# NEXUS AI — Agentic Enterprise Intelligence Platform

**Phase 1: Foundation.** Auth, a Postgres-backed data layer, and a real
streaming AI chat over WebSocket, with a pluggable LLM layer that already
supports both Anthropic and OpenAI.

**Phase 2: Document Intelligence.** Upload PDF/DOCX/TXT → parse → chunk →
embed (pgvector) → semantic search → RAG answers with inline `[1][2]`
citations rendered in the chat UI. This is the flow the platform is meant
to be judged on: upload a document, ask a question grounded in it, see
the answer cite its source.

**Phase 3: Agents.** Every chat turn is now routed to one of five
specialist agents (Research, Document, Data Analysis, Email, Task) or a
General fallback, each with its own system prompt and tool access. Tool
calling is real, not scripted — the model decides whether and when to
call `search_documents`, `search_web`, `calculate`, `query_database`,
`create_task`, `generate_report`, or `send_notification`, and the
frontend shows the routing decision and tool trace inline. Agents also
share a persistent, cross-conversation memory (`remember_fact` /
`recall_memory`), separate from ordinary chat history.

**Phase 4: Automation.** Workflows — named, scheduled, multi-step agent
runs — turn the "every Monday, analyze pending tasks and generate a
report" example from a hypothetical into something you can actually
create in the UI and watch execute. A cron scheduler triggers each
workflow's steps in order with no human typing anything; the exact same
tool-calling loop Phase 3 built for chat runs unattended, and every run's
full transcript (including tool calls) lands in an ordinary Conversation
you can open from the chat UI.

**Phase 5: Evaluation.** Real instrumentation, not simulated numbers —
every chat turn and workflow step now records actual latency and token
usage from the provider's own API response, converted to an estimated
cost via a pricing table. On top of that, a test-dataset harness runs a
set of question/reference-answer pairs through the live agent pipeline
and scores each response with an LLM-as-judge on accuracy, relevance,
faithfulness, response quality, and hallucination — plus, for cases that
name an expected source document, real retrieval precision/recall
against pgvector's actual search results. All of it — cost, latency,
eval scores — surfaces on an `/eval` dashboard with real charts
(recharts), not placeholder numbers.

This closes out the roadmap from the original brief — Foundation through
Evaluation are all built.

## Architecture

```
                       ┌─────────────────────┐
                       │   Next.js frontend    │
                       │  (App Router, TS, TW) │
                       └──────────┬───────────┘
                     REST (auth)  │  WebSocket (chat)
                                  ▼
                       ┌─────────────────────┐
                       │   FastAPI backend     │
                       │  auth · chat · llm/*  │
                       └──────────┬───────────┘
                                  │
                    ┌─────────────┼─────────────┬──────────────────┬─────────────┐
                    ▼                            ▼                  ▼             ▼
          ┌───────────────────┐        ┌──────────────────┐  ┌───────────────────┐  ┌──────────────┐
          │ PostgreSQL +       │        │ LLM providers      │  │ Embedding providers │  │ Tools          │
          │ pgvector           │        │ (Anthropic/OpenAI)  │  │ (OpenAI/Voyage)      │  │ search_web     │
          │ users/conversations│        │ tool-calling loop    │  └───────────────────┘  │ (Tavily)       │
          │ /messages/documents│        └──────────────────┘                              └──────────────┘
          │ /tasks/reports/    │
          │ /notification_logs │
          │ /memory_entries    │
          └───────────────────┘
```

**RAG flow (Phase 2):** upload → `services/parsing.py` extracts text
page-by-page → `services/chunking.py` splits on paragraph boundaries with
overlap → each chunk is embedded and stored with its source page number →
the `search_documents` tool embeds the question and pulls the nearest
chunks via pgvector cosine distance, scoped to that user's `status =
"ready"` documents → numbered results are returned to the model, which
cites them inline as `[1]`/`[2]`; the same numbered list is sent to the
frontend as a `citations` WebSocket frame so the UI doesn't have to parse
the model's prose to render sources.

**Agent flow (Phase 3):** every user message is first classified by a
cheap, non-streaming LLM call (`agents/router.py`) into one of five
specialist agents or a General fallback — each just a system prompt plus
a subset of tools (`agents/definitions.py`). The chosen agent then runs
`LLMProvider.run_agentic_turn()`: the model is called with its tool
definitions, and for as long as it requests tool use, each tool executes
(`app/tools/*.py`) and its result is fed back, until the model returns a
final text-only answer. Every routing decision and tool call/result is
streamed to the frontend live (`routing`, `tool_call`, `tool_result`
WebSocket frames) so the UI can show its work, not just the final
sentence — this is the difference between "AI chatbot" and "agentic AI
system" the brief calls out. Notably, Phase 2's RAG was *forced*
(retrieval ran on every turn automatically); Phase 3 gives the model
*agency* — `search_documents` is available but only called when the
agent decides it's actually needed.

**Why `query_database` isn't free-form SQL:** letting an LLM generate
arbitrary SQL against the primary application database is a real
injection/exfiltration risk no matter how the prompt tries to constrain
it. The tool instead exposes a small, fixed, enumerable set of read-only
query types (`count_documents`, `list_tasks`, etc.), each ordinary
parameterized SQLAlchemy code scoped to the requesting user's own rows.

**Memory, and its parallel to how this environment works:** `MemoryEntry`
gives agents a `remember_fact`/`recall_memory` tool pair backed by the
same embed-then-cosine-search pattern as document chunks — durable facts
survive across conversations, distinct from the ordinary per-thread
`messages` history. It's the same shape of problem (and roughly the same
solution) production assistants use for their own persistent memory.

**Automation flow (Phase 4):** a `Workflow` is a name, a cron expression,
a chosen tool set, and an ordered list of plain-language `WorkflowStep`
instructions. `app/scheduler.py` runs a single in-process APScheduler
instance that fires a job per workflow on its cron trigger; the job calls
`app/automation/executor.py::run_workflow`, which creates a fresh
`Conversation` (tagged `[Automation] <name> — <timestamp>`) and walks the
steps in order, calling `execute_agentic_step` — the exact same function
`run_agent_turn` uses for interactive chat — for each one, threading
history forward so step 2 can build on what step 1 found. There's no
separate "automation engine": a scheduled run is interactive chat's tool
loop with the trigger being a cron tick instead of a person typing, and
`on_event=None` since there's no live socket to push progress to. Every
tool call still executes for real — `create_task` still writes a `Task`
row, `send_notification` still writes a `NotificationLog` row — which is
what makes "the agent executes the workflow rather than simply
responding with text" true rather than aspirational.

**Why the scheduler is in-process APScheduler, not Celery:** running
scheduled jobs inside the same FastAPI process needs no additional
infrastructure beyond what `docker-compose.yml` already runs. The
tradeoff is real and worth stating plainly: jobs live only as long as
this process does, and won't coordinate correctly across multiple
backend replicas (each instance would try to run every workflow on
schedule). `start_scheduler()` reconciles against the `workflows` table
on every boot, so a restart doesn't lose track of what should be
running — but horizontal scaling would need Celery Beat (single
scheduler, worker pool) or AWS EventBridge + Lambda/ECS instead. Noted
in `app/scheduler.py`'s docstring for whoever picks this up next.

**Why WebSocket over SSE:** this paid off twice now — Phase 3's
`routing`/`tool_call`/`tool_result` frames, and it left room for Phase 4
without a protocol change, since automation runs reuse the same event
shape (just persisted to `tool_trace` instead of pushed live, because
there's no socket). A bidirectional channel also leaves room for the
client to send interrupts later (cancel a running agent), which a
one-way SSE stream couldn't support without a separate connection.

**Telemetry flow (Phase 5):** `app/telemetry.py`'s `UsageAccumulator` is
a contextvar-based accumulator, not a parameter threaded through every
function. `start_usage_tracking()` at the top of a turn, then each
provider's `complete()`/`run_agentic_turn()` calls `record_api_call()`
with the real `usage.input_tokens`/`usage.output_tokens` and measured
latency the Anthropic/OpenAI SDK response actually returned — including
every round of a multi-tool-call loop, so a turn that called three tools
before answering is measured as four real API calls, not estimated as
one. `app/usage_logging.py::log_request()` turns the accumulated total
into one `RequestLog` row per turn, costed via `app/pricing.py`'s
per-model table. This is why the dashboard's latency/cost numbers are
real measurements of Phases 1-4's actual API traffic, not numbers
invented for the dashboard to have something to show.

**Why evaluation reuses `execute_agentic_step` instead of a separate
"answer this question" code path:** an eval score is only meaningful if
it's grading the same system a real user talks to. `app/evaluation/
executor.py` fixes the tool set to the General agent's (skipping the
router, since routing is a separate, non-deterministic decision that
would add noise without adding eval signal) but otherwise runs the exact
same tool-calling loop as chat and automation.

**Why retrieval metrics call `retrieve_relevant_chunks` directly instead
of parsing what the agent's `search_documents` tool call returned:** a
test case with an expected document is specifically testing "does
semantic search surface the right document for this query" — a property
of the retriever, not of whether the agent happened to decide to search.
Measuring it independently means a low score unambiguously means
"retrieval needs work," not "retrieval might be fine, the agent just
didn't call it this time."

**The LLM-as-judge caveat, stated plainly:** `app/evaluation/judge.py`
grades accuracy/relevance/faithfulness/response_quality and flags
hallucination by asking an LLM to score another LLM's output. It's the
standard approach for grading open-ended text at scale — there's no
deterministic check for "is this a good answer" — but the judge is
itself a model with its own failure modes (it can be talked into
approving a confident-sounding wrong answer, and scores will shift if
the underlying judge model changes). Treat these numbers as a consistent
signal for catching regressions over time, not as ground truth on par
with a human grader.

**Why the LLM layer is pluggable:** `app/llm/base.py` defines one
interface (`stream_chat`); `anthropic_provider.py` and
`openai_provider.py` both implement it; `factory.py` picks one by name.
Conversations store which provider they use, so a demo can show the same
chat working against two different model vendors — useful both as an
engineering signal and as a hedge against any single provider's API
changing.

**Why pgvector is enabled in Phase 1:** the `document_chunks` table and
its `embedding` column don't exist yet, but the extension is installed in
the very first migration so Phase 2 (Document Intelligence) only needs to
add a table, not a new infra dependency.

**Why HNSW over ivfflat for the ANN index (migration `0003`):** ivfflat's
cluster centroids are trained from whatever rows exist at `CREATE INDEX`
time, which is awkward when the index is created by a migration that
typically runs before any documents are uploaded. HNSW builds
incrementally with no training step, so retrieval is fast from the first
uploaded document onward instead of needing a reindex once volume grows.

## Repo layout

```
nexus/
  backend/
    app/
      main.py          FastAPI app, CORS, router registration, scheduler lifespan
      config.py         Settings (env-driven)
      database.py        SQLAlchemy engine/session
      models.py          User, Conversation, Message, ... RequestLog/EvalDataset/EvalRun/EvalResult
      schemas.py          Pydantic request/response models
      auth.py             JWT + password hashing, HTTP + WebSocket auth deps
      scheduler.py           in-process APScheduler — cron jobs synced to the workflows table
      telemetry.py            contextvar-based usage accumulator — real latency/token capture
      pricing.py               per-model $/token table → estimate_cost_usd() (approximate, see file)
      usage_logging.py          UsageAccumulator → one persisted RequestLog row per turn
      routers/
        auth.py            /api/auth/register, /login, /refresh, /me
        chat.py             /api/chat/conversations, WS /api/chat/ws/{id} (agent-routed)
        documents.py         /api/documents upload/list/delete
        agent_data.py          /api/agent-data/tasks|reports|notifications (read-only)
        workflows.py             /api/workflows CRUD, /run-now, /runs, /meta/tools
        evaluation.py              /api/eval datasets/runs, /api/eval/telemetry/summary|points
      llm/
        base.py             LLMProvider interface
        anthropic_provider.py  instrumented — records usage on every API call
        openai_provider.py      instrumented — records usage on every API call
        factory.py           get_provider(name)
      embeddings/
        base.py             EmbeddingProvider interface
        openai_embeddings.py  text-embedding-3-small (1536 dims, default)
        voyage_embeddings.py  voyage-3 (1024 dims, Anthropic's recommended pairing)
        factory.py            get_embedding_provider()
      services/
        parsing.py            PDF/DOCX/TXT → text, page-aware
        chunking.py            paragraph-aware splitter with overlap
        retrieval.py            embed query → pgvector cosine search → context block
      agents/
        definitions.py           5 agents + General fallback (system prompt + tool subset)
        router.py                  cheap classification call → picks the agent per turn
        executor.py                 execute_agentic_step (shared tool loop) + run_agent_turn (chat entry point, now usage-tracked)
      tools/
        base.py                   ToolDefinition/ToolContext/registry (ToolContext.emit is transport-agnostic)
        search_documents.py        wraps services/retrieval, pushes citations
        calculator.py                safe AST arithmetic (never eval())
        web_search.py                Tavily-backed, degrades gracefully unconfigured
        database_query.py             fixed structured queries, never raw SQL
        tasks.py / reports.py / notifications.py
        memory.py                      remember_fact / recall_memory
      automation/
        executor.py               run_workflow — steps through a Workflow via execute_agentic_step, now usage-tracked per step
      evaluation/
        judge.py                  LLM-as-judge: accuracy/relevance/faithfulness/quality/hallucination
        retrieval_metrics.py        precision/recall against a case's expected_document_id
        executor.py                  run_evaluation — scores every case in a dataset, aggregates run averages
    alembic/
      0001  initial schema + pgvector extension
      0002  documents, document_chunks, conversations.rag_enabled
      0003  HNSW ANN index on document_chunks.embedding
      0004  tasks, reports, notification_logs, memory_entries, messages.agent_key/tool_trace
      0005  workflows, workflow_steps, workflow_runs
      0006  request_logs, eval_datasets, eval_cases, eval_runs, eval_results
    uploads/               local file storage (swap for S3 on AWS deploy)
  frontend/
    app/
      page.tsx              landing
      login/, register/     auth pages
      chat/page.tsx          conversation list + active chat (?conversation= deep-link support)
      workflows/page.tsx      workflow builder: create/list/enable/disable/run-now/run history
      eval/page.tsx            telemetry dashboard + test dataset builder + run results/charts
    components/
      ChatWindow.tsx          message list + composer, wired to WS
      MessageBubble.tsx        renders text + streaming indicator + citations + agent trace
      CitationList.tsx          numbered source list under a RAG answer
      AgentTrace.tsx             which agent handled the turn + expandable tool call log
      DocumentPanel.tsx          upload/list/delete, shown in the chat sidebar
      TaskPanel.tsx               read-only, polling view of agent-created tasks
    lib/
      auth-context.tsx        token storage, login/register/logout, authFetch
      ws.ts                    useChatSocket() hook (delta/citations/routing/tool_call/tool_result/done)
      api.ts                    REST helpers (conversations, documents, tasks, workflows, eval, telemetry)
  docker-compose.yml        postgres (pgvector image) + backend + frontend
```

## Running locally

**Option A — Docker (recommended, matches deploy topology):**

```bash
cp backend/.env.example backend/.env
# fill in ANTHROPIC_API_KEY and/or OPENAI_API_KEY in backend/.env
docker compose up --build
```

Frontend: http://localhost:3000 · Backend docs: http://localhost:8000/docs

**Option B — Run natively:**

```bash
# Postgres — any local instance with the pgvector extension available
# (the pgvector/pgvector:pg16 Docker image is the easiest way to get one)

# Backend
cd backend
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env   # fill in keys + DATABASE_URL
alembic upgrade head
uvicorn app.main:app --reload

# Frontend
cd frontend
npm install
cp .env.example .env.local
npm run dev
```

## What's demoable right now

1. Register / log in (real JWT access + refresh tokens, bcrypt hashing).
2. Start a conversation, send a message, watch the response stream
   token-by-token over WebSocket.
3. Switch `llm_provider` on a conversation (via the API — a UI toggle is
   a nicety, not built yet) to compare Anthropic vs. OpenAI on the same
   prompt.
4. **Upload a PDF/DOCX/TXT** (e.g. an employee handbook) via the sidebar,
   wait for status to flip to "Ready", then ask a question about it.
   NEXUS routes the question to the Document Agent, which calls
   `search_documents` and answers with inline `[1][2]` citations — the
   sidebar-adjacent message shows exactly which document and page each
   citation came from.
5. **Follow up with "Create a task for HR to review this policy."** NEXUS
   routes this second message to the Task Agent (a different agent than
   the one that just answered), which calls `create_task`. The message
   bubble's expandable trace shows the routing decision and the tool call
   live, and the new task appears in the sidebar's Tasks panel within a
   few seconds — a real persisted side effect, not text describing one.
   This pair is the exact "AI chatbot ❌ vs. agentic AI system ✅" demo
   from the brief.
6. Ask something needing math ("what's a 15% raise on $85,000?") and
   watch the Data Analysis or General agent call `calculate` rather than
   trusting the model's own arithmetic.
7. Ask it to email/notify someone about something — the Email Agent
   drafts the message and calls `send_notification` (simulated —
   logged, not actually delivered, unless a real provider is wired in).
8. **Build a workflow.** Go to Workflows in the sidebar, create one named
   "Weekly overdue task report" on the `0 9 * * 1` schedule with two
   steps — "Analyze pending tasks and identify anything overdue" and
   "Summarize the situation and generate a report" — and give it the
   `query_database`, `calculate`, and `generate_report` tools. Click
   **Run now** instead of waiting for Monday: within a few seconds a run
   appears with status `success`, and "View transcript" opens the exact
   conversation the agent had with itself — two steps, tool calls
   included — in the normal chat UI. This is the brief's automation
   example, actually running, not just described.
9. **Open the Eval dashboard.** After a few chat messages and a workflow
   run, the Telemetry section already has real latency/cost numbers to
   show — this is measured, not mocked. Then create a test dataset (a
   few questions, optionally with reference answers and an expected
   source document from your uploads) and click **Run evaluation**: each
   question gets answered by the live agent pipeline, graded by the
   LLM judge, and scored for retrieval precision/recall where
   applicable. The bar chart shows dataset-level averages across every
   dimension the brief's dashboard asks for, and each case expands to
   show the judge's rationale — this is "especially valuable for your
   resume" made concrete, not aspirational.

## Roadmap — what's next after this scaffold

All five phases from the original brief are built: Foundation, Document
Intelligence, Agents, Automation, and Evaluation. What's genuinely left
before this is production-ready rather than demo-ready:

- **Actually run it against live API keys.** Nothing in this repo has
  executed against real Anthropic/OpenAI/Tavily/Voyage traffic yet — the
  tool-calling message formats (especially Anthropic's `tool_use`/
  `tool_result` content blocks) were built from careful recall of each
  vendor's API shape, not verified against a live call. Treat "does a
  full multi-tool agent turn actually complete" as the first thing to
  check, before trusting anything downstream of it (including every eval
  score, which depends on the answering call succeeding).
- **Deploy:** frontend on Vercel or an AWS static/CDN target, backend as
  an AWS ECS/Fargate service (Dockerfile already in place), managed
  Postgres via RDS with pgvector. If workflow volume ever justifies it,
  swap `app/scheduler.py`'s in-process APScheduler for Celery Beat or
  AWS EventBridge + Lambda/ECS (see that file's docstring) so scheduling
  survives a multi-instance deploy.
- **Verify the pricing table** in `app/pricing.py` against current
  vendor pricing pages before quoting any cost number from this system
  to someone else — it's hand-entered and vendors change prices without
  much notice.
- **Move large eval runs off the request/response cycle.** `POST /api/
  eval/datasets/{id}/run` executes synchronously, which is fine for the
  tens-of-cases datasets a portfolio demo uses but would time out on a
  genuinely large regression suite — that wants a background task with
  a polling or websocket status endpoint instead.
