import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        // NEXUS design tokens — a "signal room" palette: near-black base,
        // one cyan-signal accent, warm amber reserved for alerts only.
        nexus: {
          bg: "#0A0E12",
          surface: "#10151B",
          border: "#1E2730",
          text: "#E4E9ED",
          muted: "#7C8894",
          signal: "#2DD4BF",
          signalDim: "#134E48",
          alert: "#F5A623",
        },
      },
      fontFamily: {
        sans: ["Inter", "system-ui", "sans-serif"],
        mono: ["JetBrains Mono", "ui-monospace", "SFMono-Regular", "monospace"],
      },
    },
  },
  plugins: [],
};

export default config;
