"use client";

import { createContext, useContext, useEffect, useState, ReactNode } from "react";

const API_BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

type User = { id: string; email: string; full_name: string | null };

type AuthContextValue = {
  user: User | null;
  accessToken: string | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (email: string, password: string, fullName?: string) => Promise<void>;
  logout: () => void;
  authFetch: (path: string, init?: RequestInit) => Promise<Response>;
};

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [accessToken, setAccessToken] = useState<string | null>(null);
  const [refreshToken, setRefreshToken] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  // Bootstrap from localStorage on first mount
  useEffect(() => {
    const at = localStorage.getItem("nexus_access_token");
    const rt = localStorage.getItem("nexus_refresh_token");
    if (at && rt) {
      setAccessToken(at);
      setRefreshToken(rt);
      fetchMe(at).finally(() => setLoading(false));
    } else {
      setLoading(false);
    }
  }, []);

  async function fetchMe(token: string) {
    const res = await fetch(`${API_BASE}/api/auth/me`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    if (res.ok) setUser(await res.json());
  }

  function storeTokens(access: string, refresh: string) {
    localStorage.setItem("nexus_access_token", access);
    localStorage.setItem("nexus_refresh_token", refresh);
    setAccessToken(access);
    setRefreshToken(refresh);
  }

  async function login(email: string, password: string) {
    const res = await fetch(`${API_BASE}/api/auth/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    });
    if (!res.ok) throw new Error((await res.json()).detail || "Login failed");
    const data = await res.json();
    storeTokens(data.access_token, data.refresh_token);
    await fetchMe(data.access_token);
  }

  async function register(email: string, password: string, fullName?: string) {
    const res = await fetch(`${API_BASE}/api/auth/register`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password, full_name: fullName }),
    });
    if (!res.ok) throw new Error((await res.json()).detail || "Registration failed");
    await login(email, password);
  }

  function logout() {
    localStorage.removeItem("nexus_access_token");
    localStorage.removeItem("nexus_refresh_token");
    setAccessToken(null);
    setRefreshToken(null);
    setUser(null);
  }

  // Wraps fetch with the access token, retrying once via refresh on a 401
  async function authFetch(path: string, init: RequestInit = {}): Promise<Response> {
    const doFetch = (token: string | null) =>
      fetch(`${API_BASE}${path}`, {
        ...init,
        headers: {
          ...(init.headers || {}),
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
      });

    let res = await doFetch(accessToken);
    if (res.status === 401 && refreshToken) {
      const refreshRes = await fetch(`${API_BASE}/api/auth/refresh`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ refresh_token: refreshToken }),
      });
      if (refreshRes.ok) {
        const data = await refreshRes.json();
        storeTokens(data.access_token, data.refresh_token);
        res = await doFetch(data.access_token);
      } else {
        logout();
      }
    }
    return res;
  }

  return (
    <AuthContext.Provider
      value={{ user, accessToken, loading, login, register, logout, authFetch }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}

export { API_BASE };
