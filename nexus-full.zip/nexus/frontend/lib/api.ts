export type Conversation = {
  id: string;
  title: string;
  llm_provider: string;
  created_at: string;
};

export async function listConversations(
  authFetch: (path: string, init?: RequestInit) => Promise<Response>
): Promise<Conversation[]> {
  const res = await authFetch("/api/chat/conversations");
  if (!res.ok) throw new Error("Failed to load conversations");
  return res.json();
}

export async function createConversation(
  authFetch: (path: string, init?: RequestInit) => Promise<Response>
): Promise<Conversation> {
  const res = await authFetch("/api/chat/conversations", { method: "POST" });
  if (!res.ok) throw new Error("Failed to create conversation");
  return res.json();
}

export type NexusDocument = {
  id: string;
  filename: string;
  content_type: string;
  status: "processing" | "ready" | "failed";
  error_message: string | null;
  chunk_count: number;
  created_at: string;
};

export async function listDocuments(
  authFetch: (path: string, init?: RequestInit) => Promise<Response>
): Promise<NexusDocument[]> {
  const res = await authFetch("/api/documents");
  if (!res.ok) throw new Error("Failed to load documents");
  return res.json();
}

export async function uploadDocument(
  authFetch: (path: string, init?: RequestInit) => Promise<Response>,
  file: File
): Promise<NexusDocument> {
  const form = new FormData();
  form.append("file", file);
  // Don't set Content-Type manually — the browser needs to add the
  // multipart boundary itself.
  const res = await authFetch("/api/documents/upload", { method: "POST", body: form });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.detail || "Upload failed");
  }
  return res.json();
}

export async function deleteDocument(
  authFetch: (path: string, init?: RequestInit) => Promise<Response>,
  id: string
): Promise<void> {
  const res = await authFetch(`/api/documents/${id}`, { method: "DELETE" });
  if (!res.ok) throw new Error("Failed to delete document");
}

export type NexusTask = {
  id: string;
  title: string;
  description: string | null;
  status: "open" | "done";
  due_date: string | null;
  source: "user" | "agent";
  created_at: string;
};

export async function listTasks(
  authFetch: (path: string, init?: RequestInit) => Promise<Response>
): Promise<NexusTask[]> {
  const res = await authFetch("/api/agent-data/tasks");
  if (!res.ok) throw new Error("Failed to load tasks");
  return res.json();
}

// ---- Workflows (Phase 4 — Automation) ----

export type ToolInfo = { name: string; description: string };

export type WorkflowStep = { id?: string; instruction: string };

export type Workflow = {
  id: string;
  name: string;
  description: string | null;
  cron_expression: string;
  enabled: boolean;
  llm_provider: string;
  tool_names: string[];
  last_run_at: string | null;
  created_at: string;
};

export type WorkflowDetail = Workflow & {
  system_prompt: string | null;
  steps: WorkflowStep[];
};

export type WorkflowRun = {
  id: string;
  status: "running" | "success" | "failed";
  conversation_id: string | null;
  started_at: string;
  finished_at: string | null;
  error_message: string | null;
};

export type WorkflowCreateInput = {
  name: string;
  description?: string;
  cron_expression: string;
  enabled?: boolean;
  llm_provider?: string;
  tool_names: string[];
  steps: WorkflowStep[];
};

async function jsonOrThrow(res: Response) {
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.detail || "Request failed");
  }
  return res.json();
}

export async function listAvailableTools(
  authFetch: (path: string, init?: RequestInit) => Promise<Response>
): Promise<ToolInfo[]> {
  return jsonOrThrow(await authFetch("/api/workflows/meta/tools"));
}

export async function listWorkflows(
  authFetch: (path: string, init?: RequestInit) => Promise<Response>
): Promise<Workflow[]> {
  return jsonOrThrow(await authFetch("/api/workflows"));
}

export async function createWorkflow(
  authFetch: (path: string, init?: RequestInit) => Promise<Response>,
  input: WorkflowCreateInput
): Promise<WorkflowDetail> {
  return jsonOrThrow(
    await authFetch("/api/workflows", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(input),
    })
  );
}

export async function updateWorkflow(
  authFetch: (path: string, init?: RequestInit) => Promise<Response>,
  id: string,
  patch: Partial<WorkflowCreateInput>
): Promise<WorkflowDetail> {
  return jsonOrThrow(
    await authFetch(`/api/workflows/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(patch),
    })
  );
}

export async function deleteWorkflow(
  authFetch: (path: string, init?: RequestInit) => Promise<Response>,
  id: string
): Promise<void> {
  const res = await authFetch(`/api/workflows/${id}`, { method: "DELETE" });
  if (!res.ok) throw new Error("Failed to delete workflow");
}

export async function runWorkflowNow(
  authFetch: (path: string, init?: RequestInit) => Promise<Response>,
  id: string
): Promise<WorkflowRun> {
  return jsonOrThrow(await authFetch(`/api/workflows/${id}/run-now`, { method: "POST" }));
}

export async function listWorkflowRuns(
  authFetch: (path: string, init?: RequestInit) => Promise<Response>,
  id: string
): Promise<WorkflowRun[]> {
  return jsonOrThrow(await authFetch(`/api/workflows/${id}/runs`));
}

// ---- Evaluation (Phase 5) ----

export type EvalCaseInput = {
  question: string;
  expected_answer?: string;
  expected_document_id?: string;
};

export type EvalDataset = {
  id: string;
  name: string;
  description: string | null;
  created_at: string;
};

export type EvalDatasetDetail = EvalDataset & {
  cases: (EvalCaseInput & { id: string })[];
};

export type EvalResult = {
  id: string;
  case_id: string;
  question: string;
  generated_answer: string;
  accuracy: number | null;
  relevance: number | null;
  faithfulness: number | null;
  response_quality: number | null;
  hallucinated: boolean | null;
  judge_rationale: string | null;
  retrieval_precision: number | null;
  retrieval_recall: number | null;
  latency_ms: number;
  input_tokens: number;
  output_tokens: number;
  cost_usd: number;
};

export type EvalRun = {
  id: string;
  dataset_id: string;
  status: "running" | "success" | "failed";
  error_message: string | null;
  avg_accuracy: number | null;
  avg_relevance: number | null;
  avg_faithfulness: number | null;
  avg_response_quality: number | null;
  avg_retrieval_precision: number | null;
  avg_retrieval_recall: number | null;
  hallucination_rate: number | null;
  avg_latency_ms: number | null;
  total_input_tokens: number;
  total_output_tokens: number;
  total_cost_usd: number;
  started_at: string;
  finished_at: string | null;
};

export type EvalRunDetail = EvalRun & { results: EvalResult[] };

export type TelemetrySummary = {
  window_days: number;
  total_requests: number;
  total_input_tokens: number;
  total_output_tokens: number;
  total_cost_usd: number;
  avg_latency_ms: number | null;
  by_kind: Record<string, number>;
};

export type TelemetryPoint = {
  created_at: string;
  kind: string;
  latency_ms: number;
  cost_usd: number;
  input_tokens: number;
  output_tokens: number;
};

export async function listEvalDatasets(
  authFetch: (path: string, init?: RequestInit) => Promise<Response>
): Promise<EvalDataset[]> {
  return jsonOrThrow(await authFetch("/api/eval/datasets"));
}

export async function createEvalDataset(
  authFetch: (path: string, init?: RequestInit) => Promise<Response>,
  input: { name: string; description?: string; cases: EvalCaseInput[] }
): Promise<EvalDatasetDetail> {
  return jsonOrThrow(
    await authFetch("/api/eval/datasets", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(input),
    })
  );
}

export async function deleteEvalDataset(
  authFetch: (path: string, init?: RequestInit) => Promise<Response>,
  id: string
): Promise<void> {
  const res = await authFetch(`/api/eval/datasets/${id}`, { method: "DELETE" });
  if (!res.ok) throw new Error("Failed to delete dataset");
}

export async function runEvalDataset(
  authFetch: (path: string, init?: RequestInit) => Promise<Response>,
  id: string
): Promise<EvalRun> {
  return jsonOrThrow(await authFetch(`/api/eval/datasets/${id}/run`, { method: "POST" }));
}

export async function listEvalRuns(
  authFetch: (path: string, init?: RequestInit) => Promise<Response>,
  datasetId: string
): Promise<EvalRun[]> {
  return jsonOrThrow(await authFetch(`/api/eval/datasets/${datasetId}/runs`));
}

export async function getEvalRun(
  authFetch: (path: string, init?: RequestInit) => Promise<Response>,
  runId: string
): Promise<EvalRunDetail> {
  return jsonOrThrow(await authFetch(`/api/eval/runs/${runId}`));
}

export async function getTelemetrySummary(
  authFetch: (path: string, init?: RequestInit) => Promise<Response>,
  days = 7
): Promise<TelemetrySummary> {
  return jsonOrThrow(await authFetch(`/api/eval/telemetry/summary?days=${days}`));
}

export async function getTelemetryPoints(
  authFetch: (path: string, init?: RequestInit) => Promise<Response>,
  days = 7
): Promise<TelemetryPoint[]> {
  return jsonOrThrow(await authFetch(`/api/eval/telemetry/points?days=${days}`));
}
