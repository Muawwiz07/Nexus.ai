"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { API_BASE } from "./auth-context";

export type Citation = {
  index: number;
  document_id: string;
  document_title: string;
  page_number: number | null;
  snippet: string;
};

export type ToolTraceEvent =
  | { kind: "tool_call"; name: string; input: Record<string, unknown> }
  | { kind: "tool_result"; name: string; result: unknown };

export type ChatMessage = {
  role: "user" | "assistant";
  content: string;
  streaming?: boolean;
  citations?: Citation[];
  agentLabel?: string;
  trace?: ToolTraceEvent[];
};

export function useChatSocket(conversationId: string | null, accessToken: string | null) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [connected, setConnected] = useState(false);
  const socketRef = useRef<WebSocket | null>(null);
  // Citations, routing, and tool trace all arrive in their own frames
  // before the delta stream starts (the agent routes, calls tools, THEN
  // the final answer streams), so they're stashed here and attached to
  // the assistant bubble as it's created.
  const pendingCitationsRef = useRef<Citation[] | null>(null);
  const pendingAgentLabelRef = useRef<string | null>(null);
  const pendingTraceRef = useRef<ToolTraceEvent[]>([]);

  useEffect(() => {
    if (!conversationId || !accessToken) return;

    const wsBase = API_BASE.replace(/^http/, "ws");
    const socket = new WebSocket(
      `${wsBase}/api/chat/ws/${conversationId}?token=${accessToken}`
    );
    socketRef.current = socket;

    socket.onopen = () => setConnected(true);
    socket.onclose = () => setConnected(false);

    socket.onmessage = (event) => {
      const data = JSON.parse(event.data);
      if (data.type === "routing") {
        pendingAgentLabelRef.current = data.agent_label;
        pendingTraceRef.current = [];
      } else if (data.type === "tool_call") {
        pendingTraceRef.current = [
          ...pendingTraceRef.current,
          { kind: "tool_call", name: data.name, input: data.input },
        ];
      } else if (data.type === "tool_result") {
        pendingTraceRef.current = [
          ...pendingTraceRef.current,
          { kind: "tool_result", name: data.name, result: data.result },
        ];
      } else if (data.type === "citations") {
        pendingCitationsRef.current = data.citations;
      } else if (data.type === "delta") {
        setMessages((prev) => {
          const last = prev[prev.length - 1];
          if (last && last.role === "assistant" && last.streaming) {
            return [
              ...prev.slice(0, -1),
              { ...last, content: last.content + data.content },
            ];
          }
          const citations = pendingCitationsRef.current || undefined;
          const agentLabel = pendingAgentLabelRef.current || undefined;
          const trace = pendingTraceRef.current.length ? pendingTraceRef.current : undefined;
          pendingCitationsRef.current = null;
          pendingAgentLabelRef.current = null;
          pendingTraceRef.current = [];
          return [
            ...prev,
            {
              role: "assistant",
              content: data.content,
              streaming: true,
              citations,
              agentLabel,
              trace,
            },
          ];
        });
      } else if (data.type === "done") {
        setMessages((prev) => {
          const last = prev[prev.length - 1];
          if (last && last.streaming) {
            return [...prev.slice(0, -1), { ...last, streaming: false }];
          }
          return prev;
        });
      }
    };

    return () => socket.close();
  }, [conversationId, accessToken]);

  const sendMessage = useCallback((content: string) => {
    if (socketRef.current?.readyState !== WebSocket.OPEN) return;
    setMessages((prev) => [...prev, { role: "user", content }]);
    socketRef.current.send(JSON.stringify({ content }));
  }, []);

  return { messages, setMessages, connected, sendMessage };
}
