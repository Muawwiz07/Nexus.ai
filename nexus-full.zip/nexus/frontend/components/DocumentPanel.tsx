"use client";

import { useEffect, useRef, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { deleteDocument, listDocuments, NexusDocument, uploadDocument } from "@/lib/api";

const STATUS_LABEL: Record<NexusDocument["status"], string> = {
  processing: "Processing…",
  ready: "Ready",
  failed: "Failed",
};

const STATUS_COLOR: Record<NexusDocument["status"], string> = {
  processing: "text-nexus-alert",
  ready: "text-nexus-signal",
  failed: "text-red-400",
};

export default function DocumentPanel() {
  const { authFetch } = useAuth();
  const [documents, setDocuments] = useState<NexusDocument[]>([]);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    refresh();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  async function refresh() {
    try {
      setDocuments(await listDocuments(authFetch));
    } catch {
      // Non-fatal — panel just stays empty; sidebar shouldn't crash the page.
    }
  }

  async function handleFile(file: File) {
    setError(null);
    setUploading(true);
    try {
      await uploadDocument(authFetch, file);
      await refresh();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setUploading(false);
      if (inputRef.current) inputRef.current.value = "";
    }
  }

  async function handleDelete(id: string) {
    await deleteDocument(authFetch, id);
    setDocuments((prev) => prev.filter((d) => d.id !== id));
  }

  return (
    <div className="border-t border-nexus-border p-4 space-y-3">
      <div className="flex items-center justify-between">
        <span className="text-xs font-mono uppercase tracking-wide text-nexus-muted">
          Documents
        </span>
        <button
          onClick={() => inputRef.current?.click()}
          disabled={uploading}
          className="text-xs text-nexus-signal hover:underline disabled:opacity-40"
        >
          {uploading ? "Uploading…" : "+ Upload"}
        </button>
        <input
          ref={inputRef}
          type="file"
          accept=".pdf,.docx,.txt"
          className="hidden"
          onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])}
        />
      </div>

      {error && <p className="text-xs text-red-400">{error}</p>}

      {documents.length === 0 && !uploading && (
        <p className="text-xs text-nexus-muted">
          Upload a PDF, DOCX, or TXT to ground chat answers in it.
        </p>
      )}

      <div className="space-y-1.5 max-h-40 overflow-y-auto">
        {documents.map((d) => (
          <div key={d.id} className="flex items-center justify-between gap-2 text-xs">
            <span className="truncate text-nexus-text" title={d.filename}>
              {d.filename}
            </span>
            <div className="flex items-center gap-2 shrink-0">
              <span className={STATUS_COLOR[d.status]}>{STATUS_LABEL[d.status]}</span>
              <button
                onClick={() => handleDelete(d.id)}
                className="text-nexus-muted hover:text-red-400 transition"
                title="Delete"
              >
                ×
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
