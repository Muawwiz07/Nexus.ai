"use client";

import { useState } from "react";
import type { ToolTraceEvent } from "@/lib/ws";

function summarizeResult(result: unknown): string {
  if (typeof result === "string") return result.slice(0, 140);
  if (result && typeof result === "object") {
    const obj = result as Record<string, unknown>;
    if (typeof obj.error === "string") return `Error: ${obj.error}`;
    if (typeof obj.result === "string") return obj.result.slice(0, 140);
    return JSON.stringify(result).slice(0, 140);
  }
  return String(result);
}

export default function AgentTrace({
  agentLabel,
  trace,
}: {
  agentLabel?: string;
  trace?: ToolTraceEvent[];
}) {
  const [expanded, setExpanded] = useState(false);
  if (!agentLabel && !trace?.length) return null;

  const calls = trace?.filter((e): e is Extract<ToolTraceEvent, { kind: "tool_call" }> =>
    e.kind === "tool_call"
  );

  return (
    <div className="mb-1.5 text-[11px] font-mono text-nexus-muted">
      <button
        onClick={() => setExpanded((v) => !v)}
        className="flex items-center gap-1.5 hover:text-nexus-signal transition"
      >
        <span className="w-1 h-1 rounded-full bg-nexus-signal" />
        {agentLabel && <span>{agentLabel}</span>}
        {calls && calls.length > 0 && (
          <span>
            · {calls.length} tool call{calls.length > 1 ? "s" : ""}
          </span>
        )}
        {trace && trace.length > 0 && <span>{expanded ? "▲" : "▼"}</span>}
      </button>

      {expanded && trace && (
        <div className="mt-1.5 space-y-1 pl-2.5 border-l border-nexus-border">
          {trace.map((event, i) =>
            event.kind === "tool_call" ? (
              <div key={i} className="text-nexus-alert">
                → {event.name}({JSON.stringify(event.input)})
              </div>
            ) : (
              <div key={i} className="text-nexus-signal">
                ✓ {event.name}: {summarizeResult(event.result)}
              </div>
            )
          )}
        </div>
      )}
    </div>
  );
}
