"use client";

import { useEffect, useRef, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { useChatSocket } from "@/lib/ws";
import MessageBubble from "./MessageBubble";

export default function ChatWindow({ conversationId }: { conversationId: string }) {
  const { accessToken } = useAuth();
  const { messages, connected, sendMessage } = useChatSocket(conversationId, accessToken);
  const [input, setInput] = useState("");
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!input.trim()) return;
    sendMessage(input.trim());
    setInput("");
  }

  return (
    <div className="flex flex-col h-full">
      <div className="flex-1 overflow-y-auto px-6 py-6 space-y-4">
        {messages.length === 0 && (
          <div className="text-center text-nexus-muted text-sm mt-20">
            Ask NEXUS anything — try "What can you help me with?"
          </div>
        )}
        {messages.map((m, i) => (
          <MessageBubble key={i} message={m} />
        ))}
        <div ref={bottomRef} />
      </div>

      <form
        onSubmit={handleSubmit}
        className="border-t border-nexus-border p-4 flex items-center gap-3"
      >
        <span
          className={`w-2 h-2 rounded-full shrink-0 ${
            connected ? "bg-nexus-signal" : "bg-nexus-muted"
          }`}
          title={connected ? "Connected" : "Connecting…"}
        />
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Message NEXUS…"
          className="flex-1 bg-nexus-bg border border-nexus-border rounded-md px-4 py-2.5 text-sm focus:outline-none focus:border-nexus-signal"
        />
        <button
          type="submit"
          disabled={!connected || !input.trim()}
          className="px-4 py-2.5 rounded-md bg-nexus-signal text-nexus-bg text-sm font-medium hover:opacity-90 transition disabled:opacity-40"
        >
          Send
        </button>
      </form>
    </div>
  );
}
