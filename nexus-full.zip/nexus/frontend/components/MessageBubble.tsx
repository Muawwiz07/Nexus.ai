import type { ChatMessage } from "@/lib/ws";
import CitationList from "./CitationList";
import AgentTrace from "./AgentTrace";

export default function MessageBubble({ message }: { message: ChatMessage }) {
  const isUser = message.role === "user";
  return (
    <div className={`flex ${isUser ? "justify-end" : "justify-start"}`}>
      <div
        className={`max-w-[75%] rounded-lg px-4 py-2.5 text-sm leading-relaxed whitespace-pre-wrap ${
          isUser
            ? "bg-nexus-signal text-nexus-bg"
            : "bg-nexus-surface border border-nexus-border text-nexus-text"
        }`}
      >
        {!isUser && <AgentTrace agentLabel={message.agentLabel} trace={message.trace} />}
        {message.content}
        {message.streaming && (
          <span className="inline-block w-1.5 h-1.5 ml-1 rounded-full bg-nexus-signal signal-dot align-middle" />
        )}
        {!isUser && message.citations && <CitationList citations={message.citations} />}
      </div>
    </div>
  );
}
