"use client";

import { useEffect, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { listTasks, NexusTask } from "@/lib/api";

export default function TaskPanel() {
  const { authFetch } = useAuth();
  const [tasks, setTasks] = useState<NexusTask[]>([]);

  useEffect(() => {
    refresh();
    // Agent-created tasks appear mid-conversation with no direct UI
    // trigger, so poll rather than requiring a manual refresh.
    const interval = setInterval(refresh, 5000);
    return () => clearInterval(interval);
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  async function refresh() {
    try {
      setTasks(await listTasks(authFetch));
    } catch {
      // Sidebar shouldn't crash the page over a transient fetch failure.
    }
  }

  if (tasks.length === 0) return null;

  return (
    <div className="border-t border-nexus-border p-4 space-y-2">
      <span className="text-xs font-mono uppercase tracking-wide text-nexus-muted">
        Tasks ({tasks.length})
      </span>
      <div className="space-y-1.5 max-h-32 overflow-y-auto">
        {tasks.map((t) => (
          <div key={t.id} className="text-xs flex items-start gap-1.5">
            <span
              className={`mt-0.5 w-1.5 h-1.5 rounded-full shrink-0 ${
                t.status === "done" ? "bg-nexus-muted" : "bg-nexus-signal"
              }`}
            />
            <span className="truncate text-nexus-text" title={t.title}>
              {t.title}
            </span>
            {t.source === "agent" && (
              <span className="text-nexus-muted shrink-0 font-mono">agent</span>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
