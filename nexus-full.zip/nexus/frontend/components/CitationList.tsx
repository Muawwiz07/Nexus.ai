import type { Citation } from "@/lib/ws";

export default function CitationList({ citations }: { citations: Citation[] }) {
  if (citations.length === 0) return null;

  return (
    <div className="mt-2 pt-2 border-t border-nexus-border/60 space-y-1">
      <span className="text-[10px] font-mono uppercase tracking-wide text-nexus-muted">
        Sources
      </span>
      {citations.map((c) => (
        <div key={c.index} className="text-xs text-nexus-muted flex gap-1.5">
          <span className="text-nexus-signal shrink-0">[{c.index}]</span>
          <span className="truncate">
            {c.document_title}
            {c.page_number ? `, p.${c.page_number}` : ""}
          </span>
        </div>
      ))}
    </div>
  );
}
