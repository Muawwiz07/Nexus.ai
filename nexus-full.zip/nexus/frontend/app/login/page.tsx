"use client";

import Link from "next/link";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/lib/auth-context";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const { login } = useAuth();
  const router = useRouter();

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      await login(email, password);
      router.push("/chat");
    } catch (err: any) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <main className="min-h-screen flex items-center justify-center px-6">
      <form
        onSubmit={handleSubmit}
        className="w-full max-w-sm space-y-5 bg-nexus-surface border border-nexus-border rounded-lg p-8"
      >
        <div>
          <h1 className="text-xl font-semibold">Sign in to NEXUS</h1>
          <p className="text-sm text-nexus-muted mt-1">Enterprise intelligence, on demand.</p>
        </div>

        {error && (
          <div className="text-sm text-nexus-alert bg-nexus-alert/10 border border-nexus-alert/30 rounded px-3 py-2">
            {error}
          </div>
        )}

        <div className="space-y-1.5">
          <label className="text-xs font-mono uppercase tracking-wide text-nexus-muted">
            Email
          </label>
          <input
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full bg-nexus-bg border border-nexus-border rounded-md px-3 py-2 text-sm focus:outline-none focus:border-nexus-signal"
          />
        </div>

        <div className="space-y-1.5">
          <label className="text-xs font-mono uppercase tracking-wide text-nexus-muted">
            Password
          </label>
          <input
            type="password"
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full bg-nexus-bg border border-nexus-border rounded-md px-3 py-2 text-sm focus:outline-none focus:border-nexus-signal"
          />
        </div>

        <button
          type="submit"
          disabled={submitting}
          className="w-full py-2.5 rounded-md bg-nexus-signal text-nexus-bg font-medium text-sm hover:opacity-90 transition disabled:opacity-50"
        >
          {submitting ? "Signing in…" : "Sign in"}
        </button>

        <p className="text-sm text-nexus-muted text-center">
          No account?{" "}
          <Link href="/register" className="text-nexus-signal hover:underline">
            Create one
          </Link>
        </p>
      </form>
    </main>
  );
}
