"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/lib/auth-context";
import {
  createWorkflow,
  deleteWorkflow,
  listAvailableTools,
  listWorkflowRuns,
  listWorkflows,
  runWorkflowNow,
  ToolInfo,
  updateWorkflow,
  Workflow,
  WorkflowRun,
} from "@/lib/api";

const CRON_PRESETS = [
  { label: "Every Monday at 9am UTC", value: "0 9 * * 1" },
  { label: "Every day at 8am UTC", value: "0 8 * * *" },
  { label: "Every hour", value: "0 * * * *" },
  { label: "Custom…", value: "custom" },
];

export default function WorkflowsPage() {
  const { user, loading, authFetch } = useAuth();
  const router = useRouter();
  const [workflows, setWorkflows] = useState<Workflow[]>([]);
  const [tools, setTools] = useState<ToolInfo[]>([]);
  const [showBuilder, setShowBuilder] = useState(false);

  useEffect(() => {
    if (!loading && !user) router.replace("/login");
  }, [loading, user, router]);

  useEffect(() => {
    if (!user) return;
    listWorkflows(authFetch).then(setWorkflows).catch(() => {});
    listAvailableTools(authFetch).then(setTools).catch(() => {});
  }, [user]); // eslint-disable-line react-hooks/exhaustive-deps

  async function refresh() {
    setWorkflows(await listWorkflows(authFetch));
  }

  if (loading || !user) return null;

  return (
    <main className="min-h-screen px-6 py-8 max-w-2xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div>
          <Link href="/chat" className="text-xs text-nexus-muted hover:text-nexus-signal">
            ← Back to chat
          </Link>
          <h1 className="text-xl font-semibold mt-1">
            Workflows <span className="text-nexus-signal">·</span> Automation
          </h1>
        </div>
        <button
          onClick={() => setShowBuilder((v) => !v)}
          className="px-4 py-2 rounded-md bg-nexus-signal text-nexus-bg text-sm font-medium hover:opacity-90 transition"
        >
          {showBuilder ? "Cancel" : "+ New workflow"}
        </button>
      </div>

      {showBuilder && (
        <WorkflowBuilder
          tools={tools}
          onCreated={() => {
            setShowBuilder(false);
            refresh();
          }}
        />
      )}

      <div className="space-y-3 mt-6">
        {workflows.length === 0 && !showBuilder && (
          <p className="text-sm text-nexus-muted">
            No workflows yet. Create one to run a multi-step agent task on a
            schedule — e.g. "every Monday, analyze pending tasks and generate
            a report."
          </p>
        )}
        {workflows.map((wf) => (
          <WorkflowCard key={wf.id} workflow={wf} onChanged={refresh} />
        ))}
      </div>
    </main>
  );
}

function WorkflowBuilder({
  tools,
  onCreated,
}: {
  tools: ToolInfo[];
  onCreated: () => void;
}) {
  const { authFetch } = useAuth();
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [cronPreset, setCronPreset] = useState(CRON_PRESETS[0].value);
  const [customCron, setCustomCron] = useState("0 9 * * 1");
  const [selectedTools, setSelectedTools] = useState<string[]>([]);
  const [steps, setSteps] = useState<string[]>([""]);
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const cronExpression = cronPreset === "custom" ? customCron : cronPreset;

  function toggleTool(name: string) {
    setSelectedTools((prev) =>
      prev.includes(name) ? prev.filter((t) => t !== name) : [...prev, name]
    );
  }

  function updateStep(i: number, value: string) {
    setSteps((prev) => prev.map((s, idx) => (idx === i ? value : s)));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);

    const cleanSteps = steps.map((s) => s.trim()).filter(Boolean);
    if (!name.trim() || cleanSteps.length === 0 || selectedTools.length === 0) {
      setError("Name, at least one step, and at least one tool are required.");
      return;
    }

    setSubmitting(true);
    try {
      await createWorkflow(authFetch, {
        name: name.trim(),
        description: description.trim() || undefined,
        cron_expression: cronExpression,
        tool_names: selectedTools,
        steps: cleanSteps.map((instruction) => ({ instruction })),
      });
      onCreated();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <form
      onSubmit={handleSubmit}
      className="bg-nexus-surface border border-nexus-border rounded-lg p-5 space-y-4"
    >
      {error && (
        <div className="text-sm text-nexus-alert bg-nexus-alert/10 border border-nexus-alert/30 rounded px-3 py-2">
          {error}
        </div>
      )}

      <div className="space-y-1.5">
        <label className="text-xs font-mono uppercase tracking-wide text-nexus-muted">
          Name
        </label>
        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Weekly overdue task report"
          className="w-full bg-nexus-bg border border-nexus-border rounded-md px-3 py-2 text-sm focus:outline-none focus:border-nexus-signal"
        />
      </div>

      <div className="space-y-1.5">
        <label className="text-xs font-mono uppercase tracking-wide text-nexus-muted">
          Description (optional)
        </label>
        <input
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          className="w-full bg-nexus-bg border border-nexus-border rounded-md px-3 py-2 text-sm focus:outline-none focus:border-nexus-signal"
        />
      </div>

      <div className="space-y-1.5">
        <label className="text-xs font-mono uppercase tracking-wide text-nexus-muted">
          Schedule
        </label>
        <select
          value={cronPreset}
          onChange={(e) => setCronPreset(e.target.value)}
          className="w-full bg-nexus-bg border border-nexus-border rounded-md px-3 py-2 text-sm focus:outline-none focus:border-nexus-signal"
        >
          {CRON_PRESETS.map((p) => (
            <option key={p.value} value={p.value}>
              {p.label}
            </option>
          ))}
        </select>
        {cronPreset === "custom" && (
          <input
            value={customCron}
            onChange={(e) => setCustomCron(e.target.value)}
            placeholder="0 9 * * 1"
            className="w-full mt-1.5 bg-nexus-bg border border-nexus-border rounded-md px-3 py-2 text-sm font-mono focus:outline-none focus:border-nexus-signal"
          />
        )}
        <p className="text-[11px] text-nexus-muted">
          Standard 5-field cron, interpreted in UTC.
        </p>
      </div>

      <div className="space-y-1.5">
        <label className="text-xs font-mono uppercase tracking-wide text-nexus-muted">
          Steps — run in order, each can use any tool selected below
        </label>
        {steps.map((step, i) => (
          <div key={i} className="flex gap-2">
            <span className="text-nexus-muted text-sm pt-2 w-5 shrink-0">{i + 1}.</span>
            <textarea
              value={step}
              onChange={(e) => updateStep(i, e.target.value)}
              rows={2}
              placeholder="Analyze pending tasks and identify anything overdue."
              className="flex-1 bg-nexus-bg border border-nexus-border rounded-md px-3 py-2 text-sm focus:outline-none focus:border-nexus-signal resize-none"
            />
            {steps.length > 1 && (
              <button
                type="button"
                onClick={() => setSteps((prev) => prev.filter((_, idx) => idx !== i))}
                className="text-nexus-muted hover:text-red-400 text-sm px-1"
              >
                ×
              </button>
            )}
          </div>
        ))}
        <button
          type="button"
          onClick={() => setSteps((prev) => [...prev, ""])}
          className="text-xs text-nexus-signal hover:underline"
        >
          + Add step
        </button>
      </div>

      <div className="space-y-1.5">
        <label className="text-xs font-mono uppercase tracking-wide text-nexus-muted">
          Tools this workflow may use
        </label>
        <div className="flex flex-wrap gap-1.5">
          {tools.map((t) => (
            <button
              type="button"
              key={t.name}
              onClick={() => toggleTool(t.name)}
              title={t.description}
              className={`px-2.5 py-1 rounded-full text-xs border transition ${
                selectedTools.includes(t.name)
                  ? "border-nexus-signal text-nexus-signal bg-nexus-signalDim"
                  : "border-nexus-border text-nexus-muted hover:border-nexus-signal"
              }`}
            >
              {t.name}
            </button>
          ))}
        </div>
      </div>

      <button
        type="submit"
        disabled={submitting}
        className="w-full py-2.5 rounded-md bg-nexus-signal text-nexus-bg font-medium text-sm hover:opacity-90 transition disabled:opacity-50"
      >
        {submitting ? "Creating…" : "Create workflow"}
      </button>
    </form>
  );
}

function WorkflowCard({
  workflow,
  onChanged,
}: {
  workflow: Workflow;
  onChanged: () => void;
}) {
  const { authFetch } = useAuth();
  const [running, setRunning] = useState(false);
  const [runs, setRuns] = useState<WorkflowRun[] | null>(null);

  async function toggleEnabled() {
    await updateWorkflow(authFetch, workflow.id, { enabled: !workflow.enabled });
    onChanged();
  }

  async function handleDelete() {
    await deleteWorkflow(authFetch, workflow.id);
    onChanged();
  }

  async function handleRunNow() {
    setRunning(true);
    try {
      await runWorkflowNow(authFetch, workflow.id);
      await loadRuns();
      onChanged();
    } finally {
      setRunning(false);
    }
  }

  async function loadRuns() {
    setRuns(await listWorkflowRuns(authFetch, workflow.id));
  }

  return (
    <div className="bg-nexus-surface border border-nexus-border rounded-lg p-4">
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <span
              className={`w-1.5 h-1.5 rounded-full ${
                workflow.enabled ? "bg-nexus-signal" : "bg-nexus-muted"
              }`}
            />
            <span className="font-medium text-sm">{workflow.name}</span>
          </div>
          {workflow.description && (
            <p className="text-xs text-nexus-muted mt-0.5">{workflow.description}</p>
          )}
          <p className="text-[11px] font-mono text-nexus-muted mt-1.5">
            {workflow.cron_expression} (UTC)
            {workflow.last_run_at &&
              ` · last ran ${new Date(workflow.last_run_at).toLocaleString()}`}
          </p>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={handleRunNow}
            disabled={running}
            className="text-xs px-2.5 py-1 rounded-md border border-nexus-border hover:border-nexus-signal transition disabled:opacity-50"
          >
            {running ? "Running…" : "Run now"}
          </button>
          <button
            onClick={toggleEnabled}
            className="text-xs px-2.5 py-1 rounded-md border border-nexus-border hover:border-nexus-signal transition"
          >
            {workflow.enabled ? "Disable" : "Enable"}
          </button>
          <button
            onClick={handleDelete}
            className="text-xs text-nexus-muted hover:text-red-400 transition"
          >
            Delete
          </button>
        </div>
      </div>

      <button
        onClick={() => (runs ? setRuns(null) : loadRuns())}
        className="text-[11px] text-nexus-signal hover:underline mt-2"
      >
        {runs ? "Hide run history" : "Show run history"}
      </button>

      {runs && (
        <div className="mt-2 space-y-1 border-t border-nexus-border pt-2">
          {runs.length === 0 && (
            <p className="text-xs text-nexus-muted">No runs yet.</p>
          )}
          {runs.map((r) => (
            <div key={r.id} className="flex items-center justify-between text-xs">
              <span
                className={
                  r.status === "success"
                    ? "text-nexus-signal"
                    : r.status === "failed"
                    ? "text-red-400"
                    : "text-nexus-alert"
                }
              >
                {r.status}
              </span>
              <span className="text-nexus-muted">
                {new Date(r.started_at).toLocaleString()}
              </span>
              {r.conversation_id && (
                <Link
                  href={`/chat?conversation=${r.conversation_id}`}
                  className="text-nexus-signal hover:underline"
                  title="View transcript in chat"
                >
                  View transcript →
                </Link>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
