"use client";

import Link from "next/link";
import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/lib/auth-context";

export default function Home() {
  const { user, loading } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!loading && user) router.replace("/chat");
  }, [loading, user, router]);

  return (
    <main className="min-h-screen flex flex-col items-center justify-center px-6">
      <div className="max-w-xl text-center space-y-6">
        <div className="flex items-center justify-center gap-2 text-nexus-signal font-mono text-xs tracking-widest uppercase">
          <span className="w-1.5 h-1.5 rounded-full bg-nexus-signal signal-dot" />
          System online
        </div>
        <h1 className="text-4xl font-semibold tracking-tight">
          NEXUS <span className="text-nexus-signal">AI</span>
        </h1>
        <p className="text-nexus-muted leading-relaxed">
          Upload company documents, ask questions grounded in your data, and
          let agents execute the follow-up work — not just describe it.
        </p>
        <div className="flex items-center justify-center gap-3 pt-2">
          <Link
            href="/login"
            className="px-5 py-2.5 rounded-md bg-nexus-signal text-nexus-bg font-medium text-sm hover:opacity-90 transition"
          >
            Sign in
          </Link>
          <Link
            href="/register"
            className="px-5 py-2.5 rounded-md border border-nexus-border text-nexus-text font-medium text-sm hover:border-nexus-signal transition"
          >
            Create account
          </Link>
        </div>
      </div>
    </main>
  );
}
