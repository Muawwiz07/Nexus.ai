"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { useAuth } from "@/lib/auth-context";
import { Conversation, createConversation, listConversations } from "@/lib/api";
import ChatWindow from "@/components/ChatWindow";
import DocumentPanel from "@/components/DocumentPanel";
import TaskPanel from "@/components/TaskPanel";

export default function ChatPage() {
  const { user, loading, authFetch, logout } = useAuth();
  const router = useRouter();
  const searchParams = useSearchParams();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeId, setActiveId] = useState<string | null>(null);

  useEffect(() => {
    if (!loading && !user) router.replace("/login");
  }, [loading, user, router]);

  useEffect(() => {
    if (!user) return;
    listConversations(authFetch).then((convs) => {
      setConversations(convs);
      // Deep-link support: the Workflows page links here with
      // ?conversation=<id> to jump straight to a specific automation
      // run's transcript, e.g. from its run-history list.
      const requested = searchParams.get("conversation");
      if (requested && convs.some((c) => c.id === requested)) {
        setActiveId(requested);
      } else if (convs.length > 0) {
        setActiveId(convs[0].id);
      }
    });
  }, [user]); // eslint-disable-line react-hooks/exhaustive-deps

  async function handleNewConversation() {
    const conv = await createConversation(authFetch);
    setConversations((prev) => [conv, ...prev]);
    setActiveId(conv.id);
  }

  if (loading || !user) return null;

  return (
    <div className="h-screen flex">
      <aside className="w-64 shrink-0 border-r border-nexus-border flex flex-col">
        <div className="p-4 border-b border-nexus-border flex items-center justify-between">
          <span className="font-semibold text-sm">
            NEXUS <span className="text-nexus-signal">AI</span>
          </span>
          <div className="flex items-center gap-3">
            <Link
              href="/workflows"
              className="text-xs text-nexus-muted hover:text-nexus-signal transition"
              title="Automation workflows"
            >
              Workflows
            </Link>
            <Link
              href="/eval"
              className="text-xs text-nexus-muted hover:text-nexus-signal transition"
              title="Evaluation dashboard"
            >
              Eval
            </Link>
          </div>
        </div>

        <button
          onClick={handleNewConversation}
          className="mx-4 mt-4 py-2 rounded-md border border-nexus-border text-sm hover:border-nexus-signal transition"
        >
          + New conversation
        </button>

        <div className="flex-1 overflow-y-auto px-2 mt-4 space-y-1">
          {conversations.map((c) => (
            <button
              key={c.id}
              onClick={() => setActiveId(c.id)}
              className={`w-full text-left px-3 py-2 rounded-md text-sm truncate transition ${
                activeId === c.id
                  ? "bg-nexus-surface text-nexus-text"
                  : "text-nexus-muted hover:bg-nexus-surface/50"
              }`}
            >
              {c.title}
            </button>
          ))}
        </div>

        <DocumentPanel />
        <TaskPanel />

        <div className="p-4 border-t border-nexus-border flex items-center justify-between">
          <span className="text-xs text-nexus-muted truncate">{user.email}</span>
          <button
            onClick={logout}
            className="text-xs text-nexus-muted hover:text-nexus-alert transition"
          >
            Sign out
          </button>
        </div>
      </aside>

      <main className="flex-1">
        {activeId ? (
          <ChatWindow key={activeId} conversationId={activeId} />
        ) : (
          <div className="h-full flex items-center justify-center text-nexus-muted text-sm">
            Start a new conversation to begin.
          </div>
        )}
      </main>
    </div>
  );
}
