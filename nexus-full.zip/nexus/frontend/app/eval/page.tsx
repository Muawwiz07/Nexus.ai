"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { useAuth } from "@/lib/auth-context";
import {
  createEvalDataset,
  deleteEvalDataset,
  EvalCaseInput,
  EvalDataset,
  EvalRun,
  EvalRunDetail,
  getEvalRun,
  getTelemetryPoints,
  getTelemetrySummary,
  listDocuments,
  listEvalDatasets,
  listEvalRuns,
  NexusDocument,
  runEvalDataset,
  TelemetryPoint,
  TelemetrySummary,
} from "@/lib/api";

export default function EvalPage() {
  const { user, loading, authFetch } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!loading && !user) router.replace("/login");
  }, [loading, user, router]);

  if (loading || !user) return null;

  return (
    <main className="min-h-screen px-6 py-8 max-w-3xl mx-auto space-y-8">
      <div>
        <Link href="/chat" className="text-xs text-nexus-muted hover:text-nexus-signal">
          ← Back to chat
        </Link>
        <h1 className="text-xl font-semibold mt-1">
          Evaluation <span className="text-nexus-signal">·</span> Telemetry
        </h1>
      </div>

      <TelemetrySection />
      <DatasetSection />
    </main>
  );
}

// ---------------------------------------------------------------------
// Telemetry — real production traffic, independent of eval datasets
// ---------------------------------------------------------------------

function TelemetrySection() {
  const { authFetch } = useAuth();
  const [summary, setSummary] = useState<TelemetrySummary | null>(null);
  const [points, setPoints] = useState<TelemetryPoint[]>([]);

  useEffect(() => {
    getTelemetrySummary(authFetch, 7).then(setSummary).catch(() => {});
    getTelemetryPoints(authFetch, 7).then(setPoints).catch(() => {});
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const chartData = [...points]
    .reverse()
    .map((p, i) => ({ i, latency: Math.round(p.latency_ms), cost: p.cost_usd * 1000 }));

  return (
    <section>
      <h2 className="text-sm font-mono uppercase tracking-wide text-nexus-muted mb-3">
        Telemetry — last 7 days
      </h2>

      {summary && (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-4">
          <StatCard label="Requests" value={summary.total_requests.toString()} />
          <StatCard
            label="Avg latency"
            value={summary.avg_latency_ms ? `${Math.round(summary.avg_latency_ms)}ms` : "—"}
          />
          <StatCard
            label="Total tokens"
            value={(summary.total_input_tokens + summary.total_output_tokens).toLocaleString()}
          />
          <StatCard label="Total cost" value={`$${summary.total_cost_usd.toFixed(4)}`} />
        </div>
      )}

      {summary && Object.keys(summary.by_kind).length > 0 && (
        <div className="flex gap-2 mb-4 flex-wrap">
          {Object.entries(summary.by_kind).map(([kind, count]) => (
            <span
              key={kind}
              className="text-xs px-2 py-1 rounded-full border border-nexus-border text-nexus-muted"
            >
              {kind}: {count}
            </span>
          ))}
        </div>
      )}

      {chartData.length > 1 && (
        <div className="bg-nexus-surface border border-nexus-border rounded-lg p-3 h-40">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1E2730" />
              <XAxis dataKey="i" hide />
              <YAxis tick={{ fontSize: 10, fill: "#7C8894" }} width={36} />
              <Tooltip
                contentStyle={{ background: "#10151B", border: "1px solid #1E2730", fontSize: 12 }}
                labelFormatter={() => ""}
                formatter={(value: number, name: string) =>
                  name === "latency"
                    ? [`${value}ms`, "Latency"]
                    : [`$${(value / 1000).toFixed(5)}`, "Cost"]
                }
              />
              <Line type="monotone" dataKey="latency" stroke="#2DD4BF" dot={false} strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      )}

      {(!points || points.length === 0) && (
        <p className="text-xs text-nexus-muted">
          No requests logged yet — chat, run a workflow, or run an evaluation to populate this.
        </p>
      )}
    </section>
  );
}

function StatCard({ label, value }: { label: string; value: string }) {
  return (
    <div className="bg-nexus-surface border border-nexus-border rounded-lg p-3">
      <div className="text-[10px] font-mono uppercase tracking-wide text-nexus-muted">
        {label}
      </div>
      <div className="text-lg font-semibold mt-0.5">{value}</div>
    </div>
  );
}

// ---------------------------------------------------------------------
// Datasets — test dataset CRUD + run evaluation
// ---------------------------------------------------------------------

function DatasetSection() {
  const { authFetch } = useAuth();
  const [datasets, setDatasets] = useState<EvalDataset[]>([]);
  const [showBuilder, setShowBuilder] = useState(false);
  const [selectedRun, setSelectedRun] = useState<EvalRunDetail | null>(null);

  useEffect(() => {
    refresh();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  async function refresh() {
    setDatasets(await listEvalDatasets(authFetch));
  }

  return (
    <section>
      <div className="flex items-center justify-between mb-3">
        <h2 className="text-sm font-mono uppercase tracking-wide text-nexus-muted">
          Test datasets
        </h2>
        <button
          onClick={() => setShowBuilder((v) => !v)}
          className="px-3 py-1.5 rounded-md bg-nexus-signal text-nexus-bg text-xs font-medium hover:opacity-90 transition"
        >
          {showBuilder ? "Cancel" : "+ New dataset"}
        </button>
      </div>

      {showBuilder && (
        <DatasetBuilder
          onCreated={() => {
            setShowBuilder(false);
            refresh();
          }}
        />
      )}

      {selectedRun ? (
        <RunDetailView run={selectedRun} onBack={() => setSelectedRun(null)} />
      ) : (
        <div className="space-y-3 mt-4">
          {datasets.length === 0 && !showBuilder && (
            <p className="text-sm text-nexus-muted">
              No test datasets yet. Create one to automatically score NEXUS's
              answers for accuracy, relevance, faithfulness, and hallucination.
            </p>
          )}
          {datasets.map((ds) => (
            <DatasetCard
              key={ds.id}
              dataset={ds}
              onDeleted={refresh}
              onViewRun={setSelectedRun}
            />
          ))}
        </div>
      )}
    </section>
  );
}

function DatasetBuilder({ onCreated }: { onCreated: () => void }) {
  const { authFetch } = useAuth();
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [cases, setCases] = useState<EvalCaseInput[]>([{ question: "" }]);
  const [documents, setDocuments] = useState<NexusDocument[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    listDocuments(authFetch).then(setDocuments).catch(() => {});
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  function updateCase(i: number, patch: Partial<EvalCaseInput>) {
    setCases((prev) => prev.map((c, idx) => (idx === i ? { ...c, ...patch } : c)));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);

    const cleaned = cases
      .map((c) => ({ ...c, question: c.question.trim() }))
      .filter((c) => c.question);
    if (!name.trim() || cleaned.length === 0) {
      setError("Name and at least one question are required.");
      return;
    }

    setSubmitting(true);
    try {
      await createEvalDataset(authFetch, {
        name: name.trim(),
        description: description.trim() || undefined,
        cases: cleaned,
      });
      onCreated();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <form
      onSubmit={handleSubmit}
      className="bg-nexus-surface border border-nexus-border rounded-lg p-5 space-y-4 mb-4"
    >
      {error && (
        <div className="text-sm text-nexus-alert bg-nexus-alert/10 border border-nexus-alert/30 rounded px-3 py-2">
          {error}
        </div>
      )}

      <div className="space-y-1.5">
        <label className="text-xs font-mono uppercase tracking-wide text-nexus-muted">
          Name
        </label>
        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Employee handbook Q&A"
          className="w-full bg-nexus-bg border border-nexus-border rounded-md px-3 py-2 text-sm focus:outline-none focus:border-nexus-signal"
        />
      </div>

      <div className="space-y-1.5">
        <label className="text-xs font-mono uppercase tracking-wide text-nexus-muted">
          Description (optional)
        </label>
        <input
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          className="w-full bg-nexus-bg border border-nexus-border rounded-md px-3 py-2 text-sm focus:outline-none focus:border-nexus-signal"
        />
      </div>

      <div className="space-y-3">
        <label className="text-xs font-mono uppercase tracking-wide text-nexus-muted">
          Test cases
        </label>
        {cases.map((c, i) => (
          <div key={i} className="border border-nexus-border rounded-md p-3 space-y-2">
            <div className="flex items-start gap-2">
              <span className="text-nexus-muted text-sm pt-2 w-5 shrink-0">{i + 1}.</span>
              <textarea
                value={c.question}
                onChange={(e) => updateCase(i, { question: e.target.value })}
                rows={2}
                placeholder="What is the leave policy for employees with 2+ years of service?"
                className="flex-1 bg-nexus-bg border border-nexus-border rounded-md px-3 py-2 text-sm focus:outline-none focus:border-nexus-signal resize-none"
              />
              {cases.length > 1 && (
                <button
                  type="button"
                  onClick={() => setCases((prev) => prev.filter((_, idx) => idx !== i))}
                  className="text-nexus-muted hover:text-red-400 text-sm px-1"
                >
                  ×
                </button>
              )}
            </div>
            <input
              value={c.expected_answer || ""}
              onChange={(e) => updateCase(i, { expected_answer: e.target.value })}
              placeholder="Reference answer (optional — enables accuracy scoring)"
              className="w-full ml-7 bg-nexus-bg border border-nexus-border rounded-md px-3 py-1.5 text-xs focus:outline-none focus:border-nexus-signal"
            />
            <select
              value={c.expected_document_id || ""}
              onChange={(e) =>
                updateCase(i, { expected_document_id: e.target.value || undefined })
              }
              className="w-full ml-7 bg-nexus-bg border border-nexus-border rounded-md px-3 py-1.5 text-xs focus:outline-none focus:border-nexus-signal"
            >
              <option value="">No expected document (skip retrieval scoring)</option>
              {documents.map((d) => (
                <option key={d.id} value={d.id}>
                  Expect retrieval from: {d.filename}
                </option>
              ))}
            </select>
          </div>
        ))}
        <button
          type="button"
          onClick={() => setCases((prev) => [...prev, { question: "" }])}
          className="text-xs text-nexus-signal hover:underline"
        >
          + Add case
        </button>
      </div>

      <button
        type="submit"
        disabled={submitting}
        className="w-full py-2.5 rounded-md bg-nexus-signal text-nexus-bg font-medium text-sm hover:opacity-90 transition disabled:opacity-50"
      >
        {submitting ? "Creating…" : "Create dataset"}
      </button>
    </form>
  );
}

function DatasetCard({
  dataset,
  onDeleted,
  onViewRun,
}: {
  dataset: EvalDataset;
  onDeleted: () => void;
  onViewRun: (run: EvalRunDetail) => void;
}) {
  const { authFetch } = useAuth();
  const [running, setRunning] = useState(false);
  const [runs, setRuns] = useState<EvalRun[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function loadRuns() {
    setRuns(await listEvalRuns(authFetch, dataset.id));
  }

  async function handleRun() {
    setRunning(true);
    setError(null);
    try {
      await runEvalDataset(authFetch, dataset.id);
      await loadRuns();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setRunning(false);
    }
  }

  async function handleDelete() {
    await deleteEvalDataset(authFetch, dataset.id);
    onDeleted();
  }

  async function handleViewRun(runId: string) {
    onViewRun(await getEvalRun(authFetch, runId));
  }

  return (
    <div className="bg-nexus-surface border border-nexus-border rounded-lg p-4">
      <div className="flex items-start justify-between gap-3">
        <div>
          <span className="font-medium text-sm">{dataset.name}</span>
          {dataset.description && (
            <p className="text-xs text-nexus-muted mt-0.5">{dataset.description}</p>
          )}
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={handleRun}
            disabled={running}
            className="text-xs px-2.5 py-1 rounded-md border border-nexus-border hover:border-nexus-signal transition disabled:opacity-50"
          >
            {running ? "Running…" : "Run evaluation"}
          </button>
          <button
            onClick={handleDelete}
            className="text-xs text-nexus-muted hover:text-red-400 transition"
          >
            Delete
          </button>
        </div>
      </div>

      {error && <p className="text-xs text-red-400 mt-2">{error}</p>}

      <button
        onClick={() => (runs ? setRuns(null) : loadRuns())}
        className="text-[11px] text-nexus-signal hover:underline mt-2"
      >
        {runs ? "Hide runs" : "Show past runs"}
      </button>

      {runs && (
        <div className="mt-2 space-y-1 border-t border-nexus-border pt-2">
          {runs.length === 0 && <p className="text-xs text-nexus-muted">No runs yet.</p>}
          {runs.map((r) => (
            <button
              key={r.id}
              onClick={() => handleViewRun(r.id)}
              className="w-full flex items-center justify-between text-xs hover:bg-nexus-bg rounded px-1 py-0.5 transition"
            >
              <span
                className={
                  r.status === "success"
                    ? "text-nexus-signal"
                    : r.status === "failed"
                    ? "text-red-400"
                    : "text-nexus-alert"
                }
              >
                {r.status}
              </span>
              <span className="text-nexus-muted">
                {r.avg_accuracy != null ? `acc ${r.avg_accuracy.toFixed(2)}` : ""}
              </span>
              <span className="text-nexus-muted">
                {new Date(r.started_at).toLocaleString()}
              </span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function RunDetailView({ run, onBack }: { run: EvalRunDetail; onBack: () => void }) {
  const dims = (
    [
      { label: "Accuracy", value: run.avg_accuracy },
      { label: "Relevance", value: run.avg_relevance },
      { label: "Faithfulness", value: run.avg_faithfulness },
      { label: "Quality", value: run.avg_response_quality },
      { label: "Retr. precision", value: run.avg_retrieval_precision },
      { label: "Retr. recall", value: run.avg_retrieval_recall },
    ] as { label: string; value: number | null }[]
  ).filter((d): d is { label: string; value: number } => d.value != null);

  const chartData = dims.map((d) => ({ name: d.label, score: Math.round(d.value * 100) }));

  return (
    <div className="mt-4">
      <button onClick={onBack} className="text-xs text-nexus-signal hover:underline mb-3">
        ← Back to datasets
      </button>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-4">
        <StatCard
          label="Hallucination rate"
          value={
            run.hallucination_rate != null ? `${Math.round(run.hallucination_rate * 100)}%` : "—"
          }
        />
        <StatCard
          label="Avg latency"
          value={run.avg_latency_ms ? `${Math.round(run.avg_latency_ms)}ms` : "—"}
        />
        <StatCard
          label="Tokens"
          value={(run.total_input_tokens + run.total_output_tokens).toLocaleString()}
        />
        <StatCard label="Total cost" value={`$${run.total_cost_usd.toFixed(4)}`} />
      </div>

      {chartData.length > 0 && (
        <div className="bg-nexus-surface border border-nexus-border rounded-lg p-3 h-48 mb-4">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1E2730" />
              <XAxis dataKey="name" tick={{ fontSize: 10, fill: "#7C8894" }} />
              <YAxis domain={[0, 100]} tick={{ fontSize: 10, fill: "#7C8894" }} width={30} />
              <Tooltip
                contentStyle={{ background: "#10151B", border: "1px solid #1E2730", fontSize: 12 }}
                formatter={(value: number) => [`${value}/100`, "Score"]}
              />
              <Bar dataKey="score" fill="#2DD4BF" radius={[3, 3, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      )}

      <div className="space-y-2">
        {run.results.map((r) => (
          <ResultRow key={r.id} result={r} />
        ))}
      </div>
    </div>
  );
}

function ResultRow({ result }: { result: EvalRunDetail["results"][number] }) {
  const [expanded, setExpanded] = useState(false);
  return (
    <div className="bg-nexus-surface border border-nexus-border rounded-lg p-3">
      <button
        onClick={() => setExpanded((v) => !v)}
        className="w-full text-left flex items-start justify-between gap-3"
      >
        <span className="text-sm truncate">{result.question}</span>
        <div className="flex items-center gap-2 shrink-0 text-xs">
          {result.hallucinated && <span className="text-red-400 font-mono">hallucination</span>}
          {result.accuracy != null && (
            <span className="text-nexus-muted font-mono">acc {result.accuracy.toFixed(2)}</span>
          )}
        </div>
      </button>
      {expanded && (
        <div className="mt-2 pt-2 border-t border-nexus-border text-xs space-y-1.5">
          <p className="text-nexus-text whitespace-pre-wrap">{result.generated_answer}</p>
          {result.judge_rationale && (
            <p className="text-nexus-muted italic">"{result.judge_rationale}"</p>
          )}
          <div className="flex flex-wrap gap-x-3 gap-y-1 text-nexus-muted font-mono">
            <span>relevance {result.relevance?.toFixed(2) ?? "—"}</span>
            <span>faithfulness {result.faithfulness?.toFixed(2) ?? "—"}</span>
            <span>quality {result.response_quality?.toFixed(2) ?? "—"}</span>
            {result.retrieval_precision != null && (
              <span>retr. precision {result.retrieval_precision.toFixed(2)}</span>
            )}
            <span>{Math.round(result.latency_ms)}ms</span>
            <span>${result.cost_usd.toFixed(5)}</span>
          </div>
        </div>
      )}
    </div>
  );
}
