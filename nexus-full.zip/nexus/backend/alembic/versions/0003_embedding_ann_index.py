"""ANN index on document_chunks.embedding

Revision ID: 0003
Revises: 0002
Create Date: 2026-08-09

"""
from alembic import op

revision = "0003"
down_revision = "0002"
branch_labels = None
depends_on = None

# HNSW over ivfflat: ivfflat's cluster centroids are trained from
# whatever rows exist at CREATE INDEX time, so quality depends on the
# table already being populated — awkward in a migration that typically
# runs before any documents are uploaded. HNSW builds incrementally and
# needs no training step, so it performs well from an empty table onward.
# Requires pgvector extension >= 0.5.0 (the pgvector/pgvector:pg16 Docker
# image used in docker-compose.yml ships a recent enough version).
INDEX_NAME = "ix_document_chunks_embedding_hnsw"


def upgrade() -> None:
    op.execute(
        f"""
        CREATE INDEX {INDEX_NAME}
        ON document_chunks
        USING hnsw (embedding vector_cosine_ops)
        WITH (m = 16, ef_construction = 64)
        """
    )


def downgrade() -> None:
    op.execute(f"DROP INDEX IF EXISTS {INDEX_NAME}")
