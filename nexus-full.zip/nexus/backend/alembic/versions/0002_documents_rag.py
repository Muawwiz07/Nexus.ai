"""documents and RAG

Revision ID: 0002
Revises: 0001
Create Date: 2026-08-09

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql
from pgvector.sqlalchemy import Vector

revision = "0002"
down_revision = "0001"
branch_labels = None
depends_on = None

# Must match Settings.embedding_dimensions (app/config.py) for whichever
# EMBEDDING_PROVIDER is active. Default is OpenAI text-embedding-3-small
# (1536). Switching to Voyage (1024) requires changing this and re-running
# a fresh migration — the column width can't be altered in place once rows
# with a different dimensionality exist.
EMBEDDING_DIM = 1536


def upgrade() -> None:
    op.add_column(
        "conversations",
        sa.Column("rag_enabled", sa.Boolean, server_default=sa.true(), nullable=False),
    )

    op.create_table(
        "documents",
        sa.Column("id", postgresql.UUID(as_uuid=False), primary_key=True),
        sa.Column(
            "user_id", postgresql.UUID(as_uuid=False), sa.ForeignKey("users.id"), nullable=False
        ),
        sa.Column("filename", sa.String, nullable=False),
        sa.Column("content_type", sa.String, nullable=False),
        sa.Column("file_path", sa.String, nullable=False),
        sa.Column("status", sa.String, server_default="processing"),
        sa.Column("error_message", sa.String, nullable=True),
        sa.Column("chunk_count", sa.Integer, server_default="0"),
        sa.Column("created_at", sa.DateTime(timezone=True)),
    )
    op.create_index("ix_documents_user_id", "documents", ["user_id"])

    op.create_table(
        "document_chunks",
        sa.Column("id", postgresql.UUID(as_uuid=False), primary_key=True),
        sa.Column(
            "document_id",
            postgresql.UUID(as_uuid=False),
            sa.ForeignKey("documents.id"),
            nullable=False,
        ),
        sa.Column("chunk_index", sa.Integer, nullable=False),
        sa.Column("content", sa.Text, nullable=False),
        sa.Column("page_number", sa.Integer, nullable=True),
        sa.Column("embedding", Vector(EMBEDDING_DIM), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True)),
    )
    op.create_index("ix_document_chunks_document_id", "document_chunks", ["document_id"])

    # The ANN index on `embedding` itself is added in migration 0003
    # (HNSW, not ivfflat — see that file for why).


def downgrade() -> None:
    op.drop_index("ix_document_chunks_document_id", table_name="document_chunks")
    op.drop_table("document_chunks")
    op.drop_index("ix_documents_user_id", table_name="documents")
    op.drop_table("documents")
    op.drop_column("conversations", "rag_enabled")
