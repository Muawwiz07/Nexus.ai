"""agents, tools, and memory

Revision ID: 0004
Revises: 0003
Create Date: 2026-08-09

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql
from pgvector.sqlalchemy import Vector

revision = "0004"
down_revision = "0003"
branch_labels = None
depends_on = None

# Must match Settings.embedding_dimensions — same rule as document_chunks
# in migration 0002.
EMBEDDING_DIM = 1536


def upgrade() -> None:
    op.add_column("messages", sa.Column("agent_key", sa.String, nullable=True))
    op.add_column("messages", sa.Column("tool_trace", sa.Text, nullable=True))

    op.create_table(
        "tasks",
        sa.Column("id", postgresql.UUID(as_uuid=False), primary_key=True),
        sa.Column(
            "user_id", postgresql.UUID(as_uuid=False), sa.ForeignKey("users.id"), nullable=False
        ),
        sa.Column("title", sa.String, nullable=False),
        sa.Column("description", sa.Text, nullable=True),
        sa.Column("status", sa.String, server_default="open"),
        sa.Column("due_date", sa.DateTime(timezone=True), nullable=True),
        sa.Column("source", sa.String, server_default="user"),
        sa.Column("created_at", sa.DateTime(timezone=True)),
    )
    op.create_index("ix_tasks_user_id", "tasks", ["user_id"])

    op.create_table(
        "reports",
        sa.Column("id", postgresql.UUID(as_uuid=False), primary_key=True),
        sa.Column(
            "user_id", postgresql.UUID(as_uuid=False), sa.ForeignKey("users.id"), nullable=False
        ),
        sa.Column("title", sa.String, nullable=False),
        sa.Column("content", sa.Text, nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True)),
    )
    op.create_index("ix_reports_user_id", "reports", ["user_id"])

    op.create_table(
        "notification_logs",
        sa.Column("id", postgresql.UUID(as_uuid=False), primary_key=True),
        sa.Column(
            "user_id", postgresql.UUID(as_uuid=False), sa.ForeignKey("users.id"), nullable=False
        ),
        sa.Column("recipient", sa.String, nullable=False),
        sa.Column("subject", sa.String, nullable=True),
        sa.Column("message", sa.Text, nullable=False),
        sa.Column("status", sa.String, server_default="sent"),
        sa.Column("created_at", sa.DateTime(timezone=True)),
    )
    op.create_index("ix_notification_logs_user_id", "notification_logs", ["user_id"])

    op.create_table(
        "memory_entries",
        sa.Column("id", postgresql.UUID(as_uuid=False), primary_key=True),
        sa.Column(
            "user_id", postgresql.UUID(as_uuid=False), sa.ForeignKey("users.id"), nullable=False
        ),
        sa.Column("content", sa.Text, nullable=False),
        sa.Column("embedding", Vector(EMBEDDING_DIM), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True)),
    )
    op.create_index("ix_memory_entries_user_id", "memory_entries", ["user_id"])
    op.execute(
        """
        CREATE INDEX ix_memory_entries_embedding_hnsw
        ON memory_entries
        USING hnsw (embedding vector_cosine_ops)
        WITH (m = 16, ef_construction = 64)
        """
    )


def downgrade() -> None:
    op.execute("DROP INDEX IF EXISTS ix_memory_entries_embedding_hnsw")
    op.drop_index("ix_memory_entries_user_id", table_name="memory_entries")
    op.drop_table("memory_entries")

    op.drop_index("ix_notification_logs_user_id", table_name="notification_logs")
    op.drop_table("notification_logs")

    op.drop_index("ix_reports_user_id", table_name="reports")
    op.drop_table("reports")

    op.drop_index("ix_tasks_user_id", table_name="tasks")
    op.drop_table("tasks")

    op.drop_column("messages", "tool_trace")
    op.drop_column("messages", "agent_key")
