"""evaluation and telemetry

Revision ID: 0006
Revises: 0005
Create Date: 2026-08-10

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = "0006"
down_revision = "0005"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "request_logs",
        sa.Column("id", postgresql.UUID(as_uuid=False), primary_key=True),
        sa.Column(
            "user_id", postgresql.UUID(as_uuid=False), sa.ForeignKey("users.id"), nullable=False
        ),
        sa.Column(
            "conversation_id",
            postgresql.UUID(as_uuid=False),
            sa.ForeignKey("conversations.id"),
            nullable=True,
        ),
        sa.Column(
            "workflow_run_id",
            postgresql.UUID(as_uuid=False),
            sa.ForeignKey("workflow_runs.id"),
            nullable=True,
        ),
        sa.Column("kind", sa.String, nullable=False),
        sa.Column("provider", sa.String, nullable=False),
        sa.Column("model", sa.String, nullable=False),
        sa.Column("input_tokens", sa.Integer, server_default="0"),
        sa.Column("output_tokens", sa.Integer, server_default="0"),
        sa.Column("latency_ms", sa.Float, server_default="0"),
        sa.Column("cost_usd", sa.Float, server_default="0"),
        sa.Column("api_calls", sa.Integer, server_default="1"),
        sa.Column("created_at", sa.DateTime(timezone=True)),
    )
    op.create_index("ix_request_logs_user_id", "request_logs", ["user_id"])
    op.create_index("ix_request_logs_created_at", "request_logs", ["created_at"])

    op.create_table(
        "eval_datasets",
        sa.Column("id", postgresql.UUID(as_uuid=False), primary_key=True),
        sa.Column(
            "user_id", postgresql.UUID(as_uuid=False), sa.ForeignKey("users.id"), nullable=False
        ),
        sa.Column("name", sa.String, nullable=False),
        sa.Column("description", sa.Text, nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True)),
    )
    op.create_index("ix_eval_datasets_user_id", "eval_datasets", ["user_id"])

    op.create_table(
        "eval_cases",
        sa.Column("id", postgresql.UUID(as_uuid=False), primary_key=True),
        sa.Column(
            "dataset_id",
            postgresql.UUID(as_uuid=False),
            sa.ForeignKey("eval_datasets.id"),
            nullable=False,
        ),
        sa.Column("question", sa.Text, nullable=False),
        sa.Column("expected_answer", sa.Text, nullable=True),
        sa.Column(
            "expected_document_id",
            postgresql.UUID(as_uuid=False),
            sa.ForeignKey("documents.id"),
            nullable=True,
        ),
        sa.Column("created_at", sa.DateTime(timezone=True)),
    )
    op.create_index("ix_eval_cases_dataset_id", "eval_cases", ["dataset_id"])

    op.create_table(
        "eval_runs",
        sa.Column("id", postgresql.UUID(as_uuid=False), primary_key=True),
        sa.Column(
            "dataset_id",
            postgresql.UUID(as_uuid=False),
            sa.ForeignKey("eval_datasets.id"),
            nullable=False,
        ),
        sa.Column(
            "user_id", postgresql.UUID(as_uuid=False), sa.ForeignKey("users.id"), nullable=False
        ),
        sa.Column("status", sa.String, server_default="running"),
        sa.Column("error_message", sa.Text, nullable=True),
        sa.Column("avg_accuracy", sa.Float, nullable=True),
        sa.Column("avg_relevance", sa.Float, nullable=True),
        sa.Column("avg_faithfulness", sa.Float, nullable=True),
        sa.Column("avg_response_quality", sa.Float, nullable=True),
        sa.Column("avg_retrieval_precision", sa.Float, nullable=True),
        sa.Column("avg_retrieval_recall", sa.Float, nullable=True),
        sa.Column("hallucination_rate", sa.Float, nullable=True),
        sa.Column("avg_latency_ms", sa.Float, nullable=True),
        sa.Column("total_input_tokens", sa.Integer, server_default="0"),
        sa.Column("total_output_tokens", sa.Integer, server_default="0"),
        sa.Column("total_cost_usd", sa.Float, server_default="0"),
        sa.Column("started_at", sa.DateTime(timezone=True)),
        sa.Column("finished_at", sa.DateTime(timezone=True), nullable=True),
    )
    op.create_index("ix_eval_runs_dataset_id", "eval_runs", ["dataset_id"])
    op.create_index("ix_eval_runs_user_id", "eval_runs", ["user_id"])

    op.create_table(
        "eval_results",
        sa.Column("id", postgresql.UUID(as_uuid=False), primary_key=True),
        sa.Column(
            "eval_run_id",
            postgresql.UUID(as_uuid=False),
            sa.ForeignKey("eval_runs.id"),
            nullable=False,
        ),
        sa.Column(
            "case_id",
            postgresql.UUID(as_uuid=False),
            sa.ForeignKey("eval_cases.id"),
            nullable=False,
        ),
        sa.Column("question", sa.Text, nullable=False),
        sa.Column("generated_answer", sa.Text, nullable=False),
        sa.Column("accuracy", sa.Float, nullable=True),
        sa.Column("relevance", sa.Float, nullable=True),
        sa.Column("faithfulness", sa.Float, nullable=True),
        sa.Column("response_quality", sa.Float, nullable=True),
        sa.Column("hallucinated", sa.Boolean, nullable=True),
        sa.Column("judge_rationale", sa.Text, nullable=True),
        sa.Column("retrieval_precision", sa.Float, nullable=True),
        sa.Column("retrieval_recall", sa.Float, nullable=True),
        sa.Column("latency_ms", sa.Float, server_default="0"),
        sa.Column("input_tokens", sa.Integer, server_default="0"),
        sa.Column("output_tokens", sa.Integer, server_default="0"),
        sa.Column("cost_usd", sa.Float, server_default="0"),
        sa.Column("created_at", sa.DateTime(timezone=True)),
    )
    op.create_index("ix_eval_results_eval_run_id", "eval_results", ["eval_run_id"])


def downgrade() -> None:
    op.drop_index("ix_eval_results_eval_run_id", table_name="eval_results")
    op.drop_table("eval_results")

    op.drop_index("ix_eval_runs_user_id", table_name="eval_runs")
    op.drop_index("ix_eval_runs_dataset_id", table_name="eval_runs")
    op.drop_table("eval_runs")

    op.drop_index("ix_eval_cases_dataset_id", table_name="eval_cases")
    op.drop_table("eval_cases")

    op.drop_index("ix_eval_datasets_user_id", table_name="eval_datasets")
    op.drop_table("eval_datasets")

    op.drop_index("ix_request_logs_created_at", table_name="request_logs")
    op.drop_index("ix_request_logs_user_id", table_name="request_logs")
    op.drop_table("request_logs")
