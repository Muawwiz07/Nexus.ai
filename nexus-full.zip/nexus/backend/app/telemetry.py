"""
Usage tracking for latency/cost/token metrics (Phase 5 — Evaluation).

Rather than changing every provider method's return type to carry usage
data back up through execute_agentic_step → run_agent_turn → the chat
router (a ripple through Phase 3/4 code that already works), this uses a
contextvar as a lightweight, per-async-task accumulator: start tracking
once at the top of a turn, let provider code record each individual API
call as it happens (including every round of a multi-tool-call loop),
then read the total back out at the end. Same pattern OpenTelemetry spans
use for exactly this reason.

Safe by construction: if `start_usage_tracking` was never called,
`record_api_call` is a no-op rather than raising, so provider code can
always call it unconditionally without needing to know whether anyone's
listening.
"""
import time
from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import dataclass, field


@dataclass
class UsageAccumulator:
    provider: str = ""
    model: str = ""
    input_tokens: int = 0
    output_tokens: int = 0
    latency_ms: float = 0.0
    api_calls: int = 0


_current: ContextVar[UsageAccumulator | None] = ContextVar("usage_accumulator", default=None)


def start_usage_tracking(provider: str, model: str) -> UsageAccumulator:
    acc = UsageAccumulator(provider=provider, model=model)
    _current.set(acc)
    return acc


def stop_usage_tracking() -> None:
    _current.set(None)


def record_api_call(input_tokens: int, output_tokens: int, latency_ms: float) -> None:
    acc = _current.get()
    if acc is None:
        return
    acc.input_tokens += input_tokens
    acc.output_tokens += output_tokens
    acc.latency_ms += latency_ms
    acc.api_calls += 1


def get_current_usage() -> UsageAccumulator | None:
    return _current.get()


@contextmanager
def timed_call():
    """`with timed_call() as t: ... ; t.ms` — elapsed wall time in ms."""

    class _Timer:
        ms: float = 0.0

    t = _Timer()
    start = time.perf_counter()
    try:
        yield t
    finally:
        t.ms = (time.perf_counter() - start) * 1000
