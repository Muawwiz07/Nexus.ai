import os
import uuid

from fastapi import APIRouter, Depends, HTTPException, UploadFile
from sqlalchemy.orm import Session

from app.auth import get_current_user
from app.config import settings
from app.database import get_db
from app.embeddings.factory import get_embedding_provider
from app.models import Document, DocumentChunk, User
from app.schemas import DocumentOut
from app.services.chunking import chunk_pages
from app.services.parsing import UnsupportedFileType, extract_pages

router = APIRouter(prefix="/api/documents", tags=["documents"])

ALLOWED_TYPES = {
    "application/pdf",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "text/plain",
}


@router.get("", response_model=list[DocumentOut])
def list_documents(
    current_user: User = Depends(get_current_user), db: Session = Depends(get_db)
):
    return (
        db.query(Document)
        .filter(Document.user_id == current_user.id)
        .order_by(Document.created_at.desc())
        .all()
    )


@router.post("/upload", response_model=DocumentOut)
async def upload_document(
    file: UploadFile,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    if file.content_type not in ALLOWED_TYPES:
        raise HTTPException(
            status_code=400,
            detail="Only PDF, DOCX, and TXT files are supported.",
        )

    contents = await file.read()
    if len(contents) > settings.max_upload_mb * 1024 * 1024:
        raise HTTPException(
            status_code=400, detail=f"File exceeds {settings.max_upload_mb}MB limit."
        )

    user_dir = os.path.join(settings.upload_dir, current_user.id)
    os.makedirs(user_dir, exist_ok=True)
    doc_id = str(uuid.uuid4())
    stored_name = f"{doc_id}_{file.filename}"
    file_path = os.path.join(user_dir, stored_name)
    with open(file_path, "wb") as f:
        f.write(contents)

    document = Document(
        id=doc_id,
        user_id=current_user.id,
        filename=file.filename,
        content_type=file.content_type,
        file_path=file_path,
        status="processing",
    )
    db.add(document)
    db.commit()
    db.refresh(document)

    # Processed inline (synchronously) for Phase 2 — fine at demo scale.
    # A production system would push this to a background worker/queue
    # (Celery, arq, or an AWS SQS-backed consumer) so upload requests
    # return immediately regardless of document size.
    try:
        pages = extract_pages(file_path, file.content_type)
        chunks = chunk_pages(pages)
        if not chunks:
            raise ValueError("No extractable text found in document.")

        provider = get_embedding_provider()
        batch_size = 64
        all_vectors: list[list[float]] = []
        for i in range(0, len(chunks), batch_size):
            batch = [c.content for c in chunks[i : i + batch_size]]
            all_vectors.extend(await provider.embed(batch))

        for idx, (chunk, vector) in enumerate(zip(chunks, all_vectors)):
            db.add(
                DocumentChunk(
                    document_id=document.id,
                    chunk_index=idx,
                    content=chunk.content,
                    page_number=chunk.page_number,
                    embedding=vector,
                )
            )

        document.status = "ready"
        document.chunk_count = len(chunks)
        db.commit()
        db.refresh(document)

    except UnsupportedFileType as e:
        document.status = "failed"
        document.error_message = str(e)
        db.commit()
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:  # noqa: BLE001 — surface any parse/embed failure to the user
        document.status = "failed"
        document.error_message = str(e)
        db.commit()
        raise HTTPException(status_code=500, detail=f"Processing failed: {e}")

    return document


@router.delete("/{document_id}", status_code=204)
def delete_document(
    document_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    doc = (
        db.query(Document)
        .filter(Document.id == document_id, Document.user_id == current_user.id)
        .first()
    )
    if not doc:
        raise HTTPException(status_code=404, detail="Document not found")

    if os.path.exists(doc.file_path):
        os.remove(doc.file_path)
    db.delete(doc)
    db.commit()
