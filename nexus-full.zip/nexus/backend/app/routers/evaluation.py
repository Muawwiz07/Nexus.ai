from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from app.auth import get_current_user
from app.database import get_db
from app.evaluation.executor import run_evaluation
from app.models import EvalCase, EvalDataset, EvalRun, RequestLog, User
from app.schemas import (
    EvalDatasetCreate,
    EvalDatasetDetail,
    EvalDatasetOut,
    EvalRunDetail,
    EvalRunOut,
    TelemetryPointOut,
    TelemetrySummaryOut,
)

router = APIRouter(prefix="/api/eval", tags=["evaluation"])


def _to_dataset_detail(ds: EvalDataset) -> EvalDatasetDetail:
    return EvalDatasetDetail(
        id=ds.id,
        name=ds.name,
        description=ds.description,
        created_at=ds.created_at,
        cases=[
            {
                "id": c.id,
                "question": c.question,
                "expected_answer": c.expected_answer,
                "expected_document_id": c.expected_document_id,
            }
            for c in ds.cases
        ],
    )


@router.get("/datasets", response_model=list[EvalDatasetOut])
def list_datasets(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    return (
        db.query(EvalDataset)
        .filter(EvalDataset.user_id == current_user.id)
        .order_by(EvalDataset.created_at.desc())
        .all()
    )


@router.post("/datasets", response_model=EvalDatasetDetail, status_code=201)
def create_dataset(
    payload: EvalDatasetCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    if not payload.cases:
        raise HTTPException(status_code=400, detail="At least one test case is required")

    ds = EvalDataset(user_id=current_user.id, name=payload.name, description=payload.description)
    db.add(ds)
    db.commit()
    db.refresh(ds)

    for case in payload.cases:
        db.add(
            EvalCase(
                dataset_id=ds.id,
                question=case.question,
                expected_answer=case.expected_answer,
                expected_document_id=case.expected_document_id,
            )
        )
    db.commit()
    db.refresh(ds)
    return _to_dataset_detail(ds)


@router.get("/datasets/{dataset_id}", response_model=EvalDatasetDetail)
def get_dataset(
    dataset_id: str, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)
):
    ds = (
        db.query(EvalDataset)
        .filter(EvalDataset.id == dataset_id, EvalDataset.user_id == current_user.id)
        .first()
    )
    if not ds:
        raise HTTPException(status_code=404, detail="Dataset not found")
    return _to_dataset_detail(ds)


@router.delete("/datasets/{dataset_id}", status_code=204)
def delete_dataset(
    dataset_id: str, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)
):
    ds = (
        db.query(EvalDataset)
        .filter(EvalDataset.id == dataset_id, EvalDataset.user_id == current_user.id)
        .first()
    )
    if not ds:
        raise HTTPException(status_code=404, detail="Dataset not found")
    db.delete(ds)
    db.commit()


@router.post("/datasets/{dataset_id}/run", response_model=EvalRunOut)
async def run_dataset(
    dataset_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Runs every case in the dataset through the real agent pipeline
    synchronously and returns once scored. Fine for the dataset sizes a
    demo/portfolio project deals with (tens of cases); a dataset large
    enough to take minutes would want this moved to a background task
    with a polling or websocket status endpoint instead.
    """
    ds = (
        db.query(EvalDataset)
        .filter(EvalDataset.id == dataset_id, EvalDataset.user_id == current_user.id)
        .first()
    )
    if not ds:
        raise HTTPException(status_code=404, detail="Dataset not found")

    run = await run_evaluation(db, ds.id, current_user)
    if run is None:
        raise HTTPException(status_code=400, detail="Dataset has no test cases to run.")
    return run


@router.get("/datasets/{dataset_id}/runs", response_model=list[EvalRunOut])
def list_runs_for_dataset(
    dataset_id: str, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)
):
    ds = (
        db.query(EvalDataset)
        .filter(EvalDataset.id == dataset_id, EvalDataset.user_id == current_user.id)
        .first()
    )
    if not ds:
        raise HTTPException(status_code=404, detail="Dataset not found")
    return (
        db.query(EvalRun)
        .filter(EvalRun.dataset_id == ds.id)
        .order_by(EvalRun.started_at.desc())
        .limit(20)
        .all()
    )


@router.get("/runs/{run_id}", response_model=EvalRunDetail)
def get_run(
    run_id: str, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)
):
    run = (
        db.query(EvalRun)
        .filter(EvalRun.id == run_id, EvalRun.user_id == current_user.id)
        .first()
    )
    if not run:
        raise HTTPException(status_code=404, detail="Eval run not found")
    return run


# ---- Telemetry (production traffic, independent of eval datasets) ----


@router.get("/telemetry/summary", response_model=TelemetrySummaryOut)
def telemetry_summary(
    days: int = Query(default=7, ge=1, le=90),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Aggregates RequestLog — every real chat turn and workflow step,
    tagged by kind. Eval-run answering calls are included in totals but
    broken out in `by_kind`, so they're visible rather than silently
    mixed in or silently excluded.
    """
    since = datetime.now(timezone.utc) - timedelta(days=days)
    rows = (
        db.query(RequestLog)
        .filter(RequestLog.user_id == current_user.id, RequestLog.created_at >= since)
        .all()
    )

    by_kind: dict[str, int] = {}
    for r in rows:
        by_kind[r.kind] = by_kind.get(r.kind, 0) + 1

    return TelemetrySummaryOut(
        window_days=days,
        total_requests=len(rows),
        total_input_tokens=sum(r.input_tokens for r in rows),
        total_output_tokens=sum(r.output_tokens for r in rows),
        total_cost_usd=sum(r.cost_usd for r in rows),
        avg_latency_ms=(sum(r.latency_ms for r in rows) / len(rows)) if rows else None,
        by_kind=by_kind,
    )


@router.get("/telemetry/points", response_model=list[TelemetryPointOut])
def telemetry_points(
    days: int = Query(default=7, ge=1, le=90),
    limit: int = Query(default=200, ge=1, le=1000),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Raw recent rows for charting latency/cost over time — deliberately
    unaggregated so the frontend can plot a real trend line."""
    since = datetime.now(timezone.utc) - timedelta(days=days)
    return (
        db.query(RequestLog)
        .filter(RequestLog.user_id == current_user.id, RequestLog.created_at >= since)
        .order_by(RequestLog.created_at.desc())
        .limit(limit)
        .all()
    )
