import json

from apscheduler.triggers.cron import CronTrigger
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.auth import get_current_user
from app.automation.executor import run_workflow
from app.database import get_db
from app.models import User, Workflow, WorkflowRun, WorkflowStep
from app.scheduler import schedule_workflow, unschedule_workflow
from app.schemas import (
    ToolInfoOut,
    WorkflowCreate,
    WorkflowDetail,
    WorkflowOut,
    WorkflowRunOut,
    WorkflowStepOut,
    WorkflowUpdate,
)
from app.tools import TOOL_REGISTRY

router = APIRouter(prefix="/api/workflows", tags=["workflows"])


def _validate_cron(expr: str) -> None:
    try:
        CronTrigger.from_crontab(expr)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=f"Invalid cron expression: {e}")


def _validate_tool_names(names: list[str]) -> None:
    unknown = [n for n in names if n not in TOOL_REGISTRY]
    if unknown:
        raise HTTPException(status_code=400, detail=f"Unknown tools: {unknown}")


def _to_out(wf: Workflow) -> WorkflowOut:
    return WorkflowOut(
        id=wf.id,
        name=wf.name,
        description=wf.description,
        cron_expression=wf.cron_expression,
        enabled=wf.enabled,
        llm_provider=wf.llm_provider,
        tool_names=json.loads(wf.tool_names),
        last_run_at=wf.last_run_at,
        created_at=wf.created_at,
    )


def _to_detail(wf: Workflow) -> WorkflowDetail:
    base = _to_out(wf)
    return WorkflowDetail(
        **base.model_dump(),
        system_prompt=wf.system_prompt,
        steps=[WorkflowStepOut.model_validate(s) for s in wf.steps],
    )


# Static path registered before the dynamic /{workflow_id} route below so
# FastAPI doesn't try to parse "meta" as a workflow id.
@router.get("/meta/tools", response_model=list[ToolInfoOut])
def list_available_tools(current_user: User = Depends(get_current_user)):
    return [ToolInfoOut(name=t.name, description=t.description) for t in TOOL_REGISTRY.values()]


@router.get("", response_model=list[WorkflowOut])
def list_workflows(
    current_user: User = Depends(get_current_user), db: Session = Depends(get_db)
):
    workflows = (
        db.query(Workflow)
        .filter(Workflow.user_id == current_user.id)
        .order_by(Workflow.created_at.desc())
        .all()
    )
    return [_to_out(w) for w in workflows]


@router.post("", response_model=WorkflowDetail, status_code=201)
def create_workflow(
    payload: WorkflowCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    _validate_cron(payload.cron_expression)
    _validate_tool_names(payload.tool_names)
    if not payload.steps:
        raise HTTPException(status_code=400, detail="At least one step is required")

    wf = Workflow(
        user_id=current_user.id,
        name=payload.name,
        description=payload.description,
        cron_expression=payload.cron_expression,
        enabled=payload.enabled,
        llm_provider=payload.llm_provider,
        system_prompt=payload.system_prompt,
        tool_names=json.dumps(payload.tool_names),
    )
    db.add(wf)
    db.commit()
    db.refresh(wf)

    for i, step in enumerate(payload.steps):
        db.add(WorkflowStep(workflow_id=wf.id, step_order=i, instruction=step.instruction))
    db.commit()
    db.refresh(wf)

    schedule_workflow(wf)
    return _to_detail(wf)


@router.get("/{workflow_id}", response_model=WorkflowDetail)
def get_workflow(
    workflow_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    wf = (
        db.query(Workflow)
        .filter(Workflow.id == workflow_id, Workflow.user_id == current_user.id)
        .first()
    )
    if not wf:
        raise HTTPException(status_code=404, detail="Workflow not found")
    return _to_detail(wf)


@router.put("/{workflow_id}", response_model=WorkflowDetail)
def update_workflow(
    workflow_id: str,
    payload: WorkflowUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    wf = (
        db.query(Workflow)
        .filter(Workflow.id == workflow_id, Workflow.user_id == current_user.id)
        .first()
    )
    if not wf:
        raise HTTPException(status_code=404, detail="Workflow not found")

    if payload.cron_expression is not None:
        _validate_cron(payload.cron_expression)
        wf.cron_expression = payload.cron_expression
    if payload.tool_names is not None:
        _validate_tool_names(payload.tool_names)
        wf.tool_names = json.dumps(payload.tool_names)
    if payload.name is not None:
        wf.name = payload.name
    if payload.description is not None:
        wf.description = payload.description
    if payload.enabled is not None:
        wf.enabled = payload.enabled
    if payload.llm_provider is not None:
        wf.llm_provider = payload.llm_provider
    if payload.system_prompt is not None:
        wf.system_prompt = payload.system_prompt

    if payload.steps is not None:
        if not payload.steps:
            raise HTTPException(status_code=400, detail="At least one step is required")
        db.query(WorkflowStep).filter(WorkflowStep.workflow_id == wf.id).delete()
        for i, step in enumerate(payload.steps):
            db.add(WorkflowStep(workflow_id=wf.id, step_order=i, instruction=step.instruction))

    db.commit()
    db.refresh(wf)

    # Re-sync the live scheduler job with whatever changed — cron,
    # enabled/disabled, or both — so an edit takes effect immediately
    # instead of waiting for the next backend restart.
    if wf.enabled:
        schedule_workflow(wf)
    else:
        unschedule_workflow(wf.id)

    return _to_detail(wf)


@router.delete("/{workflow_id}", status_code=204)
def delete_workflow(
    workflow_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    wf = (
        db.query(Workflow)
        .filter(Workflow.id == workflow_id, Workflow.user_id == current_user.id)
        .first()
    )
    if not wf:
        raise HTTPException(status_code=404, detail="Workflow not found")
    unschedule_workflow(wf.id)
    db.delete(wf)
    db.commit()


@router.post("/{workflow_id}/run-now", response_model=WorkflowRunOut)
async def run_now(
    workflow_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Triggers an immediate run outside the cron schedule — the fast
    path for demoing or testing a workflow without waiting for Monday."""
    wf = (
        db.query(Workflow)
        .filter(Workflow.id == workflow_id, Workflow.user_id == current_user.id)
        .first()
    )
    if not wf:
        raise HTTPException(status_code=404, detail="Workflow not found")

    run = await run_workflow(db, wf.id)
    if run is None:
        raise HTTPException(
            status_code=400,
            detail="Workflow could not run (disabled, or has no steps).",
        )
    return run


@router.get("/{workflow_id}/runs", response_model=list[WorkflowRunOut])
def list_runs(
    workflow_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    wf = (
        db.query(Workflow)
        .filter(Workflow.id == workflow_id, Workflow.user_id == current_user.id)
        .first()
    )
    if not wf:
        raise HTTPException(status_code=404, detail="Workflow not found")
    return (
        db.query(WorkflowRun)
        .filter(WorkflowRun.workflow_id == wf.id)
        .order_by(WorkflowRun.started_at.desc())
        .limit(20)
        .all()
    )
