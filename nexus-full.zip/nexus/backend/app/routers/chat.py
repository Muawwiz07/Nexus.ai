import asyncio
import json

from fastapi import APIRouter, Depends, HTTPException, WebSocket, WebSocketDisconnect
from sqlalchemy.orm import Session

from app.agents.executor import run_agent_turn
from app.auth import get_current_user, get_current_user_ws
from app.database import SessionLocal, get_db
from app.llm.factory import get_provider
from app.models import Conversation, Message, User
from app.schemas import ConversationDetail, ConversationOut

router = APIRouter(prefix="/api/chat", tags=["chat"])


@router.get("/conversations", response_model=list[ConversationOut])
def list_conversations(
    current_user: User = Depends(get_current_user), db: Session = Depends(get_db)
):
    return (
        db.query(Conversation)
        .filter(Conversation.user_id == current_user.id)
        .order_by(Conversation.created_at.desc())
        .all()
    )


@router.post("/conversations", response_model=ConversationOut)
def create_conversation(
    current_user: User = Depends(get_current_user), db: Session = Depends(get_db)
):
    conv = Conversation(user_id=current_user.id)
    db.add(conv)
    db.commit()
    db.refresh(conv)
    return conv


@router.get("/conversations/{conversation_id}", response_model=ConversationDetail)
def get_conversation(
    conversation_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    conv = (
        db.query(Conversation)
        .filter(Conversation.id == conversation_id, Conversation.user_id == current_user.id)
        .first()
    )
    if not conv:
        raise HTTPException(status_code=404, detail="Conversation not found")
    return conv


@router.websocket("/ws/{conversation_id}")
async def chat_ws(websocket: WebSocket, conversation_id: str):
    """
    Bidirectional chat stream. Client sends {"content": "..."} per turn.
    Server sends, in order, per turn:
      {"type": "routing", "agent": ..., "agent_label": ...}     — which agent picked this up
      {"type": "tool_call", "name": ..., "input": ...}          — zero or more, as the agent works
      {"type": "tool_result", "name": ..., "result": ...}
      {"type": "citations", "citations": [...]}                 — only if search_documents was used
      {"type": "delta", "content": "..."}                        — the final answer, chunked
      {"type": "done", "message_id": "..."}
    Auth token comes via ?token= query param since browsers can't set
    headers on the WS handshake.
    """
    db = SessionLocal()
    try:
        user = await get_current_user_ws(websocket, db)
        if not user:
            await websocket.close(code=4401)
            return

        conv = (
            db.query(Conversation)
            .filter(Conversation.id == conversation_id, Conversation.user_id == user.id)
            .first()
        )
        if not conv:
            await websocket.close(code=4404)
            return

        await websocket.accept()
        provider = get_provider(conv.llm_provider)

        while True:
            raw = await websocket.receive_text()
            payload = json.loads(raw)
            user_content = payload.get("content", "").strip()
            if not user_content:
                continue

            user_msg = Message(conversation_id=conv.id, role="user", content=user_content)
            db.add(user_msg)
            db.commit()

            history = [
                {"role": m.role, "content": m.content}
                for m in conv.messages
                if m.role in ("user", "assistant")
            ]

            final_text, trace, agent_key = await run_agent_turn(
                db, user, conv, provider, history, user_content, websocket
            )

            # Tool-calling turns run non-streaming — the model needs each
            # full response to decide whether to call another tool — so
            # once the final answer exists in full, it's chunked back over
            # the same `delta` protocol the frontend already expects. This
            # preserves the streaming UX without a second live API call
            # just to re-stream text that's already been generated.
            words = final_text.split(" ")
            for i in range(0, len(words), 3):
                piece = " ".join(words[i : i + 3])
                if i + 3 < len(words):
                    piece += " "
                await websocket.send_json({"type": "delta", "content": piece})
                await asyncio.sleep(0.02)

            assistant_msg = Message(
                conversation_id=conv.id,
                role="assistant",
                content=final_text,
                agent_key=agent_key,
                tool_trace=json.dumps(trace) if trace else None,
            )
            db.add(assistant_msg)

            if conv.title == "New conversation":
                conv.title = user_content[:60]

            db.commit()
            db.refresh(assistant_msg)

            await websocket.send_json({"type": "done", "message_id": assistant_msg.id})

    except WebSocketDisconnect:
        pass
    finally:
        db.close()
