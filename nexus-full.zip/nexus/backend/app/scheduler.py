"""
A single in-process APScheduler instance drives every workflow's cron
trigger. This is a deliberate simplification for a portfolio-scale
deployment: it needs no extra infrastructure (no Redis, no Celery
worker fleet) beyond what docker-compose.yml already runs, at the cost
of jobs living only as long as the backend process does and not
surviving a multi-instance horizontal scale-out. A production system
with real reliability requirements would move this to Celery Beat (or
AWS EventBridge + Lambda/ECS) so scheduling survives process restarts
and works across multiple backend replicas — see the README's Phase 4
notes.
"""
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger

from app.automation.executor import run_workflow
from app.database import SessionLocal
from app.models import Workflow

scheduler = AsyncIOScheduler(timezone="UTC")


def _job_id(workflow_id: str) -> str:
    return f"workflow:{workflow_id}"


async def _run_workflow_job(workflow_id: str) -> None:
    db = SessionLocal()
    try:
        await run_workflow(db, workflow_id)
    finally:
        db.close()


def schedule_workflow(workflow: Workflow) -> None:
    """(Re)schedules a workflow's job from its current cron_expression."""
    job_id = _job_id(workflow.id)
    if scheduler.get_job(job_id):
        scheduler.remove_job(job_id)
    if not workflow.enabled:
        return
    trigger = CronTrigger.from_crontab(workflow.cron_expression, timezone="UTC")
    scheduler.add_job(
        _run_workflow_job,
        trigger=trigger,
        id=job_id,
        args=[workflow.id],
        replace_existing=True,
        misfire_grace_time=3600,  # tolerate the process having been down for up to an hour
    )


def unschedule_workflow(workflow_id: str) -> None:
    job_id = _job_id(workflow_id)
    if scheduler.get_job(job_id):
        scheduler.remove_job(job_id)


def start_scheduler() -> None:
    """Called once on app startup: starts the scheduler and reconciles
    its jobs against every currently-enabled workflow in the database —
    so a backend restart doesn't lose track of what should be running."""
    if not scheduler.running:
        scheduler.start()

    db = SessionLocal()
    try:
        for wf in db.query(Workflow).filter(Workflow.enabled.is_(True)).all():
            schedule_workflow(wf)
    finally:
        db.close()


def stop_scheduler() -> None:
    if scheduler.running:
        scheduler.shutdown(wait=False)
