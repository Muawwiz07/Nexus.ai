from abc import ABC, abstractmethod


class EmbeddingProvider(ABC):
    """
    Same pluggability pattern as LLMProvider (app/llm/base.py) — swapping
    the embedding model should never touch retrieval or chunking code.
    Note: unlike chat, the embedding provider for a given deployment
    should stay fixed. Changing it changes the vector space, which
    silently breaks cosine similarity against chunks embedded by the old
    model — re-embed existing documents if you switch providers.
    """

    name: str
    dimensions: int

    @abstractmethod
    async def embed(self, texts: list[str]) -> list[list[float]]:
        """Embed a batch of texts, returning one vector per input."""
        ...

    async def embed_one(self, text: str) -> list[float]:
        return (await self.embed([text]))[0]
