import asyncio

import voyageai

from app.config import settings
from app.embeddings.base import EmbeddingProvider


class VoyageEmbeddingProvider(EmbeddingProvider):
    """
    Voyage AI — the embedding provider Anthropic recommends pairing with
    Claude for RAG, since Anthropic doesn't run its own embeddings
    endpoint. voyage-3's default output is 1024 dimensions, NOT 1536:
    if you switch to this provider, set EMBEDDING_DIMENSIONS=1024 in
    .env before running migrations, or the vector column width will be
    wrong for what this provider returns.
    """

    name = "voyage"
    dimensions = 1024  # voyage-3 default

    def __init__(self) -> None:
        self._client = voyageai.Client(api_key=settings.voyage_api_key)
        self._model = settings.voyage_model

    async def embed(self, texts: list[str]) -> list[list[float]]:
        # The voyageai SDK is synchronous; run it off the event loop thread
        # so it doesn't block other WebSocket connections mid-request.
        def _call():
            result = self._client.embed(texts, model=self._model, input_type="document")
            return result.embeddings

        return await asyncio.to_thread(_call)
