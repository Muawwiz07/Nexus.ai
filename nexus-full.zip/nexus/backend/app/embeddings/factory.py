from functools import lru_cache

from app.config import settings
from app.embeddings.base import EmbeddingProvider
from app.embeddings.openai_embeddings import OpenAIEmbeddingProvider
from app.embeddings.voyage_embeddings import VoyageEmbeddingProvider

_PROVIDERS: dict[str, type[EmbeddingProvider]] = {
    "openai": OpenAIEmbeddingProvider,
    "voyage": VoyageEmbeddingProvider,
}


@lru_cache(maxsize=None)
def get_embedding_provider() -> EmbeddingProvider:
    name = settings.embedding_provider
    if name not in _PROVIDERS:
        raise ValueError(f"Unknown embedding provider: {name}")
    return _PROVIDERS[name]()
