from openai import AsyncOpenAI

from app.config import settings
from app.embeddings.base import EmbeddingProvider


class OpenAIEmbeddingProvider(EmbeddingProvider):
    name = "openai"
    dimensions = 1536  # text-embedding-3-small

    def __init__(self) -> None:
        self._client = AsyncOpenAI(api_key=settings.openai_api_key)
        self._model = "text-embedding-3-small"

    async def embed(self, texts: list[str]) -> list[list[float]]:
        # OpenAI's embeddings endpoint accepts a batch directly.
        res = await self._client.embeddings.create(model=self._model, input=texts)
        return [item.embedding for item in res.data]
