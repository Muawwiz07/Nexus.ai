"""
Turns an uploaded file into plain text, page by page where the format
supports pages (PDF) and as a single block otherwise (DOCX, TXT).

Returns a list of (page_number_or_None, text) tuples so chunking can
retain page-level provenance for citations.
"""
from pathlib import Path

from docx import Document as DocxDocument
from pypdf import PdfReader

SUPPORTED_CONTENT_TYPES = {
    "application/pdf": "pdf",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document": "docx",
    "text/plain": "txt",
}


class UnsupportedFileType(ValueError):
    pass


def extract_pages(file_path: str, content_type: str) -> list[tuple[int | None, str]]:
    kind = SUPPORTED_CONTENT_TYPES.get(content_type)
    if kind is None:
        # Fall back to extension sniffing — browsers sometimes send a
        # generic content-type for .docx/.txt depending on OS.
        ext = Path(file_path).suffix.lower().lstrip(".")
        kind = {"pdf": "pdf", "docx": "docx", "txt": "txt"}.get(ext)
    if kind is None:
        raise UnsupportedFileType(f"Unsupported file type: {content_type}")

    if kind == "pdf":
        return _extract_pdf(file_path)
    if kind == "docx":
        return _extract_docx(file_path)
    return _extract_txt(file_path)


def _extract_pdf(file_path: str) -> list[tuple[int | None, str]]:
    reader = PdfReader(file_path)
    pages = []
    for i, page in enumerate(reader.pages, start=1):
        text = page.extract_text() or ""
        if text.strip():
            pages.append((i, text))
    return pages


def _extract_docx(file_path: str) -> list[tuple[int | None, str]]:
    doc = DocxDocument(file_path)
    text = "\n".join(p.text for p in doc.paragraphs if p.text.strip())
    return [(None, text)] if text.strip() else []


def _extract_txt(file_path: str) -> list[tuple[int | None, str]]:
    with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
        text = f.read()
    return [(None, text)] if text.strip() else []
