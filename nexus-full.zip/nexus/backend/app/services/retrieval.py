from dataclasses import dataclass

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.config import settings
from app.embeddings.factory import get_embedding_provider
from app.models import Document, DocumentChunk


@dataclass
class RetrievedChunk:
    chunk_id: str
    document_id: str
    document_title: str
    content: str
    page_number: int | None
    distance: float  # cosine distance — lower is more relevant


async def retrieve_relevant_chunks(
    db: Session, user_id: str, query: str, top_k: int | None = None
) -> list[RetrievedChunk]:
    provider = get_embedding_provider()
    query_vector = await provider.embed_one(query)

    top_k = top_k or settings.retrieval_top_k

    # `<=>` is pgvector's cosine-distance operator. An HNSW index backs
    # this column as of migration 0003, so this is an approximate nearest
    # neighbor search — fast at scale, with a small (typically negligible)
    # recall tradeoff vs. an exact scan.
    rows = (
        db.execute(
            select(
                DocumentChunk.id,
                DocumentChunk.document_id,
                DocumentChunk.content,
                DocumentChunk.page_number,
                Document.filename,
                DocumentChunk.embedding.cosine_distance(query_vector).label("distance"),
            )
            .join(Document, Document.id == DocumentChunk.document_id)
            .where(Document.user_id == user_id, Document.status == "ready")
            .order_by("distance")
            .limit(top_k)
        )
        .all()
    )

    return [
        RetrievedChunk(
            chunk_id=r.id,
            document_id=r.document_id,
            document_title=r.filename,
            content=r.content,
            page_number=r.page_number,
            distance=r.distance,
        )
        for r in rows
    ]


def build_context_block(chunks: list[RetrievedChunk]) -> str:
    """
    Formats retrieved chunks as a numbered source list the LLM is
    instructed (see chat.py's RAG system prompt) to cite inline as
    [1], [2], etc. The same numbering is sent to the frontend as
    structured citations so the UI can render them without re-parsing
    the model's prose.
    """
    if not chunks:
        return ""
    lines = []
    for i, c in enumerate(chunks, start=1):
        loc = f", p.{c.page_number}" if c.page_number else ""
        lines.append(f"[{i}] Source: {c.document_title}{loc}\n{c.content}")
    return "\n\n".join(lines)
