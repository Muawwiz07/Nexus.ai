"""
Character-based recursive splitter: tries paragraph breaks first, then
sentence breaks, then falls back to a hard cut. Good enough for MVP RAG;
swap in a token-aware splitter (tiktoken-based) if chunk boundaries start
cutting mid-sentence for a particular document set.
"""
from dataclasses import dataclass

from app.config import settings


@dataclass
class Chunk:
    content: str
    page_number: int | None


def chunk_pages(pages: list[tuple[int | None, str]]) -> list[Chunk]:
    chunks: list[Chunk] = []
    for page_number, text in pages:
        for piece in _split_text(text, settings.chunk_size_chars, settings.chunk_overlap_chars):
            if piece.strip():
                chunks.append(Chunk(content=piece.strip(), page_number=page_number))
    return chunks


def _split_text(text: str, size: int, overlap: int) -> list[str]:
    if len(text) <= size:
        return [text]

    paragraphs = [p for p in text.split("\n\n") if p.strip()]
    pieces: list[str] = []
    current = ""

    for para in paragraphs:
        if len(current) + len(para) + 2 <= size:
            current = f"{current}\n\n{para}" if current else para
        else:
            if current:
                pieces.append(current)
            if len(para) > size:
                pieces.extend(_hard_split(para, size, overlap))
                current = ""
            else:
                current = para

    if current:
        pieces.append(current)

    # Apply overlap between consecutive pieces so context isn't lost at
    # chunk boundaries.
    if overlap > 0 and len(pieces) > 1:
        overlapped = [pieces[0]]
        for prev, curr in zip(pieces, pieces[1:]):
            tail = prev[-overlap:]
            overlapped.append(f"{tail}\n\n{curr}")
        return overlapped

    return pieces


def _hard_split(text: str, size: int, overlap: int) -> list[str]:
    pieces = []
    start = 0
    step = max(size - overlap, 1)
    while start < len(text):
        pieces.append(text[start : start + size])
        start += step
    return pieces
