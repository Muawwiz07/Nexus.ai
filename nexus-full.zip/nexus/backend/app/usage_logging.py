from sqlalchemy.orm import Session

from app.models import RequestLog
from app.pricing import estimate_cost_usd
from app.telemetry import UsageAccumulator


def log_request(
    db: Session,
    user_id: str,
    kind: str,
    usage: UsageAccumulator | None,
    conversation_id: str | None = None,
    workflow_run_id: str | None = None,
) -> RequestLog | None:
    """
    Persists one RequestLog row from whatever the telemetry accumulator
    captured during a turn. Returns None (and logs nothing) if usage is
    None or recorded zero API calls — e.g. a turn that errored before
    any provider call happened shouldn't produce a fabricated zero-cost
    row that would silently skew latency/cost averages downward.
    """
    if usage is None or usage.api_calls == 0:
        return None

    cost = estimate_cost_usd(usage.model, usage.input_tokens, usage.output_tokens)
    entry = RequestLog(
        user_id=user_id,
        conversation_id=conversation_id,
        workflow_run_id=workflow_run_id,
        kind=kind,
        provider=usage.provider,
        model=usage.model,
        input_tokens=usage.input_tokens,
        output_tokens=usage.output_tokens,
        latency_ms=usage.latency_ms,
        cost_usd=cost,
        api_calls=usage.api_calls,
    )
    db.add(entry)
    db.commit()
    return entry
