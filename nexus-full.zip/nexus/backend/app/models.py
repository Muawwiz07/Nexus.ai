import uuid
from datetime import datetime, timezone

from pgvector.sqlalchemy import Vector
from sqlalchemy import Boolean, Column, DateTime, Float, ForeignKey, Integer, String, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship

from app.config import settings
from app.database import Base


def _uuid():
    return str(uuid.uuid4())


def _now():
    return datetime.now(timezone.utc)


class User(Base):
    __tablename__ = "users"

    id = Column(UUID(as_uuid=False), primary_key=True, default=_uuid)
    email = Column(String, unique=True, index=True, nullable=False)
    hashed_password = Column(String, nullable=False)
    full_name = Column(String, nullable=True)
    created_at = Column(DateTime(timezone=True), default=_now)

    conversations = relationship(
        "Conversation", back_populates="user", cascade="all, delete-orphan"
    )


class Conversation(Base):
    __tablename__ = "conversations"

    id = Column(UUID(as_uuid=False), primary_key=True, default=_uuid)
    user_id = Column(UUID(as_uuid=False), ForeignKey("users.id"), nullable=False)
    title = Column(String, default="New conversation")
    llm_provider = Column(String, default="anthropic")
    rag_enabled = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), default=_now)

    user = relationship("User", back_populates="conversations")
    messages = relationship(
        "Message",
        back_populates="conversation",
        cascade="all, delete-orphan",
        order_by="Message.created_at",
    )


class Message(Base):
    __tablename__ = "messages"

    id = Column(UUID(as_uuid=False), primary_key=True, default=_uuid)
    conversation_id = Column(
        UUID(as_uuid=False), ForeignKey("conversations.id"), nullable=False
    )
    role = Column(String, nullable=False)  # "user" | "assistant" | "system"
    content = Column(Text, nullable=False)
    created_at = Column(DateTime(timezone=True), default=_now)

    conversation = relationship("Conversation", back_populates="messages")

    # Populated by the agent executor (Phase 3) — which specialist agent
    # produced this reply, and the tool_call/tool_result trace as JSON.
    # NULL for plain (non-agent) messages, e.g. anything from Phase 1.
    agent_key = Column(String, nullable=True)
    tool_trace = Column(Text, nullable=True)


class Document(Base):
    __tablename__ = "documents"

    id = Column(UUID(as_uuid=False), primary_key=True, default=_uuid)
    user_id = Column(UUID(as_uuid=False), ForeignKey("users.id"), nullable=False)
    filename = Column(String, nullable=False)
    content_type = Column(String, nullable=False)
    file_path = Column(String, nullable=False)
    status = Column(String, default="processing")  # processing | ready | failed
    error_message = Column(String, nullable=True)
    chunk_count = Column(Integer, default=0)
    created_at = Column(DateTime(timezone=True), default=_now)

    chunks = relationship(
        "DocumentChunk", back_populates="document", cascade="all, delete-orphan"
    )


class DocumentChunk(Base):
    __tablename__ = "document_chunks"

    id = Column(UUID(as_uuid=False), primary_key=True, default=_uuid)
    document_id = Column(UUID(as_uuid=False), ForeignKey("documents.id"), nullable=False)
    chunk_index = Column(Integer, nullable=False)
    content = Column(Text, nullable=False)
    page_number = Column(Integer, nullable=True)
    embedding = Column(Vector(settings.embedding_dimensions), nullable=False)
    created_at = Column(DateTime(timezone=True), default=_now)

    document = relationship("Document", back_populates="chunks")


# ---- Phase 3 — Agents, tools, memory ----

class Task(Base):
    __tablename__ = "tasks"

    id = Column(UUID(as_uuid=False), primary_key=True, default=_uuid)
    user_id = Column(UUID(as_uuid=False), ForeignKey("users.id"), nullable=False)
    title = Column(String, nullable=False)
    description = Column(Text, nullable=True)
    status = Column(String, default="open")  # open | done
    due_date = Column(DateTime(timezone=True), nullable=True)
    source = Column(String, default="user")  # "user" | "agent" — who created it
    created_at = Column(DateTime(timezone=True), default=_now)


class Report(Base):
    __tablename__ = "reports"

    id = Column(UUID(as_uuid=False), primary_key=True, default=_uuid)
    user_id = Column(UUID(as_uuid=False), ForeignKey("users.id"), nullable=False)
    title = Column(String, nullable=False)
    content = Column(Text, nullable=False)  # markdown, composed by the Data Analysis Agent
    created_at = Column(DateTime(timezone=True), default=_now)


class NotificationLog(Base):
    """
    Record of a notification the Email Agent 'sent'. Delivery is
    simulated (logged here, not actually emailed) unless a real
    provider — e.g. SES, SendGrid — is wired into app/tools/notifications.py.
    """

    __tablename__ = "notification_logs"

    id = Column(UUID(as_uuid=False), primary_key=True, default=_uuid)
    user_id = Column(UUID(as_uuid=False), ForeignKey("users.id"), nullable=False)
    recipient = Column(String, nullable=False)
    subject = Column(String, nullable=True)
    message = Column(Text, nullable=False)
    status = Column(String, default="sent")  # simulated status
    created_at = Column(DateTime(timezone=True), default=_now)


class MemoryEntry(Base):
    """
    Long-term, cross-conversation agent memory — distinct from
    Conversation/Message, which is short-term (scoped to one thread).
    Agents write here via the remember_fact tool and read via
    recall_memory, so a fact learned in one conversation is available in
    later ones. Same embed-then-cosine-search pattern as document_chunks.
    """

    __tablename__ = "memory_entries"

    id = Column(UUID(as_uuid=False), primary_key=True, default=_uuid)
    user_id = Column(UUID(as_uuid=False), ForeignKey("users.id"), nullable=False)
    content = Column(Text, nullable=False)
    embedding = Column(Vector(settings.embedding_dimensions), nullable=False)
    created_at = Column(DateTime(timezone=True), default=_now)


# ---- Phase 4 — Automation ----

class Workflow(Base):
    """
    A scheduled, multi-step agent run — "every Monday, analyze pending
    tasks, identify overdue work, and generate a report" as a persisted,
    cron-driven definition rather than a one-off chat message. See
    app/automation/executor.py for how this actually runs and
    app/scheduler.py for how cron_expression turns into a job.
    """

    __tablename__ = "workflows"

    id = Column(UUID(as_uuid=False), primary_key=True, default=_uuid)
    user_id = Column(UUID(as_uuid=False), ForeignKey("users.id"), nullable=False)
    name = Column(String, nullable=False)
    description = Column(Text, nullable=True)
    cron_expression = Column(String, nullable=False)  # standard 5-field cron, UTC
    enabled = Column(Boolean, default=True)
    llm_provider = Column(String, default="anthropic")
    system_prompt = Column(Text, nullable=True)  # falls back to a default if unset
    tool_names = Column(Text, nullable=False)  # JSON list — which tools this workflow may use
    last_run_at = Column(DateTime(timezone=True), nullable=True)
    created_at = Column(DateTime(timezone=True), default=_now)

    steps = relationship(
        "WorkflowStep",
        back_populates="workflow",
        cascade="all, delete-orphan",
        order_by="WorkflowStep.step_order",
    )
    runs = relationship(
        "WorkflowRun", back_populates="workflow", cascade="all, delete-orphan"
    )


class WorkflowStep(Base):
    """
    One instruction in a workflow's sequence, executed in step_order.
    Instructions are plain natural language (same as a chat message) —
    the model decides which tools to call to satisfy each one, and each
    step sees the conversation history built up by the steps before it.
    """

    __tablename__ = "workflow_steps"

    id = Column(UUID(as_uuid=False), primary_key=True, default=_uuid)
    workflow_id = Column(UUID(as_uuid=False), ForeignKey("workflows.id"), nullable=False)
    step_order = Column(Integer, nullable=False)
    instruction = Column(Text, nullable=False)

    workflow = relationship("Workflow", back_populates="steps")


class WorkflowRun(Base):
    """
    One execution of a workflow, whether triggered by the scheduler or
    manually via 'run now'. Rather than inventing a separate transcript
    format, each run gets its own Conversation + Messages — the exact
    same tables interactive chat uses — so a run's full step-by-step
    reasoning and tool calls are inspectable in the ordinary chat UI,
    tagged distinctly by title and Message.agent_key='automation'.
    """

    __tablename__ = "workflow_runs"

    id = Column(UUID(as_uuid=False), primary_key=True, default=_uuid)
    workflow_id = Column(UUID(as_uuid=False), ForeignKey("workflows.id"), nullable=False)
    conversation_id = Column(UUID(as_uuid=False), ForeignKey("conversations.id"), nullable=True)
    status = Column(String, default="running")  # running | success | failed
    started_at = Column(DateTime(timezone=True), default=_now)
    finished_at = Column(DateTime(timezone=True), nullable=True)
    error_message = Column(Text, nullable=True)

    workflow = relationship("Workflow", back_populates="runs")


# ---- Phase 5 — Evaluation ----

class RequestLog(Base):
    """
    One row per LLM 'turn' — an interactive chat message or one workflow
    step — capturing real, measured latency/token/cost data, not
    estimates. A turn that made three tool calls before answering is
    still one row here (see app/telemetry.py): the individual API calls
    are summed, because "cost per request" in the brief means cost per
    user-visible turn, not per internal API round-trip.
    """

    __tablename__ = "request_logs"

    id = Column(UUID(as_uuid=False), primary_key=True, default=_uuid)
    user_id = Column(UUID(as_uuid=False), ForeignKey("users.id"), nullable=False)
    conversation_id = Column(UUID(as_uuid=False), ForeignKey("conversations.id"), nullable=True)
    workflow_run_id = Column(UUID(as_uuid=False), ForeignKey("workflow_runs.id"), nullable=True)
    kind = Column(String, nullable=False)  # "chat" | "workflow_step" | "eval"
    provider = Column(String, nullable=False)
    model = Column(String, nullable=False)
    input_tokens = Column(Integer, default=0)
    output_tokens = Column(Integer, default=0)
    latency_ms = Column(Float, default=0.0)
    cost_usd = Column(Float, default=0.0)
    api_calls = Column(Integer, default=1)  # how many underlying API round-trips this turn made
    created_at = Column(DateTime(timezone=True), default=_now)


class EvalDataset(Base):
    """A named, reusable set of test questions — the 'test dataset' the
    brief asks for — that automated eval runs are graded against."""

    __tablename__ = "eval_datasets"

    id = Column(UUID(as_uuid=False), primary_key=True, default=_uuid)
    user_id = Column(UUID(as_uuid=False), ForeignKey("users.id"), nullable=False)
    name = Column(String, nullable=False)
    description = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), default=_now)

    cases = relationship(
        "EvalCase", back_populates="dataset", cascade="all, delete-orphan"
    )
    runs = relationship(
        "EvalRun", back_populates="dataset", cascade="all, delete-orphan"
    )


class EvalCase(Base):
    """
    One test question. `expected_answer` (a reference answer) drives the
    LLM-judge's accuracy score; `expected_document_id` (if the question
    should be answerable from a specific uploaded document) drives the
    retrieval precision/recall metrics — both optional, independently,
    since not every test case needs to exercise both dimensions.
    """

    __tablename__ = "eval_cases"

    id = Column(UUID(as_uuid=False), primary_key=True, default=_uuid)
    dataset_id = Column(UUID(as_uuid=False), ForeignKey("eval_datasets.id"), nullable=False)
    question = Column(Text, nullable=False)
    expected_answer = Column(Text, nullable=True)
    expected_document_id = Column(UUID(as_uuid=False), ForeignKey("documents.id"), nullable=True)
    created_at = Column(DateTime(timezone=True), default=_now)

    dataset = relationship("EvalDataset", back_populates="cases")


class EvalRun(Base):
    """One execution of a dataset's full case list, with dataset-level
    averages across every dimension the brief's dashboard asks for."""

    __tablename__ = "eval_runs"

    id = Column(UUID(as_uuid=False), primary_key=True, default=_uuid)
    dataset_id = Column(UUID(as_uuid=False), ForeignKey("eval_datasets.id"), nullable=False)
    user_id = Column(UUID(as_uuid=False), ForeignKey("users.id"), nullable=False)
    status = Column(String, default="running")  # running | success | failed
    error_message = Column(Text, nullable=True)

    avg_accuracy = Column(Float, nullable=True)
    avg_relevance = Column(Float, nullable=True)
    avg_faithfulness = Column(Float, nullable=True)
    avg_response_quality = Column(Float, nullable=True)
    avg_retrieval_precision = Column(Float, nullable=True)  # null if no case tested retrieval
    avg_retrieval_recall = Column(Float, nullable=True)
    hallucination_rate = Column(Float, nullable=True)
    avg_latency_ms = Column(Float, nullable=True)
    total_input_tokens = Column(Integer, default=0)
    total_output_tokens = Column(Integer, default=0)
    total_cost_usd = Column(Float, default=0.0)

    started_at = Column(DateTime(timezone=True), default=_now)
    finished_at = Column(DateTime(timezone=True), nullable=True)

    dataset = relationship("EvalDataset", back_populates="runs")
    results = relationship(
        "EvalResult", back_populates="run", cascade="all, delete-orphan"
    )


class EvalResult(Base):
    """Per-case scores from one EvalRun, including the judge's raw
    rationale so a low score is explainable, not just a number."""

    __tablename__ = "eval_results"

    id = Column(UUID(as_uuid=False), primary_key=True, default=_uuid)
    eval_run_id = Column(UUID(as_uuid=False), ForeignKey("eval_runs.id"), nullable=False)
    case_id = Column(UUID(as_uuid=False), ForeignKey("eval_cases.id"), nullable=False)

    question = Column(Text, nullable=False)
    generated_answer = Column(Text, nullable=False)

    accuracy = Column(Float, nullable=True)
    relevance = Column(Float, nullable=True)
    faithfulness = Column(Float, nullable=True)
    response_quality = Column(Float, nullable=True)
    hallucinated = Column(Boolean, nullable=True)
    judge_rationale = Column(Text, nullable=True)

    retrieval_precision = Column(Float, nullable=True)
    retrieval_recall = Column(Float, nullable=True)

    latency_ms = Column(Float, default=0.0)
    input_tokens = Column(Integer, default=0)
    output_tokens = Column(Integer, default=0)
    cost_usd = Column(Float, default=0.0)

    created_at = Column(DateTime(timezone=True), default=_now)

    run = relationship("EvalRun", back_populates="results")
