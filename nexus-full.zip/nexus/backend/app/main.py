from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.config import settings
from app.routers import agent_data, auth, chat, documents, evaluation, workflows
from app.scheduler import start_scheduler, stop_scheduler


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Starts the cron scheduler and reconciles it against every enabled
    # Workflow row in the database — so workflow schedules survive a
    # backend restart without any manual re-registration.
    start_scheduler()
    yield
    stop_scheduler()


app = FastAPI(
    title="NEXUS AI",
    description="Agentic Enterprise Intelligence Platform — API",
    version="0.1.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[settings.frontend_origin],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router)
app.include_router(chat.router)
app.include_router(documents.router)
app.include_router(agent_data.router)
app.include_router(workflows.router)
app.include_router(evaluation.router)


@app.get("/api/health")
def health():
    return {"status": "ok", "service": "nexus-backend"}
