from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, AsyncIterator, Awaitable, Callable, TypedDict

if TYPE_CHECKING:
    # Deferred import avoids a circular dependency: app.tools.base doesn't
    # import anything from app.llm, but importing it at module load time
    # here would still create an import-order hazard depending on how
    # app.tools's package __init__ wires up tool registration.
    from app.tools.base import ToolDefinition


class ChatMessage(TypedDict):
    role: str  # "user" | "assistant" | "system"
    content: str


class LLMProvider(ABC):
    """
    Every provider (Anthropic, OpenAI, ...) implements this same interface,
    so routers/agents never need to know which one is active.

    Subclasses also expose a `model_name` property (the specific model
    string in use, e.g. "claude-sonnet-4-6") — used by app/pricing.py to
    estimate cost from the token counts each API call reports.
    """

    name: str

    @abstractmethod
    async def stream_chat(
        self, messages: list[ChatMessage], system: str | None = None
    ) -> AsyncIterator[str]:
        """Yield text deltas as they arrive from the model."""
        ...

    @abstractmethod
    async def complete(self, system: str, user_message: str, max_tokens: int = 20) -> str:
        """
        Single-turn, non-streaming completion. Used for cheap calls that
        don't need token-level streaming — currently just agent routing
        classification (app/agents/router.py).
        """
        ...

    @abstractmethod
    async def run_agentic_turn(
        self,
        messages: list[ChatMessage],
        tools: "list[ToolDefinition]",
        system: str,
        on_tool_call: Callable[[str, dict], Awaitable[None]],
        execute_tool: Callable[[str, dict], Awaitable[str]],
        max_iterations: int = 5,
    ) -> str:
        """
        Runs the full tool-calling loop for one turn: calls the model,
        and for as long as it requests tool use, executes each tool via
        `execute_tool` (which returns a string result) and feeds results
        back, notifying `on_tool_call` before each execution so the
        caller can stream progress. Returns once the model produces a
        final text-only response, or after `max_iterations` rounds.
        """
        ...
