import json
from typing import Awaitable, Callable, TYPE_CHECKING, AsyncIterator

from openai import AsyncOpenAI

from app.config import settings
from app.llm.base import ChatMessage, LLMProvider
from app.telemetry import record_api_call, timed_call

if TYPE_CHECKING:
    from app.tools.base import ToolDefinition


class OpenAIProvider(LLMProvider):
    name = "openai"

    def __init__(self) -> None:
        self._client = AsyncOpenAI(api_key=settings.openai_api_key)
        self._model = settings.openai_model

    @property
    def model_name(self) -> str:
        return self._model

    async def stream_chat(
        self, messages: list[ChatMessage], system: str | None = None
    ) -> AsyncIterator[str]:
        formatted = []
        if system:
            formatted.append({"role": "system", "content": system})
        formatted += [{"role": m["role"], "content": m["content"]} for m in messages]

        stream = await self._client.chat.completions.create(
            model=self._model, messages=formatted, stream=True
        )
        async for chunk in stream:
            delta = chunk.choices[0].delta.content
            if delta:
                yield delta

    async def complete(self, system: str, user_message: str, max_tokens: int = 20) -> str:
        with timed_call() as t:
            resp = await self._client.chat.completions.create(
                model=self._model,
                max_tokens=max_tokens,
                messages=[
                    {"role": "system", "content": system},
                    {"role": "user", "content": user_message},
                ],
            )
        if resp.usage:
            record_api_call(resp.usage.prompt_tokens, resp.usage.completion_tokens, t.ms)
        return (resp.choices[0].message.content or "").strip()

    @staticmethod
    def _to_openai_tools(tools: "list[ToolDefinition]") -> list[dict]:
        return [
            {
                "type": "function",
                "function": {
                    "name": t.name,
                    "description": t.description,
                    "parameters": t.parameters,
                },
            }
            for t in tools
        ]

    async def run_agentic_turn(
        self,
        messages: list[ChatMessage],
        tools: "list[ToolDefinition]",
        system: str,
        on_tool_call: Callable[[str, dict], Awaitable[None]],
        execute_tool: Callable[[str, dict], Awaitable[str]],
        max_iterations: int = 5,
    ) -> str:
        openai_tools = self._to_openai_tools(tools)
        convo: list[dict] = [{"role": "system", "content": system}] + [
            {"role": m["role"], "content": m["content"]} for m in messages
        ]

        for _ in range(max_iterations):
            with timed_call() as t:
                resp = await self._client.chat.completions.create(
                    model=self._model,
                    messages=convo,
                    tools=openai_tools,
                    tool_choice="auto",
                )
            if resp.usage:
                record_api_call(resp.usage.prompt_tokens, resp.usage.completion_tokens, t.ms)

            msg = resp.choices[0].message

            if not msg.tool_calls:
                return (msg.content or "").strip()

            convo.append(
                {
                    "role": "assistant",
                    "content": msg.content,
                    "tool_calls": [tc.model_dump() for tc in msg.tool_calls],
                }
            )

            for tc in msg.tool_calls:
                try:
                    args = json.loads(tc.function.arguments)
                except json.JSONDecodeError:
                    args = {}
                await on_tool_call(tc.function.name, args)
                result_str = await execute_tool(tc.function.name, args)
                convo.append({"role": "tool", "tool_call_id": tc.id, "content": result_str})

        return (
            "I wasn't able to finish that within the allotted tool-call steps — "
            "could you narrow the request?"
        )
