from typing import Awaitable, Callable, TYPE_CHECKING, AsyncIterator

import anthropic

from app.config import settings
from app.llm.base import ChatMessage, LLMProvider
from app.telemetry import record_api_call, timed_call

if TYPE_CHECKING:
    from app.tools.base import ToolDefinition


class AnthropicProvider(LLMProvider):
    name = "anthropic"

    def __init__(self) -> None:
        self._client = anthropic.AsyncAnthropic(api_key=settings.anthropic_api_key)
        self._model = settings.anthropic_model

    @property
    def model_name(self) -> str:
        return self._model

    async def stream_chat(
        self, messages: list[ChatMessage], system: str | None = None
    ) -> AsyncIterator[str]:
        async with self._client.messages.stream(
            model=self._model,
            max_tokens=2048,
            system=system or "",
            messages=[{"role": m["role"], "content": m["content"]} for m in messages],
        ) as stream:
            async for text in stream.text_stream:
                yield text

    async def complete(self, system: str, user_message: str, max_tokens: int = 20) -> str:
        with timed_call() as t:
            resp = await self._client.messages.create(
                model=self._model,
                max_tokens=max_tokens,
                system=system,
                messages=[{"role": "user", "content": user_message}],
            )
        record_api_call(resp.usage.input_tokens, resp.usage.output_tokens, t.ms)
        return "".join(block.text for block in resp.content if block.type == "text").strip()

    @staticmethod
    def _to_anthropic_tools(tools: "list[ToolDefinition]") -> list[dict]:
        return [
            {"name": t.name, "description": t.description, "input_schema": t.parameters}
            for t in tools
        ]

    async def run_agentic_turn(
        self,
        messages: list[ChatMessage],
        tools: "list[ToolDefinition]",
        system: str,
        on_tool_call: Callable[[str, dict], Awaitable[None]],
        execute_tool: Callable[[str, dict], Awaitable[str]],
        max_iterations: int = 5,
    ) -> str:
        anthropic_tools = self._to_anthropic_tools(tools)
        convo: list[dict] = [{"role": m["role"], "content": m["content"]} for m in messages]

        for _ in range(max_iterations):
            # Every round of the tool loop is its own API call and gets
            # recorded separately — a turn that calls three tools before
            # answering shows up as four recorded calls, summed by
            # whoever's tracking usage (see app/telemetry.py).
            with timed_call() as t:
                resp = await self._client.messages.create(
                    model=self._model,
                    max_tokens=2048,
                    system=system,
                    messages=convo,
                    tools=anthropic_tools,
                )
            record_api_call(resp.usage.input_tokens, resp.usage.output_tokens, t.ms)

            tool_uses = [b for b in resp.content if b.type == "tool_use"]
            text = "".join(b.text for b in resp.content if b.type == "text").strip()

            if not tool_uses:
                return text

            # The assistant turn requesting tool use — including any text
            # it produced alongside the tool_use blocks — must be replayed
            # verbatim in the next request, exactly as the API returned it.
            convo.append(
                {"role": "assistant", "content": [b.model_dump() for b in resp.content]}
            )

            tool_result_blocks = []
            for tu in tool_uses:
                await on_tool_call(tu.name, tu.input)
                result_str = await execute_tool(tu.name, tu.input)
                tool_result_blocks.append(
                    {"type": "tool_result", "tool_use_id": tu.id, "content": result_str}
                )
            convo.append({"role": "user", "content": tool_result_blocks})

        return (
            "I wasn't able to finish that within the allotted tool-call steps — "
            "could you narrow the request?"
        )
