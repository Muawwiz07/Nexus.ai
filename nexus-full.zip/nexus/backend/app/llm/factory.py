from functools import lru_cache

from app.config import settings
from app.llm.anthropic_provider import AnthropicProvider
from app.llm.base import LLMProvider
from app.llm.openai_provider import OpenAIProvider

_PROVIDERS: dict[str, type[LLMProvider]] = {
    "anthropic": AnthropicProvider,
    "openai": OpenAIProvider,
}


@lru_cache(maxsize=None)
def _instantiate(name: str) -> LLMProvider:
    if name not in _PROVIDERS:
        raise ValueError(f"Unknown LLM provider: {name}")
    return _PROVIDERS[name]()


def get_provider(name: str | None = None) -> LLMProvider:
    """Get a (cached) provider instance. Falls back to DEFAULT_LLM_PROVIDER."""
    return _instantiate(name or settings.default_llm_provider)
