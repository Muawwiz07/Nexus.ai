from sqlalchemy import select

from app.embeddings.factory import get_embedding_provider
from app.models import MemoryEntry
from app.tools.base import ToolContext, ToolDefinition, register_tool


async def _remember_handler(tool_input: dict, ctx: ToolContext) -> dict:
    content = (tool_input.get("content") or "").strip()
    if not content:
        return {"error": "content is required"}

    provider = get_embedding_provider()
    vector = await provider.embed_one(content)

    entry = MemoryEntry(user_id=ctx.user.id, content=content, embedding=vector)
    ctx.db.add(entry)
    ctx.db.commit()

    return {"result": "Remembered."}


async def _recall_handler(tool_input: dict, ctx: ToolContext) -> dict:
    query = (tool_input.get("query") or "").strip()
    if not query:
        return {"error": "query is required"}

    provider = get_embedding_provider()
    vector = await provider.embed_one(query)

    rows = ctx.db.execute(
        select(
            MemoryEntry.content, MemoryEntry.embedding.cosine_distance(vector).label("distance")
        )
        .where(MemoryEntry.user_id == ctx.user.id)
        .order_by("distance")
        .limit(5)
    ).all()

    if not rows:
        return {"result": "No relevant memories found."}
    return {"result": [r.content for r in rows]}


register_tool(
    ToolDefinition(
        name="remember_fact",
        description=(
            "Save a fact about the user or their preferences for future conversations "
            "— e.g. 'The user's HR contact is Priya Nair.' Use this for durable facts "
            "worth recalling later, not for routine chat content."
        ),
        parameters={
            "type": "object",
            "properties": {
                "content": {"type": "string", "description": "The fact to remember, as a plain statement."}
            },
            "required": ["content"],
        },
        handler=_remember_handler,
    )
)

register_tool(
    ToolDefinition(
        name="recall_memory",
        description=(
            "Search facts previously saved about the user across all their past "
            "conversations, not just this one. Use this when a request seems to "
            "reference something discussed before."
        ),
        parameters={
            "type": "object",
            "properties": {"query": {"type": "string", "description": "What to recall."}},
            "required": ["query"],
        },
        handler=_recall_handler,
    )
)
