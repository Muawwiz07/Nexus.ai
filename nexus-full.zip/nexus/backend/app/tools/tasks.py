from datetime import datetime

from app.models import Task
from app.tools.base import ToolContext, ToolDefinition, register_tool


def _parse_due_date(raw: str | None) -> datetime | None:
    if not raw:
        return None
    try:
        return datetime.fromisoformat(raw)
    except ValueError:
        return None  # tolerate a malformed date rather than failing the whole tool call


async def _handler(tool_input: dict, ctx: ToolContext) -> dict:
    title = (tool_input.get("title") or "").strip()
    if not title:
        return {"error": "title is required"}

    task = Task(
        user_id=ctx.user.id,
        title=title,
        description=tool_input.get("description"),
        due_date=_parse_due_date(tool_input.get("due_date")),
        status="open",
        source="agent",
    )
    ctx.db.add(task)
    ctx.db.commit()
    ctx.db.refresh(task)

    return {"result": f"Created task '{task.title}'.", "task_id": task.id}


register_tool(
    ToolDefinition(
        name="create_task",
        description=(
            "Create a task/action item for the user or a team to follow up on. "
            "Use this when the user asks you to create, assign, or track work."
        ),
        parameters={
            "type": "object",
            "properties": {
                "title": {"type": "string", "description": "Short, clear task title."},
                "description": {
                    "type": "string",
                    "description": "Optional additional detail — why the task matters, what to do.",
                },
                "due_date": {
                    "type": "string",
                    "description": "Optional ISO 8601 date/datetime, e.g. '2026-08-20'.",
                },
            },
            "required": ["title"],
        },
        handler=_handler,
    )
)
