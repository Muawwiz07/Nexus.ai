from app.models import Report
from app.tools.base import ToolContext, ToolDefinition, register_tool


async def _handler(tool_input: dict, ctx: ToolContext) -> dict:
    title = (tool_input.get("title") or "Untitled report").strip()
    content = (tool_input.get("content") or "").strip()
    if not content:
        return {"error": "content is required"}

    report = Report(user_id=ctx.user.id, title=title, content=content)
    ctx.db.add(report)
    ctx.db.commit()
    ctx.db.refresh(report)

    return {"result": f"Saved report '{title}'.", "report_id": report.id}


register_tool(
    ToolDefinition(
        name="generate_report",
        description=(
            "Save a written report (markdown) the user can retrieve later, e.g. a "
            "summary of overdue tasks or an analysis of their documents. Write the "
            "full report content yourself, then call this to persist it."
        ),
        parameters={
            "type": "object",
            "properties": {
                "title": {"type": "string", "description": "Report title."},
                "content": {
                    "type": "string",
                    "description": "The full report body, in markdown.",
                },
            },
            "required": ["title", "content"],
        },
        handler=_handler,
    )
)
