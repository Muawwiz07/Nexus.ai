from dataclasses import dataclass
from typing import Awaitable, Callable, Optional

from sqlalchemy.orm import Session

from app.models import Conversation, User


@dataclass
class ToolContext:
    """Everything a tool handler needs to actually do its job."""

    db: Session
    user: User
    conversation: Conversation
    # A tool that wants to push a live side-channel event (e.g.
    # search_documents pushing a `citations` frame) calls `await
    # ctx.emit(event)` rather than touching a WebSocket directly. In
    # interactive chat this forwards to the live socket; in an unattended
    # automation run (Phase 4) there's no socket to push to, so it's None
    # and tools skip the push — same handler code, two execution contexts.
    emit: Optional[Callable[[dict], Awaitable[None]]] = None


@dataclass
class ToolDefinition:
    name: str
    description: str
    parameters: dict  # JSON schema for the tool's input
    handler: Callable[[dict, ToolContext], Awaitable[dict | str]]


TOOL_REGISTRY: dict[str, ToolDefinition] = {}


def register_tool(tool: ToolDefinition) -> None:
    if tool.name in TOOL_REGISTRY:
        raise ValueError(f"Tool '{tool.name}' is already registered")
    TOOL_REGISTRY[tool.name] = tool


def resolve_tools(names: list[str]) -> list[ToolDefinition]:
    missing = [n for n in names if n not in TOOL_REGISTRY]
    if missing:
        raise KeyError(f"Unregistered tools requested: {missing}")
    return [TOOL_REGISTRY[n] for n in names]
