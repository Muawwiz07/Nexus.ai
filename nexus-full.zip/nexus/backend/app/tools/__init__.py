# Each submodule calls register_tool(...) at import time. Importing them
# here — and only here — means the rest of the app just does
# `from app.tools import resolve_tools` and gets every tool without
# needing to know the individual module names.
from app.tools import (  # noqa: F401
    calculator,
    database_query,
    memory,
    notifications,
    reports,
    search_documents,
    tasks,
    web_search,
)
from app.tools.base import TOOL_REGISTRY, ToolContext, ToolDefinition, resolve_tools  # noqa: F401
