"""
Deliberately NOT a free-form SQL tool. Letting an LLM generate arbitrary
SQL against the primary application database is a real injection/data-
exfiltration risk regardless of how the prompt tries to constrain it —
a malicious or confused tool call is one bad string away from reading
other users' rows or worse. Instead this exposes a fixed, enumerable set
of read-only query types, each implemented as ordinary parameterized
SQLAlchemy code and scoped to `ctx.user.id`. If you need broader
analytics later, point this at a read-only replica or warehouse instead
of loosening what's allowed here.
"""
from app.models import Conversation, Document, Task
from app.tools.base import ToolContext, ToolDefinition, register_tool

QUERY_TYPES = {
    "count_documents",
    "count_conversations",
    "list_tasks",
    "count_tasks_by_status",
}


async def _handler(tool_input: dict, ctx: ToolContext) -> dict:
    query_type = tool_input.get("query_type")
    if query_type not in QUERY_TYPES:
        return {"error": f"Unknown query_type. Must be one of: {sorted(QUERY_TYPES)}"}

    if query_type == "count_documents":
        count = ctx.db.query(Document).filter(Document.user_id == ctx.user.id).count()
        return {"result": f"{count} document(s) uploaded."}

    if query_type == "count_conversations":
        count = ctx.db.query(Conversation).filter(Conversation.user_id == ctx.user.id).count()
        return {"result": f"{count} conversation(s)."}

    if query_type == "list_tasks":
        q = ctx.db.query(Task).filter(Task.user_id == ctx.user.id)
        status = tool_input.get("status")
        if status:
            q = q.filter(Task.status == status)
        tasks = q.order_by(Task.created_at.desc()).limit(20).all()
        return {
            "result": [
                {
                    "id": t.id,
                    "title": t.title,
                    "status": t.status,
                    "due_date": t.due_date.isoformat() if t.due_date else None,
                }
                for t in tasks
            ]
        }

    if query_type == "count_tasks_by_status":
        tasks = ctx.db.query(Task).filter(Task.user_id == ctx.user.id).all()
        counts: dict[str, int] = {}
        for t in tasks:
            counts[t.status] = counts.get(t.status, 0) + 1
        return {"result": counts}

    return {"error": "Unhandled query_type"}  # unreachable given the check above


register_tool(
    ToolDefinition(
        name="query_database",
        description=(
            "Run a structured, read-only query over the user's own NEXUS data "
            "(their documents, conversations, and tasks) — not general web or "
            "document content search."
        ),
        parameters={
            "type": "object",
            "properties": {
                "query_type": {
                    "type": "string",
                    "enum": sorted(QUERY_TYPES),
                    "description": "Which structured query to run.",
                },
                "status": {
                    "type": "string",
                    "description": "Optional status filter for list_tasks, e.g. 'open' or 'done'.",
                },
            },
            "required": ["query_type"],
        },
        handler=_handler,
    )
)
