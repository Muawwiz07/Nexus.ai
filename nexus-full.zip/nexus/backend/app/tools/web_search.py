import httpx

from app.config import settings
from app.tools.base import ToolContext, ToolDefinition, register_tool


async def _handler(tool_input: dict, ctx: ToolContext) -> dict:
    query = (tool_input.get("query") or "").strip()
    if not query:
        return {"error": "query is required"}

    if not settings.tavily_api_key:
        # Fails soft, not hard — an unconfigured web search shouldn't
        # crash the agent loop, just tell the model (and, via its reply,
        # the user) that this capability isn't turned on yet.
        return {
            "error": (
                "Web search is not configured. Set TAVILY_API_KEY in the backend "
                ".env to enable it (https://tavily.com)."
            )
        }

    try:
        async with httpx.AsyncClient(timeout=15) as client:
            res = await client.post(
                "https://api.tavily.com/search",
                json={"api_key": settings.tavily_api_key, "query": query, "max_results": 5},
            )
            res.raise_for_status()
            data = res.json()
    except httpx.HTTPError as e:
        return {"error": f"Web search request failed: {e}"}

    results = [
        {
            "title": r.get("title"),
            "url": r.get("url"),
            "snippet": (r.get("content") or "")[:300],
        }
        for r in data.get("results", [])
    ]
    if not results:
        return {"result": "No web results found."}
    return {"results": results}


register_tool(
    ToolDefinition(
        name="search_web",
        description="Search the open internet for current information not in the user's documents.",
        parameters={
            "type": "object",
            "properties": {"query": {"type": "string", "description": "The search query."}},
            "required": ["query"],
        },
        handler=_handler,
    )
)
