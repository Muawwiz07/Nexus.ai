import ast
import operator

from app.tools.base import ToolContext, ToolDefinition, register_tool

# Deliberately small: arithmetic only, no names/attributes/calls, so this
# can never be turned into arbitrary code execution regardless of what
# the model is prompted or tricked into passing as an "expression".
_BINARY_OPS = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.FloorDiv: operator.floordiv,
    ast.Mod: operator.mod,
    ast.Pow: operator.pow,
}
_UNARY_OPS = {ast.USub: operator.neg, ast.UAdd: operator.pos}


def _safe_eval(node: ast.AST) -> float:
    if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
        return node.value
    if isinstance(node, ast.BinOp) and type(node.op) in _BINARY_OPS:
        return _BINARY_OPS[type(node.op)](_safe_eval(node.left), _safe_eval(node.right))
    if isinstance(node, ast.UnaryOp) and type(node.op) in _UNARY_OPS:
        return _UNARY_OPS[type(node.op)](_safe_eval(node.operand))
    raise ValueError("Expression contains something other than plain arithmetic")


async def _handler(tool_input: dict, ctx: ToolContext) -> dict:
    expression = (tool_input.get("expression") or "").strip()
    if not expression:
        return {"error": "expression is required"}
    try:
        tree = ast.parse(expression, mode="eval")
        value = _safe_eval(tree.body)
    except (SyntaxError, ValueError, ZeroDivisionError, TypeError) as e:
        return {"error": f"Could not evaluate '{expression}': {e}"}
    return {"result": value}


register_tool(
    ToolDefinition(
        name="calculate",
        description="Evaluate an arithmetic expression, e.g. '(1200 - 950) / 950 * 100'.",
        parameters={
            "type": "object",
            "properties": {
                "expression": {
                    "type": "string",
                    "description": "A plain arithmetic expression using + - * / // % ** and parentheses.",
                }
            },
            "required": ["expression"],
        },
        handler=_handler,
    )
)
