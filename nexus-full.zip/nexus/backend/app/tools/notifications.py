from app.models import NotificationLog
from app.tools.base import ToolContext, ToolDefinition, register_tool


async def _handler(tool_input: dict, ctx: ToolContext) -> dict:
    recipient = (tool_input.get("recipient") or "").strip()
    if not recipient:
        return {"error": "recipient is required"}

    message = (tool_input.get("message") or "").strip()
    if not message:
        return {"error": "message is required"}

    log = NotificationLog(
        user_id=ctx.user.id,
        recipient=recipient,
        subject=tool_input.get("subject"),
        message=message,
        status="sent",  # simulated — see NotificationLog docstring in models.py
    )
    ctx.db.add(log)
    ctx.db.commit()

    return {
        "result": (
            f"Notification logged for {recipient} (simulated delivery — no live "
            "email/SMS provider is wired up in this environment)."
        )
    }


register_tool(
    ToolDefinition(
        name="send_notification",
        description=(
            "Send (simulated) a notification/email to someone. Delivery is logged, "
            "not actually transmitted, unless a real provider is configured."
        ),
        parameters={
            "type": "object",
            "properties": {
                "recipient": {
                    "type": "string",
                    "description": "Who to notify — name, email, or role (e.g. 'HR').",
                },
                "subject": {"type": "string", "description": "Optional subject line."},
                "message": {"type": "string", "description": "The notification body."},
            },
            "required": ["recipient", "message"],
        },
        handler=_handler,
    )
)
