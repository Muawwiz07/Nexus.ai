from app.services.retrieval import build_context_block, retrieve_relevant_chunks
from app.tools.base import ToolContext, ToolDefinition, register_tool


async def _handler(tool_input: dict, ctx: ToolContext) -> dict:
    query = (tool_input.get("query") or "").strip()
    if not query:
        return {"error": "query is required"}

    chunks = await retrieve_relevant_chunks(ctx.db, ctx.user.id, query)

    # Push the same `citations` frame Phase 2 sent automatically — the
    # frontend's CitationList component already knows how to render it.
    # Now it only fires when the model actually decides to search, rather
    # than on every single turn regardless of relevance. In an automation
    # run (Phase 4) ctx.emit is None, so this is skipped — citations still
    # end up in the tool's return value either way, just not pushed live.
    if chunks and ctx.emit is not None:
        await ctx.emit(
            {
                "type": "citations",
                "citations": [
                    {
                        "index": i + 1,
                        "document_id": c.document_id,
                        "document_title": c.document_title,
                        "page_number": c.page_number,
                        "snippet": c.content[:220],
                    }
                    for i, c in enumerate(chunks)
                ],
            }
        )

    if not chunks:
        return {"result": "No relevant passages found in the user's uploaded documents."}
    return {"result": build_context_block(chunks)}


register_tool(
    ToolDefinition(
        name="search_documents",
        description=(
            "Semantic search over the user's uploaded documents (PDF/DOCX/TXT). "
            "Use this whenever a question might be answered by something the user "
            "has uploaded — policies, contracts, reports, handbooks, etc."
        ),
        parameters={
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "The search query — phrase it as a natural question or topic.",
                }
            },
            "required": ["query"],
        },
        handler=_handler,
    )
)
