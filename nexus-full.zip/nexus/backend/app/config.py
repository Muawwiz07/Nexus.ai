from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # Database
    database_url: str = "postgresql://nexus:nexus@localhost:5432/nexus"

    # Auth
    jwt_secret_key: str = "dev-secret-change-me"
    jwt_algorithm: str = "HS256"
    access_token_expire_minutes: int = 30
    refresh_token_expire_days: int = 7

    # LLM
    default_llm_provider: str = "anthropic"
    anthropic_api_key: str = ""
    anthropic_model: str = "claude-sonnet-4-6"
    openai_api_key: str = ""
    openai_model: str = "gpt-4o"

    # CORS
    frontend_origin: str = "http://localhost:3000"

    # Embeddings (Phase 2 — Document Intelligence)
    embedding_provider: str = "openai"  # "openai" | "voyage"
    embedding_dimensions: int = 1536
    voyage_api_key: str = ""
    voyage_model: str = "voyage-3"

    # Document storage — local disk for Phase 1/2; swap for S3 on AWS deploy
    upload_dir: str = "./uploads"
    max_upload_mb: int = 25

    # RAG tuning
    chunk_size_chars: int = 1200
    chunk_overlap_chars: int = 200
    retrieval_top_k: int = 5

    # Agents / tools (Phase 3)
    tavily_api_key: str = ""  # search_web tool — https://tavily.com


settings = Settings()
