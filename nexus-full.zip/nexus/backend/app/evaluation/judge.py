"""
LLM-as-judge scoring for automated evaluation. This is the standard
pattern for grading open-ended RAG/agent outputs at scale — there's no
deterministic string-match that captures "is this answer actually
correct and grounded" — but it comes with a real, worth-stating
limitation: the judge is itself an LLM call, with its own failure modes
(it can be fooled by confident-sounding wrong answers, and its scores
will drift if the underlying judge model changes). Treat these scores as
a consistent, repeatable signal for tracking regressions over time, not
as ground truth on par with human grading.
"""
import json

from app.llm.base import LLMProvider

JUDGE_SYSTEM_PROMPT = (
    "You are an evaluation judge for an enterprise AI system. You will be "
    "given a question, the system's answer, optionally a reference answer, "
    "and optionally the context the system retrieved before answering. "
    "Score the answer on four dimensions from 0.0 to 1.0 (use the full range, "
    "not just 0/0.5/1), and flag hallucination. Respond with ONLY a JSON "
    "object and nothing else — no markdown fences, no commentary:\n"
    "{\n"
    '  "accuracy": <correctness vs. the reference answer, if one was given; '
    "if no reference was given, judge plausibility and internal consistency>,\n"
    '  "relevance": <does the answer actually address the question asked>,\n'
    '  "faithfulness": <is every factual claim grounded in the retrieved '
    "context, if context was given; if no context was given, score whether "
    "the answer avoids stating unsupported specifics as fact>,\n"
    '  "response_quality": <clarity, completeness, organization>,\n'
    '  "hallucinated": <true if the answer states something as fact that is '
    "not supported by the context or reference answer, false otherwise>,\n"
    '  "rationale": "<one or two sentences explaining the scores>"\n'
    "}"
)


def _build_judge_prompt(
    question: str,
    generated_answer: str,
    reference_answer: str | None,
    retrieved_context: str | None,
) -> str:
    parts = [f"QUESTION:\n{question}", f"\nSYSTEM'S ANSWER:\n{generated_answer}"]
    if reference_answer:
        parts.append(f"\nREFERENCE ANSWER (for accuracy comparison):\n{reference_answer}")
    if retrieved_context:
        parts.append(f"\nRETRIEVED CONTEXT (for faithfulness checking):\n{retrieved_context}")
    else:
        parts.append(
            "\n(No context was retrieved for this question — the system answered from "
            "general knowledge/reasoning alone.)"
        )
    return "\n".join(parts)


DEFAULT_JUDGMENT = {
    "accuracy": None,
    "relevance": None,
    "faithfulness": None,
    "response_quality": None,
    "hallucinated": None,
    "rationale": "Judge response could not be parsed as JSON.",
}


async def judge_response(
    provider: LLMProvider,
    question: str,
    generated_answer: str,
    reference_answer: str | None = None,
    retrieved_context: str | None = None,
) -> dict:
    """
    Returns a dict with accuracy/relevance/faithfulness/response_quality
    (floats 0-1 or None), hallucinated (bool or None), and rationale
    (str). Never raises on a malformed judge response — falls back to
    DEFAULT_JUDGMENT (all None) with the raw text in the rationale, so
    one bad judge call doesn't crash an entire evaluation run.
    """
    prompt = _build_judge_prompt(question, generated_answer, reference_answer, retrieved_context)
    raw = await provider.complete(system=JUDGE_SYSTEM_PROMPT, user_message=prompt, max_tokens=400)

    try:
        # Judge models occasionally wrap JSON in a markdown fence despite
        # instructions not to — strip it before parsing rather than
        # failing the whole case over a formatting slip.
        cleaned = raw.strip()
        if cleaned.startswith("```"):
            cleaned = cleaned.strip("`")
            if cleaned.startswith("json"):
                cleaned = cleaned[4:]
        parsed = json.loads(cleaned.strip())
    except (json.JSONDecodeError, AttributeError):
        return {**DEFAULT_JUDGMENT, "rationale": f"Unparseable judge output: {raw[:200]}"}

    def _score(key: str) -> float | None:
        val = parsed.get(key)
        if isinstance(val, (int, float)):
            return max(0.0, min(1.0, float(val)))
        return None

    hallucinated_raw = parsed.get("hallucinated")
    rationale_raw = parsed.get("rationale")

    return {
        "accuracy": _score("accuracy"),
        "relevance": _score("relevance"),
        "faithfulness": _score("faithfulness"),
        "response_quality": _score("response_quality"),
        "hallucinated": hallucinated_raw if isinstance(hallucinated_raw, bool) else None,
        "rationale": rationale_raw if isinstance(rationale_raw, str) else "",
    }
