from sqlalchemy.orm import Session

from app.services.retrieval import retrieve_relevant_chunks


async def score_retrieval(
    db: Session, user_id: str, question: str, expected_document_id: str
) -> tuple[float, float]:
    """
    Measures the retriever in isolation — calls the same retrieval
    function the search_documents tool uses, directly, regardless of
    whether the agent actually chose to call that tool for this
    question. This is deliberate: a case with expected_document_id set
    is specifically testing "does semantic search surface the right
    document for this query", which is a property of the retrieval
    subsystem, not of the agent's tool-use judgment (that's a separate
    thing to evaluate, and conflating the two would make a bad score
    ambiguous — is retrieval broken, or did the agent just not bother
    searching?).

    precision = fraction of retrieved chunks that came from the expected
    document; recall = 1.0 if the expected document appears anywhere in
    the retrieved set, else 0.0 (single relevant document per case).
    """
    chunks = await retrieve_relevant_chunks(db, user_id, question)
    if not chunks:
        return 0.0, 0.0

    matching = [c for c in chunks if c.document_id == expected_document_id]
    precision = len(matching) / len(chunks)
    recall = 1.0 if matching else 0.0
    return precision, recall
