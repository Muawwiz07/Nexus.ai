import json
from datetime import datetime, timezone

from sqlalchemy.orm import Session

from app.agents.definitions import AGENT_REGISTRY, COMMON_TOOL_NAMES
from app.agents.executor import execute_agentic_step
from app.evaluation.judge import judge_response
from app.evaluation.retrieval_metrics import score_retrieval
from app.llm.factory import get_provider
from app.models import Conversation, EvalCase, EvalDataset, EvalResult, EvalRun, Message, User
from app.pricing import estimate_cost_usd
from app.telemetry import get_current_usage, start_usage_tracking, stop_usage_tracking
from app.tools import resolve_tools
from app.tools.base import ToolContext

# Fixed to the General agent's tool set rather than running the router —
# an eval run is testing "how good is the system at answering", and
# routing itself is a separate, non-deterministic decision that would
# make case-to-case comparisons noisier without adding evaluation signal.
EVAL_TOOL_NAMES = list(AGENT_REGISTRY["general"].tool_names) + COMMON_TOOL_NAMES
EVAL_SYSTEM_PROMPT = AGENT_REGISTRY["general"].system_prompt


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _extract_retrieved_context(trace: list[dict]) -> str | None:
    """Pulls the text the search_documents tool actually returned during
    this case, if it was called — this is what the model saw, and so
    what the judge should check faithfulness against."""
    texts = []
    for event in trace:
        if event.get("type") == "tool_result" and event.get("name") == "search_documents":
            result = event.get("result")
            if isinstance(result, dict) and isinstance(result.get("result"), str):
                texts.append(result["result"])
    return "\n\n".join(texts) if texts else None


def _avg(values: list[float]) -> float | None:
    clean = [v for v in values if v is not None]
    return sum(clean) / len(clean) if clean else None


async def run_evaluation(db: Session, dataset_id: str, user: User) -> EvalRun | None:
    dataset = db.query(EvalDataset).filter(EvalDataset.id == dataset_id).first()
    if not dataset:
        return None

    cases = db.query(EvalCase).filter(EvalCase.dataset_id == dataset.id).all()
    if not cases:
        return None

    run = EvalRun(dataset_id=dataset.id, user_id=user.id, status="running", started_at=_now())
    db.add(run)
    db.commit()
    db.refresh(run)

    # Every case's Q&A is persisted as a message pair in one dedicated
    # Conversation — same transparency pattern as workflow runs — but
    # each case's LLM call sees only its own question, not prior cases'
    # history, since test cases are independent by design.
    conversation = Conversation(
        user_id=user.id,
        title=f"[Evaluation] {dataset.name} — {run.started_at.strftime('%Y-%m-%d %H:%M UTC')}",
        rag_enabled=True,
    )
    db.add(conversation)
    db.commit()
    db.refresh(conversation)

    try:
        provider = get_provider()
        judge_provider = provider  # same model grades and answers by default; see README caveat
        tools = resolve_tools(EVAL_TOOL_NAMES)
        ctx = ToolContext(db=db, user=user, conversation=conversation, emit=None)

        judge_cost_usd = 0.0
        scored: list[EvalResult] = []

        for case in cases:
            db.add(Message(conversation_id=conversation.id, role="user", content=case.question))
            db.commit()

            start_usage_tracking(provider.name, provider.model_name)
            answer_text, trace = await execute_agentic_step(
                provider,
                [{"role": "user", "content": case.question}],
                tools,
                EVAL_SYSTEM_PROMPT,
                ctx,
                on_event=None,
                max_iterations=5,
            )
            answer_usage = get_current_usage()
            stop_usage_tracking()

            db.add(
                Message(
                    conversation_id=conversation.id,
                    role="assistant",
                    content=answer_text,
                    agent_key="eval",
                    tool_trace=json.dumps(trace) if trace else None,
                )
            )
            db.commit()

            retrieved_context = _extract_retrieved_context(trace)

            start_usage_tracking(judge_provider.name, judge_provider.model_name)
            judgment = await judge_response(
                judge_provider,
                question=case.question,
                generated_answer=answer_text,
                reference_answer=case.expected_answer,
                retrieved_context=retrieved_context,
            )
            judge_usage = get_current_usage()
            stop_usage_tracking()
            if judge_usage:
                judge_cost_usd += estimate_cost_usd(
                    judge_usage.model, judge_usage.input_tokens, judge_usage.output_tokens
                )

            retrieval_precision = retrieval_recall = None
            if case.expected_document_id:
                retrieval_precision, retrieval_recall = await score_retrieval(
                    db, user.id, case.question, case.expected_document_id
                )

            answer_cost = (
                estimate_cost_usd(
                    answer_usage.model, answer_usage.input_tokens, answer_usage.output_tokens
                )
                if answer_usage
                else 0.0
            )

            result = EvalResult(
                eval_run_id=run.id,
                case_id=case.id,
                question=case.question,
                generated_answer=answer_text,
                accuracy=judgment["accuracy"],
                relevance=judgment["relevance"],
                faithfulness=judgment["faithfulness"],
                response_quality=judgment["response_quality"],
                hallucinated=judgment["hallucinated"],
                judge_rationale=judgment["rationale"],
                retrieval_precision=retrieval_precision,
                retrieval_recall=retrieval_recall,
                latency_ms=answer_usage.latency_ms if answer_usage else 0.0,
                input_tokens=answer_usage.input_tokens if answer_usage else 0,
                output_tokens=answer_usage.output_tokens if answer_usage else 0,
                cost_usd=answer_cost,
            )
            db.add(result)
            db.commit()
            scored.append(result)

        run.avg_accuracy = _avg([r.accuracy for r in scored])
        run.avg_relevance = _avg([r.relevance for r in scored])
        run.avg_faithfulness = _avg([r.faithfulness for r in scored])
        run.avg_response_quality = _avg([r.response_quality for r in scored])
        run.avg_retrieval_precision = _avg([r.retrieval_precision for r in scored])
        run.avg_retrieval_recall = _avg([r.retrieval_recall for r in scored])

        hallucination_flags = [r.hallucinated for r in scored if r.hallucinated is not None]
        run.hallucination_rate = (
            sum(1 for h in hallucination_flags if h) / len(hallucination_flags)
            if hallucination_flags
            else None
        )

        run.avg_latency_ms = _avg([r.latency_ms for r in scored])
        run.total_input_tokens = sum(r.input_tokens for r in scored)
        run.total_output_tokens = sum(r.output_tokens for r in scored)
        # Includes judge overhead, unlike each EvalResult.cost_usd (which
        # reflects only the answering call — the production-representative
        # number). The run total is "what did evaluating this cost", which
        # is a different, also-useful question.
        run.total_cost_usd = sum(r.cost_usd for r in scored) + judge_cost_usd

        run.status = "success"

    except Exception as e:  # noqa: BLE001 — a bad run must not raise past the API boundary
        run.status = "failed"
        run.error_message = str(e)

    finally:
        run.finished_at = _now()
        db.commit()

    return run
