"""
Cost estimation from token counts. These figures are snapshot prices at
the time this scaffold was written, entered by hand — NOT fetched from
any live pricing API, and vendors change prices without much notice.
Treat every cost_usd value derived from this table as directional
("roughly what this costs"), not as a number to reconcile against an
actual invoice. Before relying on this for a real budget decision,
check current pricing:
  https://www.anthropic.com/pricing
  https://openai.com/api/pricing
  https://docs.voyageai.com/docs/pricing
"""

# (input_usd_per_million_tokens, output_usd_per_million_tokens)
PRICING_PER_MILLION_TOKENS: dict[str, tuple[float, float]] = {
    "claude-sonnet-4-6": (3.00, 15.00),
    "gpt-4o": (2.50, 10.00),
    "text-embedding-3-small": (0.02, 0.0),
    "voyage-3": (0.06, 0.0),
}

# Used for any model string not found above, so cost estimation degrades
# to "approximately mid-tier frontier-model pricing" instead of crashing
# or silently reporting $0 for a model we don't recognize.
DEFAULT_PRICING = (3.00, 15.00)


def estimate_cost_usd(model: str, input_tokens: int, output_tokens: int) -> float:
    in_price, out_price = PRICING_PER_MILLION_TOKENS.get(model, DEFAULT_PRICING)
    return (input_tokens / 1_000_000) * in_price + (output_tokens / 1_000_000) * out_price
