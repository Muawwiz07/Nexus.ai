from datetime import datetime

from pydantic import BaseModel, EmailStr, ConfigDict


# ---- Auth ----

class UserCreate(BaseModel):
    email: EmailStr
    password: str
    full_name: str | None = None


class UserLogin(BaseModel):
    email: EmailStr
    password: str


class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    email: EmailStr
    full_name: str | None = None
    created_at: datetime


class TokenPair(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"


class RefreshRequest(BaseModel):
    refresh_token: str


# ---- Chat ----

class ConversationOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    title: str
    llm_provider: str
    created_at: datetime


class MessageOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    role: str
    content: str
    created_at: datetime


class ConversationDetail(ConversationOut):
    messages: list[MessageOut] = []


# ---- Documents (Phase 2 — Document Intelligence) ----

class DocumentOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    filename: str
    content_type: str
    status: str
    error_message: str | None = None
    chunk_count: int
    created_at: datetime


class CitationOut(BaseModel):
    index: int
    document_id: str
    document_title: str
    page_number: int | None = None
    snippet: str


# ---- Agents / tools / memory (Phase 3) ----

class TaskOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    title: str
    description: str | None = None
    status: str
    due_date: datetime | None = None
    source: str
    created_at: datetime


class ReportOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    title: str
    content: str
    created_at: datetime


class NotificationOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    recipient: str
    subject: str | None = None
    message: str
    status: str
    created_at: datetime


# ---- Automation / workflows (Phase 4) ----

class WorkflowStepIn(BaseModel):
    instruction: str


class WorkflowStepOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    step_order: int
    instruction: str


class WorkflowCreate(BaseModel):
    name: str
    description: str | None = None
    cron_expression: str  # standard 5-field cron, interpreted in UTC
    enabled: bool = True
    llm_provider: str = "anthropic"
    system_prompt: str | None = None
    tool_names: list[str]
    steps: list[WorkflowStepIn]


class WorkflowUpdate(BaseModel):
    name: str | None = None
    description: str | None = None
    cron_expression: str | None = None
    enabled: bool | None = None
    llm_provider: str | None = None
    system_prompt: str | None = None
    tool_names: list[str] | None = None
    steps: list[WorkflowStepIn] | None = None  # if provided, replaces all steps


class WorkflowOut(BaseModel):
    # Not from_attributes — tool_names is stored as a JSON string on the
    # ORM model and needs explicit parsing, so the router builds this by
    # hand (see routers/workflows.py::_to_out) rather than letting Pydantic
    # auto-map columns.
    id: str
    name: str
    description: str | None = None
    cron_expression: str
    enabled: bool
    llm_provider: str
    tool_names: list[str]
    last_run_at: datetime | None = None
    created_at: datetime


class WorkflowDetail(WorkflowOut):
    system_prompt: str | None = None
    steps: list[WorkflowStepOut]


class WorkflowRunOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    status: str
    conversation_id: str | None = None
    started_at: datetime
    finished_at: datetime | None = None
    error_message: str | None = None


class ToolInfoOut(BaseModel):
    name: str
    description: str


# ---- Evaluation (Phase 5) ----

class EvalCaseIn(BaseModel):
    question: str
    expected_answer: str | None = None
    expected_document_id: str | None = None


class EvalCaseOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    question: str
    expected_answer: str | None = None
    expected_document_id: str | None = None


class EvalDatasetCreate(BaseModel):
    name: str
    description: str | None = None
    cases: list[EvalCaseIn]


class EvalDatasetOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    name: str
    description: str | None = None
    created_at: datetime


class EvalDatasetDetail(EvalDatasetOut):
    cases: list[EvalCaseOut]


class EvalResultOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    case_id: str
    question: str
    generated_answer: str
    accuracy: float | None = None
    relevance: float | None = None
    faithfulness: float | None = None
    response_quality: float | None = None
    hallucinated: bool | None = None
    judge_rationale: str | None = None
    retrieval_precision: float | None = None
    retrieval_recall: float | None = None
    latency_ms: float
    input_tokens: int
    output_tokens: int
    cost_usd: float


class EvalRunOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    dataset_id: str
    status: str
    error_message: str | None = None
    avg_accuracy: float | None = None
    avg_relevance: float | None = None
    avg_faithfulness: float | None = None
    avg_response_quality: float | None = None
    avg_retrieval_precision: float | None = None
    avg_retrieval_recall: float | None = None
    hallucination_rate: float | None = None
    avg_latency_ms: float | None = None
    total_input_tokens: int
    total_output_tokens: int
    total_cost_usd: float
    started_at: datetime
    finished_at: datetime | None = None


class EvalRunDetail(EvalRunOut):
    results: list[EvalResultOut]


class TelemetrySummaryOut(BaseModel):
    """Aggregate over real production traffic (RequestLog), not eval
    runs — this answers "what is NEXUS actually costing/how fast is it
    actually responding" independent of any test dataset."""

    window_days: int
    total_requests: int
    total_input_tokens: int
    total_output_tokens: int
    total_cost_usd: float
    avg_latency_ms: float | None = None
    by_kind: dict[str, int]  # kind -> request count, e.g. {"chat": 40, "workflow_step": 6}


class TelemetryPointOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    created_at: datetime
    kind: str
    latency_ms: float
    cost_usd: float
    input_tokens: int
    output_tokens: int
