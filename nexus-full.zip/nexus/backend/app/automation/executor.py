import json
from datetime import datetime, timezone

from sqlalchemy.orm import Session

from app.agents.executor import execute_agentic_step
from app.llm.base import ChatMessage
from app.llm.factory import get_provider
from app.models import Conversation, Message, User, Workflow, WorkflowRun, WorkflowStep
from app.telemetry import get_current_usage, start_usage_tracking, stop_usage_tracking
from app.tools import resolve_tools
from app.tools.base import ToolContext
from app.usage_logging import log_request

DEFAULT_WORKFLOW_SYSTEM_PROMPT = (
    "You are NEXUS running an automated workflow on a schedule — no one is "
    "watching in real time, so be concrete and factual, and actually use your "
    "tools rather than describing what you would do. Fully complete each "
    "instruction before moving to the next."
)


def _now() -> datetime:
    return datetime.now(timezone.utc)


async def run_workflow(db: Session, workflow_id: str) -> WorkflowRun | None:
    """
    Executes every step of a workflow in order, threading conversation
    history between steps so later steps can build on earlier findings —
    e.g. step 2 ("identify overdue work") naturally sees what step 1
    ("analyze pending tasks") already pulled via query_database.

    Runs with no human in the loop: on any failure the run is marked
    failed with the error captured rather than raised, since an
    unhandled exception here would otherwise silently kill the
    scheduler's background job.

    Returns None (without creating a run) if the workflow is missing,
    disabled, has no owner, or has no steps — the caller (scheduler or
    the run-now endpoint) treats that as "nothing to do", not an error.
    """
    workflow = db.query(Workflow).filter(Workflow.id == workflow_id).first()
    if not workflow or not workflow.enabled:
        return None

    user = db.query(User).filter(User.id == workflow.user_id).first()
    if not user:
        return None

    steps = (
        db.query(WorkflowStep)
        .filter(WorkflowStep.workflow_id == workflow.id)
        .order_by(WorkflowStep.step_order)
        .all()
    )
    if not steps:
        return None

    # Each run gets its own Conversation so the full transcript — every
    # step, every tool call — is inspectable in the ordinary chat UI,
    # not a separate write-only log nobody looks at.
    started_at = _now()
    conversation = Conversation(
        user_id=user.id,
        title=f"[Automation] {workflow.name} — {started_at.strftime('%Y-%m-%d %H:%M UTC')}",
        llm_provider=workflow.llm_provider,
        rag_enabled=True,
    )
    db.add(conversation)
    db.commit()
    db.refresh(conversation)

    run = WorkflowRun(
        workflow_id=workflow.id,
        conversation_id=conversation.id,
        status="running",
        started_at=started_at,
    )
    db.add(run)
    db.commit()
    db.refresh(run)

    try:
        provider = get_provider(workflow.llm_provider)
        tools = resolve_tools(json.loads(workflow.tool_names))
        system = workflow.system_prompt or DEFAULT_WORKFLOW_SYSTEM_PROMPT
        # emit=None — there's no live client to push tool_call/tool_result
        # events to; the trace is still captured and stored per-step below.
        ctx = ToolContext(db=db, user=user, conversation=conversation, emit=None)

        history: list[ChatMessage] = []
        for step in steps:
            db.add(
                Message(conversation_id=conversation.id, role="user", content=step.instruction)
            )
            db.commit()
            history.append({"role": "user", "content": step.instruction})

            start_usage_tracking(provider.name, provider.model_name)
            step_text, step_trace = await execute_agentic_step(
                provider, history, tools, system, ctx, on_event=None, max_iterations=5
            )
            log_request(
                db,
                user.id,
                "workflow_step",
                get_current_usage(),
                conversation_id=conversation.id,
                workflow_run_id=run.id,
            )
            stop_usage_tracking()

            db.add(
                Message(
                    conversation_id=conversation.id,
                    role="assistant",
                    content=step_text,
                    agent_key="automation",
                    tool_trace=json.dumps(step_trace) if step_trace else None,
                )
            )
            db.commit()
            history.append({"role": "assistant", "content": step_text})

        run.status = "success"

    except Exception as e:  # noqa: BLE001 — a bad run must not crash the scheduler thread
        run.status = "failed"
        run.error_message = str(e)

    finally:
        run.finished_at = _now()
        workflow.last_run_at = run.finished_at
        db.commit()

    return run
