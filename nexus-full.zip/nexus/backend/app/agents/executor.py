import json
from typing import Any, Awaitable, Callable

from fastapi import WebSocket
from sqlalchemy.orm import Session

from app.agents.definitions import AGENT_REGISTRY, COMMON_TOOL_NAMES
from app.agents.router import route_agent
from app.llm.base import ChatMessage, LLMProvider
from app.models import Conversation, User
from app.telemetry import get_current_usage, start_usage_tracking, stop_usage_tracking
from app.tools import resolve_tools
from app.tools.base import ToolContext, ToolDefinition
from app.usage_logging import log_request

MAX_TOOL_ITERATIONS = 5


async def execute_agentic_step(
    provider: LLMProvider,
    history: list[ChatMessage],
    tools: list[ToolDefinition],
    system: str,
    ctx: ToolContext,
    on_event: Callable[[dict], Awaitable[None]] | None = None,
    max_iterations: int = MAX_TOOL_ITERATIONS,
) -> tuple[str, list[dict[str, Any]]]:
    """
    The shared core of the tool-calling loop: calls the model, executes
    whatever tools it requests via the shared TOOL_REGISTRY, feeds results
    back, and repeats until the model returns a final text answer.

    Used by both interactive chat (run_agent_turn, below — `on_event`
    forwards to a live WebSocket) and unattended automation runs
    (app/automation/executor.py — `on_event` is None, since there's no
    socket to push to). Same tool-execution code path either way, which
    is exactly the point: a scheduled workflow isn't a separate,
    parallel implementation of "call tools" — it's this same loop with
    nobody watching it run.
    """
    tools_by_name = {t.name: t for t in tools}
    trace: list[dict[str, Any]] = []

    async def on_tool_call(name: str, tool_input: dict) -> None:
        event = {"type": "tool_call", "name": name, "input": tool_input}
        trace.append(event)
        if on_event:
            await on_event(event)

    async def execute_tool(name: str, tool_input: dict) -> str:
        tool = tools_by_name.get(name)
        result: dict | str = (
            {"error": f"Unknown tool: {name}"}
            if tool is None
            else await tool.handler(tool_input, ctx)
        )
        event = {"type": "tool_result", "name": name, "result": result}
        trace.append(event)
        if on_event:
            await on_event(event)
        return result if isinstance(result, str) else json.dumps(result)

    final_text = await provider.run_agentic_turn(
        messages=history,
        tools=tools,
        system=system,
        on_tool_call=on_tool_call,
        execute_tool=execute_tool,
        max_iterations=max_iterations,
    )
    return final_text, trace


async def run_agent_turn(
    db: Session,
    user: User,
    conversation: Conversation,
    provider: LLMProvider,
    history: list[ChatMessage],
    user_content: str,
    websocket: WebSocket,
) -> tuple[str, list[dict[str, Any]], str]:
    """
    Interactive-chat entry point: routes the message to a specialist
    agent, then runs execute_agentic_step with an `on_event` callback
    that forwards routing/tool_call/tool_result frames to the live
    WebSocket so the frontend can show the agent's work as it happens.
    """
    # Starts before routing so the router's own classification call (a
    # real API call with real tokens/latency) counts toward this turn's
    # total, not just the tool-loop calls that follow it.
    start_usage_tracking(provider.name, provider.model_name)
    try:
        agent = await route_agent(provider, user_content)
        await websocket.send_json(
            {"type": "routing", "agent": agent.key, "agent_label": agent.label}
        )

        tool_names = list(agent.tool_names) + COMMON_TOOL_NAMES
        if not conversation.rag_enabled:
            # Respect the conversation-level toggle: if document grounding
            # is off, no agent gets to reach into the user's documents.
            tool_names = [n for n in tool_names if n != "search_documents"]
        tools = resolve_tools(tool_names)

        async def emit(event: dict) -> None:
            await websocket.send_json(event)

        ctx = ToolContext(db=db, user=user, conversation=conversation, emit=emit)

        final_text, trace = await execute_agentic_step(
            provider,
            history,
            tools,
            agent.system_prompt,
            ctx,
            on_event=emit,
            max_iterations=MAX_TOOL_ITERATIONS,
        )
    finally:
        usage = get_current_usage()
        log_request(db, user.id, "chat", usage, conversation_id=conversation.id)
        stop_usage_tracking()

    return final_text, trace, agent.key


__all__ = ["run_agent_turn", "execute_agentic_step", "AGENT_REGISTRY"]
