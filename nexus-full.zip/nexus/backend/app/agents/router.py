from app.agents.definitions import AGENT_REGISTRY, AgentDefinition
from app.llm.base import LLMProvider

ROUTER_SYSTEM_PROMPT = (
    "You are a routing classifier for an enterprise AI platform. Given the "
    "user's message, decide which specialist agent should handle it. Respond "
    "with ONLY the agent key — no punctuation, no explanation, nothing else.\n\n"
    "Agents:\n" + "\n".join(f"- {a.key}: {a.description}" for a in AGENT_REGISTRY.values())
)


async def route_agent(provider: LLMProvider, user_content: str) -> AgentDefinition:
    """
    One cheap, non-streaming completion decides which agent handles this
    turn. Runs on every message (not once per conversation) so a thread
    can naturally move between, say, a Document Agent question and a
    follow-up Task Agent request without the user switching contexts.
    """
    raw = await provider.complete(
        system=ROUTER_SYSTEM_PROMPT, user_message=user_content, max_tokens=10
    )
    key = (raw or "").strip().lower().strip(".,:;\"'").split()[0] if raw and raw.strip() else ""
    return AGENT_REGISTRY.get(key, AGENT_REGISTRY["general"])
