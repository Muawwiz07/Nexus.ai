from dataclasses import dataclass, field


@dataclass
class AgentDefinition:
    key: str
    label: str
    # Shown to the router LLM to decide whether this agent fits a message
    # — keep these mutually distinguishing, not just descriptive, or the
    # router will guess inconsistently between two similar-sounding agents.
    description: str
    system_prompt: str
    tool_names: list[str] = field(default_factory=list)


# Available to every agent regardless of specialty — memory is a platform
# capability, not something only one agent should have.
COMMON_TOOL_NAMES = ["remember_fact", "recall_memory"]

AGENT_REGISTRY: dict[str, AgentDefinition] = {
    "research": AgentDefinition(
        key="research",
        label="Research Agent",
        description=(
            "Open-ended research, comparisons, or questions needing outside "
            "information — combines the user's documents with live web search."
        ),
        system_prompt=(
            "You are NEXUS's Research Agent. Investigate the user's question using "
            "search_documents (their uploaded files) and search_web (the open "
            "internet) as needed, and calculate for any arithmetic. Synthesize "
            "findings into a clear, well-organized answer and name your sources."
        ),
        tool_names=["search_documents", "search_web", "calculate"],
    ),
    "document": AgentDefinition(
        key="document",
        label="Document Agent",
        description=(
            "Questions specifically about the content of the user's uploaded "
            "documents — policies, contracts, handbooks, reports."
        ),
        system_prompt=(
            "You are NEXUS's Document Agent. Answer strictly using search_documents "
            "results from the user's uploaded files. Cite the source document (and "
            "page, if given) for every factual claim. If the documents don't cover "
            "the question, say so plainly instead of guessing."
        ),
        tool_names=["search_documents"],
    ),
    "data_analysis": AgentDefinition(
        key="data_analysis",
        label="Data Analysis Agent",
        description=(
            "Requests to analyze, count, or report on the user's own NEXUS data — "
            "their tasks, documents, or conversations — not general web research."
        ),
        system_prompt=(
            "You are NEXUS's Data Analysis Agent. Use query_database to pull "
            "structured facts about the user's own platform data and calculate for "
            "any math. When asked for a written summary or report, use "
            "generate_report to save it, then tell the user what you found."
        ),
        tool_names=["query_database", "calculate", "generate_report"],
    ),
    "email": AgentDefinition(
        key="email",
        label="Email Agent",
        description="Requests to draft, send, or log an email or notification to someone.",
        system_prompt=(
            "You are NEXUS's Email Agent. Draft clear, professional message content, "
            "then use send_notification to send it. Mention in your reply that "
            "delivery is simulated in this environment unless told otherwise."
        ),
        tool_names=["send_notification"],
    ),
    "task": AgentDefinition(
        key="task",
        label="Task Agent",
        description=(
            "Requests to create, assign, or track a task or action item — e.g. "
            "'create a task for X to review Y'."
        ),
        system_prompt=(
            "You are NEXUS's Task Agent. When asked to create, assign, or track "
            "work, use create_task to record it — search_documents first if you "
            "need context from an uploaded document to write a clear description. "
            "Confirm what was created, including the task id."
        ),
        tool_names=["create_task", "search_documents"],
    ),
    "general": AgentDefinition(
        key="general",
        label="General Assistant",
        description=(
            "Anything conversational or that doesn't clearly fit a specialist above "
            "— greetings, general questions, or requests spanning multiple areas."
        ),
        system_prompt=(
            "You are NEXUS, a helpful enterprise AI assistant. Use search_documents "
            "if the question might be answered by the user's uploaded files, and "
            "calculate for arithmetic. Be concise and direct."
        ),
        tool_names=["search_documents", "calculate"],
    ),
}
